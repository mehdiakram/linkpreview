<?php
/*
Plugin Name: Royal Link Hover Preview
Plugin URI: http://www.royaltechbd.com
Description: Simple plugin to preview snapshot when hover any link
Author: SM Mehdi Akram
Version: 2022.02.25
Author URI: http://www.shamokaldarpon.com/
*/

/*Some Set-up*/
define('PLUGIN_PATH', WP_PLUGIN_URL . '/' . plugin_basename( dirname(__FILE__) ) . '/' );


/* Adding jquery */
function load_jquery() {
    if ( ! wp_script_is( 'jquery', 'enqueued' )) {
        wp_enqueue_script( 'jquery' );
    }
}
add_action( 'wp_enqueue_scripts', 'load_jquery' );


/* Adding JS file */
wp_enqueue_script('jquery.minipreview', PLUGIN_PATH.'lib/jquery.minipreview.js', array( 'jquery' ), '',  true );


/* Adding CSS file */
wp_enqueue_style('jquery.minipreview', PLUGIN_PATH.'lib/jquery.minipreview.css');


function mytheme_content_ad( $content ) {
    $myadcode = '<div class="hoverpreview">';
    $myadcode .= $content;
    $myadcode .= '</div>';

    $filteredcontent = $myadcode;

    return $filteredcontent;
}
add_filter( 'the_content', 'mytheme_content_ad' );


// Function Add in Footer
function royal_link_hover_preview(){
	echo'
	<script type="text/javascript">
	jQuery.noConflict();
	(function( $ ) {
	$(document).ready(function(){
	  $(function() {
		  $(\'.hoverpreview a\').miniPreview({ prefetch: \'pageload\' });
	  });
	});
	})(jQuery);
  </script>';
}
add_action('wp_footer','royal_link_hover_preview');

?>