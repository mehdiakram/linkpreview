<?php
namespace RoyalAddons;

class ROYAL_Widget_Loader{

  private static $_instance = null;

  public static function instance()  {
    if (is_null(self::$_instance)) {
      self::$_instance = new self();
    }
    return self::$_instance;
  }



  public function __construct(){

    $this->files();
    $this->setup_hooks();
    
  }



  protected function setup_hooks() {
    add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'royal_elementor_scripts' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_scripts' ] );
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
    add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'royal_elementor_admin' ] ); 

    add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ] );
    add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
    add_action( 'elementor/theme/register_locations', [$this, 'royal_elementor_locations'], 10, 1);
		add_action( 'elementor/controls/controls_registered', [ $this, 'init_controls' ] );
		add_action( 'elementor/init', [ $this, 'init_modules' ] );   

    add_action( 'elementor/element/after_section_end', [$this, 'remove_pro_controls'], 10, 2);
  }


  public function register_scripts() {

  }


  public function enqueue_scripts() {
    
  
  }


  public function init_controls() {

  }


  public function init_modules() {

  }


  public function remove_pro_controls($element, $section_id) {
    if ($section_id == 'section_custom_css_pro') {
    $element->remove_control('section_custom_css_pro');
    }

    $element->remove_control('section_custom_attributes_pro');
  }


	private function files() {
    include ROYALADDONSPATH. 'class/royalclass.php';  
		if (! function_exists( 'is_woocommerce_activated' ) ) {
      include ROYALADDONSPATH. 'class/royalwooclass.php';  
    }

    include ROYALADDONSPATH. 'controls/royalcustomcss.php';  
    include ROYALADDONSPATH. 'controls/royalequalheight.php';  
    include ROYALADDONSPATH. 'controls/royalwrapperlink.php';  
	}
  

  function royal_elementor_locations( $elementor_theme_manager ) { 
    $elementor_theme_manager->register_location(
      'main-sidebar',
      [
        'label' => __( 'Main Sidebar', 'royaltech' ),
        'multiple' => true,
        'edit_in_content' => false,
      ]
    );  


		$elementor_theme_manager->register_location(
			'header',
			[
				'is_core'         => false,
				'public'          => false,
				'label'           => esc_html__( 'Header', 'royaltech' ),
				'edit_in_content' => false,
			]
		);

		$elementor_theme_manager->register_location(
			'footer',
			[
				'is_core'         => false,
				'public'          => false,
				'label'           => esc_html__( 'Footer', 'royaltech' ),
				'edit_in_content' => false,
			]
		);
	}    




  public function royal_elementor_admin(){
    wp_enqueue_style('royaladmin', ROYALADDONSURL.'assets/css/admin.css', [], rand(), 'all' );
  }

  

  public function royal_elementor_scripts(){
    wp_enqueue_script('jquery');
    wp_enqueue_script('all.hook', ROYALADDONSURL.'assets/js/all.hook.js', [],'', true );
    wp_enqueue_script('royalmodernizr', ROYALADDONSURL.'js/modernizr.min.js', array('jquery'), '1.0.0' );



    /* Owl Carousel */
    wp_register_script('royalowlcarousel', ROYALADDONSURL.'assets/vendor/owl-carousel/owl.carousel.min.js', [], '' );
    wp_register_style('royalowlcarousel', ROYALADDONSURL . 'assets/vendor/owl-carousel/owl.carousel.min.css');
    wp_register_style('royalowlcarouseltheme', ROYALADDONSURL . 'assets/vendor/owl-carousel/owl.theme.default.min.css');
    wp_register_style('royalcarousel', ROYALADDONSURL. 'assets/css/royalcarousel.css');

    /* Timeline */
    wp_register_style('royaltimeline', ROYALADDONSURL. 'assets/css/royaltimeline.css');

    /* Lottie Player */
    wp_register_script('lottie-player', ROYALADDONSURL. 'assets/vendor/lottie-player/lottie-player.js', [], '' );

    /* Flipbox */
    wp_register_style('royalflipbox', ROYALADDONSURL . 'assets/css/royalflipbox.css');

    /* RoyalTeam1 */    
    wp_register_script('royalteam', ROYALADDONSURL. 'assets/js/royalteam.js', [], '' );
    wp_register_style('royalteam', ROYALADDONSURL . 'assets/css/royalteam.css');

    /* prism required for sourcecode */    
    wp_register_script('prism', ROYALADDONSURL.'assets/vendor/prism/prism.js', [],'', true );
    wp_register_style('prism', ROYALADDONSURL.'assets/vendor/prism/prism.min.css');

    /* RoyalSourceCode */
    wp_register_style('royalsourcecode', ROYALADDONSURL . 'assets/css/royalsourcecode.css');

    /* Royalanimatedheadline */
    wp_register_script('royalanimatedheadline', ROYALADDONSURL.'assets/js/royalanimatedheadline.js',[],'', true);
    wp_register_style('royalanimatedheadline', ROYALADDONSURL.'assets/css/royalanimatedheadline.css');

    /* Royalanimatedheadline */
    wp_register_script('countdown', ROYALADDONSURL.'assets/vendor/countdown/countdown.js', [],'', true );
    wp_register_style('royalcountdown', ROYALADDONSURL.'assets/css/royalcountdown.css');

    /* royaltyping */
    wp_register_script('royaltypedcustom', ROYALADDONSURL.'assets/vendor/typed/typed.custom.js', [], '' );
    wp_register_style('royaltyping', ROYALADDONSURL.'assets/css/royaltyping.css');

    /* RoyalImageComparison2 */
    wp_register_script('royalimagecomparison', ROYALADDONSURL.'assets/js/royalimagecomparison.js', [],'', true );
    wp_register_script('jquery-event-move', ROYALADDONSURL.'assets/vendor/jquery.event.move/jquery.event.move.js',[],'1.0.0', true );
    wp_register_style('royalimagecomparison', ROYALADDONSURL.'assets/css/royalimagecomparison.css');


    /*Others*/
    wp_enqueue_script('allinone', ROYALADDONSURL.'assets/js/allinone.js',[],'', true);
    wp_enqueue_style('allinone', ROYALADDONSURL.'assets/css/allinone.css'); 
    wp_register_style('royalaccordion', ROYALADDONSURL.'assets/css/royalaccordion.css');
    wp_register_style('royalblob', ROYALADDONSURL.'assets/css/royalblob.css');
    wp_register_style('royaldesktopnavmenu', ROYALADDONSURL.'assets/css/royaldesktopnavmenu.css');
    wp_register_style('royalheading', ROYALADDONSURL.'assets/css/royalheading.css');
    wp_register_style('royalimagebox', ROYALADDONSURL.'assets/css/royalimagebox.css');
    wp_register_style('royalmobilemenu', ROYALADDONSURL.'assets/css/royalmobilemenu.css');
    wp_register_style('royalpost', ROYALADDONSURL.'assets/css/royalpost.css');
    wp_register_style('royalpreviewcard', ROYALADDONSURL.'assets/css/royalpreviewcard.css');
    wp_register_style('royalpricelist', ROYALADDONSURL.'assets/css/royalpricelist.css');
    wp_register_style('royalpricingtable', ROYALADDONSURL.'assets/css/royalpricingtable.css');
    wp_register_style('royalprofilecard', ROYALADDONSURL.'assets/css/royalprofilecard.css');
    wp_register_style('royalsearch', ROYALADDONSURL.'assets/css/royalsearch.css');
    wp_register_style('royalservicelist', ROYALADDONSURL.'assets/css/royalservicelist.css');
    wp_register_style('royalservices', ROYALADDONSURL.'assets/css/royalservices.css');
    wp_register_style('royalwavetext', ROYALADDONSURL.'assets/css/royalwavetext.css');
    wp_register_style('royalwoominicart', ROYALADDONSURL.'assets/css/royalwoominicart.css');



    wp_register_script('royalcalltoactionbox', ROYALADDONSURL.'js/royalcalltoactionbox.js',[],'', true);
    wp_register_style('royalcalltoactionbox', ROYALADDONSURL.'css/royalcalltoactionbox.css');

    
   
    wp_enqueue_script('test', ROYALADDONSURL.'js/test.js', [], '' );
    wp_enqueue_style('test', ROYALADDONSURL . 'css/test.css');
  }



	public static function royal_widget_list() {
		$widget_list = [
      'RoyalAnimatedHeadline',
      'RoyalTeam',
      'Royalaccordion',
      'RoyalPricingTable',
      'RoyalImageBox',
      'RoyalHeading',
      'RoyalFeatures',
      'RoyalImageCompare',
      'RoyalContactForm7',
      'RoyalTyping',
      'RoyalLottieAnimations',
      'RoyalPriceList',
      'RoyalPreviewCard',
      'RoyalCallToActionBox',
      'RoyalFlipbox',
      'RoyalPostGrid',
      'RoyalPostCategory',
      'RoyalImageComparison2',
      'RoyalSearch',
      'RoyalServices',
      'RoyalBlobBackground',
      'ElementorModal',
      'RoyalWaveText',
      'RoyalNavMenuDesktop',
      'RoyalNavMenuMobile',
      'RoyalShapeDivider',
      'RoyalServiceList',
      'RoyalProgressbar',
      'RoyalContentSlider',
      'RoyalPostCarousel',
      'RoyalImageCarousel',
      'RoyalTestimonialCarousel',
      'RoyalProfileCard',
      'RoyalSourceCode',
      'RoyalCountdown',
      'RoyalTimeline',

      
      /* Woocommece */
      'RoyalWooProductsGrid',
      'RoyalWooMiniCart',
		];
		return $widget_list;
	}


  public function include_widgets_files() {      
		$widget_list = $this->royal_widget_list();
		if ( ! empty( $widget_list ) ) {
			foreach ( $widget_list as $handle => $data ) {
        $data = strtolower($data);
				require_once ROYALADDONSPATH.'widgets/' . $data . '.php';
			}
		}

	}





  public function register_widgets($royalwidgets){
    $this->include_widgets_files();

    $royalwidgets->register(new Widgets\RoyalAnimatedHeadline() );
    $royalwidgets->register(new Widgets\RoyalTeam());
    $royalwidgets->register(new Widgets\RoyalAccordion());
    $royalwidgets->register(new Widgets\RoyalPricingTable());
    $royalwidgets->register(new Widgets\RoyalImageBox());
    $royalwidgets->register(new Widgets\RoyalHeading());
    $royalwidgets->register(new Widgets\RoyalFeatures() );
    $royalwidgets->register(new Widgets\RoyalImageCompare());
    $royalwidgets->register(new Widgets\RoyalContactForm7());
    $royalwidgets->register(new Widgets\RoyalTyping());
    $royalwidgets->register(new Widgets\RoyalAnimatedHeadline());
    $royalwidgets->register(new Widgets\RoyalLottieAnimations());
    $royalwidgets->register(new Widgets\RoyalPriceList());
    $royalwidgets->register(new Widgets\RoyalPreviewCard());
    $royalwidgets->register(new Widgets\RoyalCallToActionBox());
    $royalwidgets->register(new Widgets\RoyalFlipbox());
    $royalwidgets->register(new Widgets\RoyalPostGrid());
    $royalwidgets->register(new Widgets\RoyalPostCategory());
    $royalwidgets->register(new Widgets\RoyalImageComparison2());
    $royalwidgets->register(new Widgets\RoyalSearch());
    $royalwidgets->register(new Widgets\RoyalServices());
    $royalwidgets->register(new Widgets\RoyalBlobBackground());
    $royalwidgets->register(new Widgets\ElementorModal());
    $royalwidgets->register(new Widgets\RoyalWaveText());
    $royalwidgets->register(new Widgets\RoyalNavMenuDesktop());
    $royalwidgets->register(new Widgets\RoyalNavMenuMobile());
    $royalwidgets->register(new Widgets\RoyalShapeDivider());
    $royalwidgets->register(new Widgets\RoyalServiceList());
    $royalwidgets->register(new Widgets\RoyalProgressbar());
    $royalwidgets->register(new Widgets\RoyalContentSlider());
    $royalwidgets->register(new Widgets\RoyalPostCarousel());
    $royalwidgets->register(new Widgets\RoyalImageCarousel());
    $royalwidgets->register(new Widgets\RoyalTestimonialCarousel());
    $royalwidgets->register(new Widgets\RoyalProfileCard());
    $royalwidgets->register(new Widgets\RoyalSourceCode());
    $royalwidgets->register(new Widgets\RoyalCountdown());
    $royalwidgets->register(new Widgets\RoyalTimeline());


    
    if (! function_exists( 'is_woocommerce_activated' ) ) {
    $royalwidgets->register(new Widgets\RoyalWooProductsGrid());  
    $royalwidgets->register(new Widgets\RoyalWooMiniCart());  
    }

    


  }



  public function add_category() {
      \Elementor\Plugin::instance()->elements_manager->add_category(
          'royaltech',
          array(
              'title' => __('Royal Technologies', 'royaltech'),
              'icon'  => 'fa fa-plug',
          )
        );
  }  




}

ROYAL_Widget_Loader::instance();