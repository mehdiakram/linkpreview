<?php

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class RoyalWrapperLink {
	
	public function __construct() {
		add_action( 'elementor/element/section/_section_responsive/after_section_end', [ $this, 'royal_wrapper_link' ], 10, 2 );
		add_action( 'elementor/element/column/_section_responsive/after_section_end', [ $this, 'royal_wrapper_link' ], 10, 2 );
		add_action( 'elementor/element/common/section_custom_css_pro/after_section_end', [ $this, 'royal_wrapper_link' ], 10, 2 );
		add_action( 'elementor/frontend/before_render', [ $this, 'wrapperlink_before_render'], 10, 1 );	
	}
	
	public function get_name() {
		return 'royalwrapperlink';
	}
	
	public function royal_wrapper_link($element) {		
		$element->start_controls_section(
			'royalwrapperlinksection',
			[
				'label' => esc_html__( 'Wrapper Link [Royal]', 'royaltech' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);
		$element->add_control(
			'wrapper_link_switch',
			[
				'label'        => esc_html__( 'Link', 'royaltech' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' 		=> 'no',
			]
		);
		$element->add_control(
			'wrapper_link',
			[
				'label' => esc_html__( 'Your Link', 'royaltech' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],				
				'placeholder' => esc_html__( 'https://www.demo-link.com', 'royaltech' ),
				'condition' => [
					'wrapper_link_switch' => 'yes',
				],
			]
		);
		$element->end_controls_section();
	}


	public function wrapperlink_before_render($element) {		
		$settings = $element->get_settings();
		$settings = $element->get_settings_for_display();
		if((!empty($settings['wrapper_link_switch']) && $settings['wrapper_link_switch']=='yes') && !empty($settings['wrapper_link'])){			
			$element->add_render_attribute( '_wrapper', 
			array(			
				'data-tp-sc-link' => $settings['wrapper_link']['url'],
				'data-tp-sc-link-external' => $settings['wrapper_link']['is_external'],
				'style' => 'cursor: pointer'
			) );
		}
	
	}
}

new RoyalWrapperLink();