<?php
/*
 * Plugin Name: Royal Addons for Elementor
 * Description: Royal Addons for Elementor is one of the best Elementor addons comes with free Elementor widgets & custom css feature.
 * Version: 22.1.26
 * Author: Royal Technologies
 * Author URI: https://royaltechbd.com/
 * Text Domain: royaltech
 * Domain Path: /languages/
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Elementor tested up to: 3.5
 * Elementor Pro tested up to: 3.5
 */



defined('ABSPATH') || exit; // Exit if accessed directly
define('ROYALADDONSURL', plugin_dir_url(__FILE__));
define('ROYALADDONSDIR ', plugin_dir_url(__DIR__));
define('ROYALADDONSPATH', plugin_dir_path(__FILE__));



function royal_addons_for_elementor_mime_types($mimes) {
	$mimes['json'] = 'application/json'; 
	$mimes['svg'] = 'image/svg+xml'; 
	return $mimes; 
  } 
add_filter('upload_mimes', 'royal_addons_for_elementor_mime_types');

function disable_elementor_from_dashboard_widget() {
	remove_meta_box( 'e-dashboard-overview', 'dashboard', 'normal');
}
add_action('wp_dashboard_setup', 'disable_elementor_from_dashboard_widget', 40);



add_image_size( 'royalimage1140X570', 1140, 570, true );
add_image_size( 'royalimage600X600', 600, 600, true );
add_image_size( 'royalimage1400X560', 1400, 560, true );



final class Royal_Addons_for_Elementor {
	// const VERSION = '1.2.1';
	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';
	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {

		// Extra meta for plugin row
		add_filter( 'plugin_row_meta', [ $this, 'royal_addons_for_elementor_plugin_row_meta' ], 10, 2 );
		
		// Extra plugin action
		add_filter( 'plugin_action_links', [ $this, 'royal_addons_for_elementor_plugin_action_links' ], 1, 2 );

		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );

		
	}


	function royal_addons_for_elementor_plugin_row_meta( $links_array, $plugin_file_name ) {
		if ( strpos( $plugin_file_name, basename(__FILE__) ) ) {
			$links_array[] = '<a href="https://www.royaltechbd.com/product/royal-addons-for-elementor/" target="_blank">Plugin Details</a>';
			$links_array[] = '<a href="https://www.messenger.com/t/190720437675055" target="_blank">FB Chat</a>';
		}
		return $links_array;
	}


	function royal_addons_for_elementor_plugin_action_links( $links_array, $plugin_file_name ) {
		if ( strpos( $plugin_file_name, basename(__FILE__) ) ) {
			$links_array[] = '<a href="plugins.php?page=royal_addons_for_elementor_page/">Settings</a>';
		}
		return $links_array;
	}
	

	public function i18n() {
		load_plugin_textdomain( 'royaltech' );
	}


	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_missing_main_plugin' ) );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
			return;
		}




		/* Royal Options Menu */
		add_action( 'admin_menu', 'royaltech_mainside_menu_for_royal_addons_for_elementor' );
		function royaltech_mainside_menu_for_royal_addons_for_elementor() {

			$royalthemevac			='2dfa98f7b0914c782eddcbd52a27dd0b';
            $royalthemeget 			= wp_get_theme();
			$royalthemeuri 			= $royalthemeget->get( 'ThemeURI' );
			$royalthemeurl     		= str_replace("www.", "", $royalthemeuri);
			$royalthemeurl 			= preg_replace("(^https?://)", "", $royalthemeurl );
			$royalthemesecret       = "_royal";
			$royalthemefull     	= $royalthemeurl.$royalthemesecret;
			$royalthemevaccined 	= md5($royalthemefull);				

			if ($royalthemevac == $royalthemevaccined) {
				
			} else {
				add_menu_page( 
					'Royal Addons',
					'Royal Addons',
					'manage_options',
					'royaladdonsforelementor',
					'royal_addons_for_elementor_page_contents',
					'',
					66
				); 
	
			}

		}
		function royal_addons_for_elementor_page_info() {


		}

		function royal_addons_for_elementor_page_contents() {
		?>
		<h2>Royal Addons for Elementor Settings</h2>
		<form action="options.php" method="post">
			<?php 
			settings_fields( 'royal_addons_for_elementor_plugin_settings' );
			do_settings_sections( 'royal_addons_for_elementor_plugin_page' );
			?>
			<input
			type="submit"
			name="submit"
			class="button button-primary"
			value="<?php esc_attr_e( 'Save License Key' ); ?>"
			/>
		</form>
		If have no License Key, <a href="https://www.royaltechbd.com/" target="_blank"> Please conact</a>
		<?php
		}


		function royal_addons_for_elementor_register_settings() {
			register_setting(
			'royal_addons_for_elementor_plugin_settings',
			'royal_addons_for_elementor_plugin_settings',
			'royal_addons_for_elementor_plugin_validate_settings'
			);
		
			add_settings_section(
			'section_one',
			'Section One',
			'royal_addons_for_elementor_section_one',
			'royal_addons_for_elementor_plugin_page'
			);
		
			add_settings_field(
			'covid19_field',
			'Plugin License Key',
			'royal_addons_for_elementor_render_key',
			'royal_addons_for_elementor_plugin_page',
			'section_one'
			);
		

		}
		add_action( 'admin_init', 'royal_addons_for_elementor_register_settings' );


		function royal_addons_for_elementor_plugin_validate_settings( $input ) {
			$output['covid19_field']      = sanitize_text_field( $input['covid19_field'] );
			return $output;
		}


		function royal_addons_for_elementor_section_one() {
			echo '<p>License Section.</p>';
		}
		
		function royal_addons_for_elementor_render_key() {
			$options = get_option( 'royal_addons_for_elementor_plugin_settings' );
			if ( empty( $options['covid19_field'] ) ) {
				$options['covid19_field'] = "No License Key";
			}

			printf(
				'<input type="text" name="%s" value="%s" />',
				esc_attr( 'royal_addons_for_elementor_plugin_settings[covid19_field]' ),
				esc_attr( $options['covid19_field'] )
			);
		}


		/* Vaccine */
		function pluginvaccine() {
			$pluginoptions 	= get_option( 'royal_addons_for_elementor_plugin_settings' );
			$pluginvaccine  = $pluginoptions['covid19_field'];
			$httphost     	= str_replace("www.", "", $_SERVER['HTTP_HOST']);
			$secret       	= "_royal";
			$pluginfull     = $httphost.$secret;
			$pluginvaccined = md5($pluginfull);

			$royalthemevac			='2dfa98f7b0914c782eddcbd52a27dd0b';
            $royalthemeget 			= wp_get_theme();
			$royalthemeuri 			= $royalthemeget->get( 'ThemeURI' );
			$royalthemeurl     		= str_replace("www.", "", $royalthemeuri);
			$royalthemeurl 			= preg_replace("(^https?://)", "", $royalthemeurl );
			$royalthemesecret       = "_royal";
			$royalthemefull     	= $royalthemeurl.$royalthemesecret;
			$royalthemevaccined 	= md5($royalthemefull);
			
			
			if ($pluginvaccine == $pluginvaccined || $royalthemevac == $royalthemevaccined) {
			require 'elementor.php';
			}
		}
		add_action( 'after_setup_theme', 'pluginvaccine' );
		/* Vaccine Complete */

		}


	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'royaltech' ),
			'<strong>' . esc_html__( 'Royal Addons for Elementor', 'royaltech' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'royaltech' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}


	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'royaltech' ),
			'<strong>' . esc_html__( 'Royal Addons for Elementor', 'royaltech' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'royaltech' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}


	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'royaltech' ),
			'<strong>' . esc_html__( 'Royal Addons for Elementor', 'royaltech' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'royaltech' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}
}

// Instantiate Royal_Addons_for_Elementor.
new Royal_Addons_for_Elementor();


