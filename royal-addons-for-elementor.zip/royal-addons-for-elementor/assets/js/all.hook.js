window.Royal = window.Royal || {};

(function ($, Royal, w) {
  var $window = $(w);
    $window.on("elementor/frontend/init", function () {

    var RoyalTimelineHandler = function TimeLine($scope) {
      var T_ID = $scope.data("id");
      var timeline = $scope.find(".ha-timeline-wrap");
      var dataScroll = timeline.data("scroll");
      var timeline_block = timeline.find(".ha-timeline-block");
      var event = "scroll.timelineScroll" + T_ID + " resize.timelineScroll" + T_ID;

      function scroll_tree() {
        timeline_block.each(function () {
          var block_height = $(this).outerHeight(true);
          var $offsetTop = $(this).offset().top;
          var window_middle_p = $window.scrollTop() + $window.height() / 2;

          if ($offsetTop < window_middle_p) {
            $(this).addClass("ha-timeline-scroll-tree");
          } else {
            $(this).removeClass("ha-timeline-scroll-tree");
          }

          var scroll_tree_wrap = $(this).find(".ha-timeline-tree-inner");
          var scroll_height = $window.scrollTop() - scroll_tree_wrap.offset().top + $window.outerHeight() / 2;

          if ($offsetTop < window_middle_p && timeline_block.hasClass("ha-timeline-scroll-tree")) {
            if (block_height > scroll_height) {
              scroll_tree_wrap.css({
                height: scroll_height * 1.5 + "px"
              });
            } else {
              scroll_tree_wrap.css({
                height: block_height * 1.2 + "px"
              });
            }
          } else {
            scroll_tree_wrap.css("height", "0px");
          }
        });
      }

      if ("yes" === dataScroll) {
        scroll_tree();
        $window.on(event, scroll_tree);
      } else {
        $window.off(event);
      }
    };
 
    elementorFrontend.hooks.addAction("frontend/element_ready/royaltimeline.default", RoyalTimelineHandler);
    /* RoyalTimeline End*/



    var RoyalCarouselHandler = function( $scope, $ ) {
      var $_this = $scope.find('.royalcarousel');
      var $currentID          = '#'+$_this.attr('id'),
          $loop               = $_this.data('loop'),
          $autoplay           = $_this.data('autoplay'),
          $margin             = $_this.data('margin'),
          $autoplaytimeout    = $_this.data('timeout'),
          $navtext            = $_this.data('navtext'),

          $desktopitems       = $_this.data('desktopitems'),
          $desktopdots        = $_this.data('desktopdots'),
          $desktopnav         = $_this.data('desktopnav'),

          $tabitems           = $_this.data('tabitems'),
          $tabdots            = $_this.data('tabdots'),
          $tabnav             = $_this.data('tabnav'),

          $mobileitems        = $_this.data('mobileitems'),
          $mobiledots         = $_this.data('mobiledots'),
          $mobilenav          = $_this.data('mobilenav');



      var owl = $( $currentID );
      owl.owlCarousel({
          autoplay            : $autoplay,
          loop                : $loop,
          margin              : $margin,
          autoplayTimeout     : $autoplaytimeout,
          navText             : $navtext,
          responsive  :{
              0:{
                  items:$mobileitems,
                  dots:$mobiledots,
                  nav:$mobilenav
              },
              600:{
                  items:$tabitems,
                  dots:$tabdots,
                  nav:$tabnav
              },
              1000:{
                  items:$desktopitems,
                  dots:$desktopdots,
                  nav:$desktopnav
              }
          }
      })
  }
  elementorFrontend.hooks.addAction('frontend/element_ready/royalpostcarousel.default', RoyalCarouselHandler);
  elementorFrontend.hooks.addAction('frontend/element_ready/royalimagecarousel.default', RoyalCarouselHandler);
  elementorFrontend.hooks.addAction('frontend/element_ready/royalcontentslider.default', RoyalCarouselHandler);
  elementorFrontend.hooks.addAction('frontend/element_ready/royaltestimonialcarousel.default', RoyalCarouselHandler);
  /* RoyalCarousel End*/




	var RoyalFlipBoxHandler = function( $scope, $ ) {
		$('.tp-flipbox').each(function(){
			var me = $(this);
			var tp_fb_holder         = me.find('.tp-flipbox__holder');
			var tp_fb_content_height = me.find(".tp-flipbox__content").height();
			var tp_fb_front_height   = me.find(".tp-flipbox__front .tp-flipbox__content").height();
			var tp_fb_back_height    = me.find(".tp-flipbox__back .tp-flipbox__content").height();


			if(tp_fb_back_height > tp_fb_front_height){
				tp_fb_holder.css("min-height",tp_fb_back_height);
			}
			if(tp_fb_back_height < tp_fb_front_height){
				tp_fb_holder.css("min-height",tp_fb_front_height);
			}

		});
	};
  elementorFrontend.hooks.addAction( 'frontend/element_ready/royalflipbox.default', RoyalFlipBoxHandler);
  /* RoyalFlipBox End*/




  var RoyalSourceCodeHandler = function SourceCode($scope) {
    var $item = $scope.find(".royal-source-code");
    var $lng_type = $item.data("lng-type");
    var $after_copy_text = $item.data("after-copy");
    var $code = $item.find("code.language-" + $lng_type);
    var $copy_btn = $scope.find(".royal-copy-code-button");
    $copy_btn.on("click", function () {
      var $temp = $("<textarea>");
      $(this).append($temp);
      $temp.val($code.text()).select();
      document.execCommand("copy");
      $temp.remove();

      if ($after_copy_text.length) {
        $(this).text($after_copy_text);
      }
    });

    if ($lng_type !== undefined && $code !== undefined) {
      Prism.highlightElement($code.get(0));
    }
  }; 
  elementorFrontend.hooks.addAction("frontend/element_ready/royalsourcecode.default", RoyalSourceCodeHandler);
  /* RoyalSourceCode End*/




  var RoyalCountdownHandler = function CountDown($scope) {
    var $item = $scope.find(".royal-countdown");
    var $countdown_item = $item.find(".royal-countdown-item");
    var $end_action = $item.data("end-action");
    var $redirect_link = $item.data("redirect-link");
    var $end_action_div = $item.find(".royal-countdown-end-action");
    var $editor_mode_on = $scope.hasClass("elementor-element-edit-mode");
    $item.countdown({
      end: function end() {
        if (("message" === $end_action || "img" === $end_action) && $end_action_div !== undefined) {
          $countdown_item.css("display", "none");
          $end_action_div.css("display", "block");
        } else if ("url" === $end_action && $redirect_link !== undefined && $editor_mode_on !== true) {
          window.location.replace($redirect_link);
        }
      }
    });
  };
  elementorFrontend.hooks.addAction( 'frontend/element_ready/royalcountdown.default', RoyalCountdownHandler );
  /* RoyalCountdown End*/





  });
})(jQuery, Royal, window);