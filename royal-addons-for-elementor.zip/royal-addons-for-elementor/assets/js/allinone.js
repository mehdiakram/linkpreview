
/* Royal Equal Height Start ---------------------------------*/
( function ( $ ) {	
    $.fn.equalHeights = function() {
      var max_height = 0;
      $(this).each(function() {
        max_height = Math.max($(this).outerHeight(), max_height);
      });
      $(this).each(function() {
        $(this).css('min-height',max_height);
      });
    };
    
    $(document).ready(function() {
        var container = $('.elementor-element[data-tp-equal-height-loadded]');
        if(container.length){
            container.each(function() {
                var id = $(this).data('id');
                var new_find = $(this).data('tp-equal-height-loadded');
                $('.elementor-element-'+id +' '+ new_find).equalHeights();
            });	
        }
        
    });
    $(window).on("load resize",function() {
        var container = $('.elementor-element[data-tp-equal-height-loadded]');
        if(container.length){
            container.each(function() {
                var id = $(this).data('id');
                var new_find = $(this).data('tp-equal-height-loadded');
                $('.elementor-element-'+id +' '+ new_find).equalHeights();
            });	
        }
    });
    } ( jQuery ) );
/* Royal Equal Height End ---------------------------------*/




/* Royal Wrapper Link Start ---------------------------------*/
jQuery(document).ready(function( $ ) {
	$(document).on('click','[data-tp-sc-link]',function() {
		/*Get Attributes*/
		var tp_sc_link = $(this).data('tp-sc-link'),
			tp_sc_link_external = $(this).data('tp-sc-link-external'),
			addlink = '<a href="' + tp_sc_link + '" data-tp-sc-link-add style="display:none"></a>';
		/*Get Attributes*/
		
		/*Open in new window*/
		if(tp_sc_link_external == 'on') {
			addlink = '<a href="' + tp_sc_link + '" target="_blank" data-tp-sc-link-add style="display:none"></a>';
		}
		/*Open in new window*/
		
		/*length*/
		if ($(this).find('[data-tp-sc-link-add]').length == 0) {
			$(this).append(addlink);
		}
		/*length*/
		
		var firelink = $(this).find('[data-tp-sc-link-add]');
		firelink[0].click();	
	});
});
/* Royal Wrapper Link End ---------------------------------*/













/* Royal Search Overly Start ---------------------------------*/
jQuery(document).ready(function($) {
    var opensearchoverly = function(){
        $(".royalsearchoverly").addClass("displayblock");
    }
    
    var closesearchoverly = function(){
        $(".royalsearchoverly").removeClass("displayblock");
    }
    
        
    $('.royalsearchicon').click( function(event) {
        event.stopPropagation();
        $(this).is('.displayblock') ? closesearchoverly() : opensearchoverly();
    });
    

    $('.royalsearchoverly .closebtn').click( function(event) {
        event.stopPropagation();
        $(this).is('.displayblock') ? opensearchoverly() : closesearchoverly();
    });

    
    $(document).click( function(event){
        if ( !$(event.target).closest('.royalsearchoverly').length ) {
            closesearchoverly();   
        }
    });
    });
/* Royal Search Overly End --------------------------------- */ 
    






/*Royal Mobile Menu Start ---------------------------------*/
jQuery.noConflict();
(function( $ ) {
    $(function() {
        // More code using $ as alias to jQuery
        $(function(){
            var $ul   =   $('.royalmobilemenu');
            
            $ul.find('li a').click(function(e){
            var $li = $(this).parent();
            
            if($li.find('ul').length > 0){
                e.preventDefault();
                
                if($li.hasClass('selected')){
                $li.removeClass('selected').find('li').removeClass('selected');
                $li.find('ul').slideUp(400);
                }else{
                
                if($li.parents('li.selected').length == 0){
                    $ul.find('li').removeClass('selected');
                    $ul.find('ul').slideUp(400);
                }else{
                    $li.parent().find('li').removeClass('selected');
                    $li.parent().find('> li ul').slideUp(400);
                }
                
                $li.addClass('selected');
                $li.find('>ul').slideDown(400);
                }
            }
            });
            
            
            $('.royalmobilemenu ul').each(function(i){
            if($(this).find('>li>ul').length > 0){
                var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
                var pIntPLeft   = parseInt(paddingLeft);
                var result      = pIntPLeft + 10;
                
                $(this).find('>li>a').css('padding-left',result);
            }else{
                var paddingLeft = $(this).parent().parent().find('>li>a').css('padding-left');
                var pIntPLeft   = parseInt(paddingLeft);
                var result      = pIntPLeft + 10;
                
                $(this).find('>li>a').css('padding-left',result).parent().addClass('selected--last');
            }
            });
            
            
            var activeLi = $('li.selected');
            if(activeLi.length){
            opener(activeLi);
            }
            
            function opener(li){
            var ul = li.closest('ul');
            if(ul.length){
                
                li.addClass('selected');
                ul.addClass('open');
                
                if(ul.closest('li').length){
                opener(ul.closest('li'));
                }else{
                return false;
                }
                
            }
            }
            
        });  
        // More code using $ as alias to jQuery
    });
})(jQuery);



/* Royal Mobile Menu Start ---------------------------------*/ 
jQuery(document).ready(function($) {
var openMobileMenu = function(){
    $(".royalmobilemenucontainer").addClass("displayblock");
}

var closeMobileMenu = function(){
    $(".royalmobilemenucontainer").removeClass("displayblock");
}


$('.royalmobilemenushow').click( function(event) {
    event.stopPropagation();
    $(this).is('.displayblock') ? closeMobileMenu() : openMobileMenu();
});


$('.royalmobilemenucontainer .close').click( function(event) {
    event.stopPropagation();
    $(this).is('.displayblock') ? openMobileMenu() : closeMobileMenu();
});


$(document).click( function(event){
    if ( !$(event.target).closest('.royalmobilemenucontainer').length ) {
        closeMobileMenu();   
    }
});

});
/* Royal Mobile Menu End ---------------------------------*/ 







/* Royal Cart Start  ---------------------------------*/
jQuery(document).ready(function($) {
    var openMobileMenu = function(){
        $(".royalwoocartcontainer").addClass("displayblock");
    }
    
    var closeMobileMenu = function(){
        $(".royalwoocartcontainer").removeClass("displayblock");
    }
    
    
    $('.royalwoocartshow').click( function(event) {
        event.stopPropagation();
        $(this).is('.displayblock') ? closeMobileMenu() : openMobileMenu();
    });
    
    
    $('.royalwoocartcontainer .close').click( function(event) {
        event.stopPropagation();
        $(this).is('.displayblock') ? openMobileMenu() : closeMobileMenu();
    });
    
    
    $(document).click( function(event){
        if ( !$(event.target).closest('.royalwoocartcontainer').length ) {
            closeMobileMenu();   
        }
    });
    
    });
/* Royal Cart End  ---------------------------------*/







