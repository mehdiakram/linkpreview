<?php
namespace RoyalAddons\Elementor;

class RoyalClass {

	public static function royal_categories( $post_type ) {
		$options = array();
		$taxonomy = 'category';
		if ( ! empty( $taxonomy ) ) {
			// Get categories for post type.
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
			if ( ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( isset( $term ) ) {
						if ( isset( $term->slug ) && isset( $term->name ) ) {
							$options[ $term->slug ] = $term->name;
						}
					}
				}
			}
		}
		return $options;
	}


	public static function royal_button_sizes() {
		return [
			'xs' => __( 'Extra Small', 'modal-for-elementor' ),
			'sm' => __( 'Small', 'modal-for-elementor' ),
			'md' => __( 'Medium', 'modal-for-elementor' ),
			'lg' => __( 'Large', 'modal-for-elementor' ),
			'xl' => __( 'Extra Large', 'modal-for-elementor' ),
		];
	}


	public static function royal_post_types ( $args = array(), $output = 'names', $operator = 'and' ) {
		global $wp_post_types;
		$field = ('names' == $output) ? 'name' : false;
		return wp_filter_object_list($wp_post_types, $args, $operator, $field);
	}



	
	public static function get_terms_options( $taxonomy = 'category' ) {
		$terms = konte_addons_get_terms_hierarchy( $taxonomy, '&#8212;' );

		if ( empty( $terms ) ) {
			return [];
		}

		$options = wp_list_pluck( $terms, 'name', 'slug' );

		return $options;
	}




	/* Dynamic Excerpt Limit */
	public static function royalpostexcerpt($limit = '100', $echo = true) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		if (count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
		} else {
		$excerpt = implode(" ",$excerpt);
		} 
		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);

		if ( $echo ) {
			echo $excerpt;
		} else {
			return $arrows;
		}

		return $excerpt;
	}


	/* Dynamic Content Limit */
	public static function royalpostcontent($limit) {
		$content = explode(' ', get_the_content(), $limit);
		if (count($content)>=$limit) {
		array_pop($content);
		$content = implode(" ",$content).'...';
		} else {
		$content = implode(" ",$content);
		} 
		$content = preg_replace('/\[.+\]/','', $content);
		$content = apply_filters('the_content', $content); 
		$content = str_replace(']]>', ']]&gt;', $content);
		return $content;
	}



	public static function royal_users() {
		$users = [];		
		foreach ( get_users() as $key => $user ) {
			$users[$user->data->ID] = $user->data->user_nicename;
		}		
		wp_reset_postdata();
		return $users;
	}



	function royal_elementor_templates(){
		$page_templates = get_posts( [
			'post_type'         => 'elementor_library',
			'posts_per_page'    => -1
		] );
	
		$options = [];
	
		if ( ! empty( $page_templates ) && ! is_wp_error( $page_templates ) ){
			foreach ( $page_templates as $template ) {
				$options[ $template->ID ] = $template->post_title;
			}
		}
		return $options;
	}



	function royal_any_post_type($posttype){
		$page_templates = get_posts( [
			'post_type'         => $posttype,
			'posts_per_page'    => -1
		] );
	
		$options = [];
	
		if ( ! empty( $page_templates ) && ! is_wp_error( $page_templates ) ){
			foreach ( $page_templates as $template ) {
				$options[ $template->ID ] = $template->post_title;
			}
		}
		return $options;
	}









	function royal_ext_html_tags( $tag ) {
		$allowed_tags = [
			'h1',
			'h2',
			'h3',
			'h4',
			'h5',
			'h6',
			'p',
		];
		return in_array( strtolower( $tag ), $allowed_tags ) ? $tag : 'h2';
	}
	



	public static function animation_in() {
		return [
			'none' => esc_html__( 'None', 'sina-ext' ),
			'fadeIn' => esc_html__( 'Fade In', 'sina-ext' ),
			'fadeInUp' => esc_html__( 'Fade In Up', 'sina-ext' ),
			'fadeInDown' => esc_html__( 'Fade In Down', 'sina-ext' ),
			'fadeInLeft' => esc_html__( 'Fade In Left', 'sina-ext' ),
			'fadeInRight' => esc_html__( 'Fade In Right', 'sina-ext' ),
			'zoomIn' => esc_html__('Zoom In', 'sina-ext'),
			'zoomInLeft' => esc_html__('Zoom In Left', 'sina-ext'),
			'zoomInRight' => esc_html__('Zoom In Right', 'sina-ext'),
			'zoomInDown' => esc_html__('Zoom In Down', 'sina-ext'),
			'zoomInUp' => esc_html__('Zoom In Up', 'sina-ext'),
			'bounce' => esc_html__('Bounce', 'sina-ext'),
			'bounceIn' => esc_html__('Bounce In', 'sina-ext'),
			'bounceInDown' => esc_html__('Bounce In Down', 'sina-ext'),
			'bounceInLeft' => esc_html__('Bounce In Left', 'sina-ext'),
			'bounceInRight' => esc_html__('Bounce In Right', 'sina-ext'),
			'bounceInUp' => esc_html__('Bounce In Up', 'sina-ext'),
			'slideInDown' => esc_html__('Slide In Down', 'sina-ext'),
			'slideInLeft' => esc_html__('Slide In Left', 'sina-ext'),
			'slideInRight' => esc_html__('Slide In Right', 'sina-ext'),
			'slideInUp' => esc_html__('Slide In Up', 'sina-ext'),
			'rotateIn' => esc_html__('Rotate In', 'sina-ext'),
			'rotateInDownLeft' => esc_html__('Rotate In Down Left', 'sina-ext'),
			'rotateInDownRight' => esc_html__('Rotate In Down Right', 'sina-ext'),
			'rotateInUpLeft' => esc_html__('Rotate In Up Left', 'sina-ext'),
			'rotateInUpRight' => esc_html__('Rotate In Up Right', 'sina-ext'),
			'flipInX' => esc_html__( 'Flip In X', 'sina-ext' ),
			'flipInY' => esc_html__( 'Flip In Y', 'sina-ext' ),
			'lightSpeedIn' => esc_html__('Light Speed In', 'sina-ext'),
			'swing' => esc_html__( 'Swing', 'sina-ext' ),
			'flash' => esc_html__('Flash', 'sina-ext'),
			'pulse' => esc_html__('Pulse', 'sina-ext'),
			'rubberBand' => esc_html__('Rubber Band', 'sina-ext'),
			'shake' => esc_html__('Shake', 'sina-ext'),
			'headShake' => esc_html__('Head Shake', 'sina-ext'),
			'swing' => esc_html__('Swing', 'sina-ext'),
			'tada' => esc_html__('Tada', 'sina-ext'),
			'wobble' => esc_html__('Wobble', 'sina-ext'),
			'jello' => esc_html__('Jello', 'sina-ext'),
			'rollIn' => esc_html__('Roll In', 'sina-ext'),
		];
	}


	
	public static function animation_out() {
		return [
			'none' => esc_html__( 'None', 'sina-ext' ),
			'fadeOut' => esc_html__( 'Fade Out', 'sina-ext' ),
			'fadeOutUp' => esc_html__( 'Fade Out Up', 'sina-ext' ),
			'fadeOutDown' => esc_html__( 'Fade Out Down', 'sina-ext' ),
			'fadeOutLeft' => esc_html__( 'Fade Out Left', 'sina-ext' ),
			'fadeOutRight' => esc_html__( 'Fade Out Right', 'sina-ext' ),
			'zoomOut' => esc_html__('Zoom Out', 'sina-ext'),
			'zoomOutLeft' => esc_html__('Zoom Out Left', 'sina-ext'),
			'zoomOutRight' => esc_html__('Zoom Out Right', 'sina-ext'),
			'zoomOutDown' => esc_html__('Zoom Out Down', 'sina-ext'),
			'zoomOutUp' => esc_html__('Zoom Out Up', 'sina-ext'),
			'bounceOut' => esc_html__('Bounce Out', 'sina-ext'),
			'bounceOutDown' => esc_html__('Bounce Out Down', 'sina-ext'),
			'bounceOutLeft' => esc_html__('Bounce Out Left', 'sina-ext'),
			'bounceOutRight' => esc_html__('Bounce Out Right', 'sina-ext'),
			'bounceOutUp' => esc_html__('Bounce Out Up', 'sina-ext'),
			'slideOutDown' => esc_html__('Slide Out Down', 'sina-ext'),
			'slideOutLeft' => esc_html__('Slide Out Left', 'sina-ext'),
			'slideOutRight' => esc_html__('Slide Out Right', 'sina-ext'),
			'slideOutUp' => esc_html__('Slide Out Up', 'sina-ext'),
			'rotateOut' => esc_html__('Rotate Out', 'sina-ext'),
			'rotateOutDownLeft' => esc_html__('Rotate Out Down Left', 'sina-ext'),
			'rotateOutDownRight' => esc_html__('Rotate Out Down Right', 'sina-ext'),
			'rotateOutUpLeft' => esc_html__('Rotate Out Up Left', 'sina-ext'),
			'rotateOutUpRight' => esc_html__('Rotate Out Up Right', 'sina-ext'),
			'flipOutX' => esc_html__( 'Flip Out X', 'sina-ext' ),
			'flipOutY' => esc_html__( 'Flip Out Y', 'sina-ext' ),
			'lightSpeedOut' => esc_html__('Light Speed Out', 'sina-ext'),
			'rollOut' => esc_html__('Roll Out', 'sina-ext'),
		];
	}














	public static function carousel_pagination( $echo = true ) {
		$pagination = '<div class="konte-carousel__pagination swiper-pagination"></div>';

		if ( $echo ) {
			echo $pagination;
		} else {
			return $pagination;
		}
	}


	public static function carousel_navigation( $type = 'angle', $echo = true ) {
		switch ( $type ) {
			case 'arrow':
				$left  = 'arrow-left';
				$right = 'arrow-left';
				break;

			default:
				$left  = 'left';
				$right = 'right';
				break;
		}

		$arrows = [
			'left' => '<div class="konte-carousel__arrow konte-carousel-navigation--' . esc_attr( $type ) . ' konte-carousel-navigation--prev">
						<span class="svg-icon icon-' . esc_attr( $left ) . '"><svg><use xlink:href="#' . esc_attr( $left ) . '"></use></svg></span>
					</div>',
			'right' => '<div class="konte-carousel__arrow konte-carousel-navigation--' . esc_attr( $type ) . ' konte-carousel-navigation--next">
						<span class="svg-icon icon-' . esc_attr( $right ) . '"><svg><use xlink:href="#' . esc_attr( $right ) . '"></use></svg></span>
					</div>',
		];

		if ( $echo ) {
			echo implode( '', $arrows );
		} else {
			return $arrows;
		}
	}
}



function konte_addons_get_terms_hierarchy( $taxonomy = 'category', $separator = '-' ) {
	$terms = get_terms( array(
		'taxonomy'   => $taxonomy,
		'hide_empty' => true,
		'update_term_meta_cache' => false,
	) );

	if ( ! $terms || is_wp_error( $terms ) ) {
		return array();
	}

	$taxonomy = get_taxonomy( $taxonomy );

	if ( $taxonomy->hierarchical ) {
		$terms = konte_addons_sort_terms_hierarchy( $terms );
		$terms = konte_addons_flatten_hierarchy_terms( $terms, $separator );
	}

	return $terms;
}


function konte_addons_flatten_hierarchy_terms( $terms, $separator = '&mdash;', $depth = 0 ) {
	$flatted = array();

	foreach ( $terms as $term ) {
		$children = array();

		if ( ! empty( $term->children ) ) {
			$children = $term->children;
			$term->has_children = true;
			unset( $term->children );
		}

		$term->depth = $depth;
		$term->name = $depth && $separator ? str_repeat( $separator, $depth ) . ' ' . $term->name : $term->name;
		$flatted[] = $term;

		if ( ! empty( $children ) ) {
			$flatted = array_merge( $flatted, konte_addons_flatten_hierarchy_terms( $children, $separator, ++$depth ) );
			$depth--;
		}
	}

	return $flatted;
}








function konte_addons_sort_terms_hierarchy( $terms, $parent_id = 0 ) {
	$hierarchy = array();

	foreach ( $terms as $term ) {
		if ( $term->parent == $parent_id ) {
			$term->children = konte_addons_sort_terms_hierarchy( $terms, $term->term_id );
			$hierarchy[] = $term;
		}
	}

	return $hierarchy;
}













