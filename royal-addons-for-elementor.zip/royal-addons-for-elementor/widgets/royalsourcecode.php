<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;

defined('ABSPATH') || die();

class RoyalSourceCode extends Widget_Base {
	public function get_name() {
		return 'royalsourcecode';
	}

	public function get_title() {
		return __('Royal Source Code', 'royaltechbd');
	}


	public function get_icon() {
		return 'royalicon eicon-code-highlight';
	}


	public function get_keywords() {
		return ['RoyalSourceCode', 'source-code', 'source', 'code', 'highlight', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}

	
	public function get_style_depends() {
		$styles = [ 'prism', 'royalsourcecode'];
		return $styles;
	}

	public function get_script_depends() {
		$scripts = ['prism'];
		return $scripts;
	}


	public function lng_type() {
		return [
			'markup' => __('HTML Markup', 'royaltechbd'),
			'css' => __('CSS', 'royaltechbd'),
			'clike' => __('Clike', 'royaltechbd'),
			'javascript' => __('JavaScript', 'royaltechbd'),
			'abap' => __('ABAP', 'royaltechbd'),
			'abnf' => __('Augmented Backus–Naur form', 'royaltechbd'),
			'actionscript' => __('ActionScript', 'royaltechbd'),
			'ada' => __('Ada', 'royaltechbd'),
			'apacheconf' => __('Apache Configuration', 'royaltechbd'),
			'apl' => __('APL', 'royaltechbd'),
			'applescript' => __('AppleScript', 'royaltechbd'),
			'arduino' => __('Arduino', 'royaltechbd'),
			'arff' => __('ARFF', 'royaltechbd'),
			'asciidoc' => __('AsciiDoc', 'royaltechbd'),
			'asm6502' => __('6502 Assembly', 'royaltechbd'),
			'aspnet' => __('ASP.NET (C#)', 'royaltechbd'),
			'autohotkey' => __('AutoHotkey', 'royaltechbd'),
			'autoit' => __('Autoit', 'royaltechbd'),
			'bash' => __('Bash', 'royaltechbd'),
			'basic' => __('BASIC', 'royaltechbd'),
			'batch' => __('Batch', 'royaltechbd'),
			'bison' => __('Bison', 'royaltechbd'),
			'bnf' => __('Bnf', 'royaltechbd'),
			'brainfuck' => __('Brainfuck', 'royaltechbd'),
			'bro' => __('Bro', 'royaltechbd'),
			'c' => __('C', 'royaltechbd'),
			'csharp' => __('Csharp', 'royaltechbd'),
			'cpp' => __('Cpp', 'royaltechbd'),
			'cil' => __('Cil', 'royaltechbd'),
			'coffeescript' => __('Coffeescript', 'royaltechbd'),
			'cmake' => __('Cmake', 'royaltechbd'),
			'clojure' => __('Clojure', 'royaltechbd'),
			'crystal' => __('Crystal', 'royaltechbd'),
			'csp' => __('Csp', 'royaltechbd'),
			'css-extras' => __('Css-extras', 'royaltechbd'),
			'd' => __('D', 'royaltechbd'),
			'dart' => __('Dart', 'royaltechbd'),
			'diff' => __('Diff', 'royaltechbd'),
			'django' => __('Django', 'royaltechbd'),
			'dns-zone-file' => __('Dns-zone-file', 'royaltechbd'),
			'docker' => __('Docker', 'royaltechbd'),
			'ebnf' => __('Ebnf', 'royaltechbd'),
			'eiffel' => __('Eiffel', 'royaltechbd'),
			'ejs' => __('Ejs', 'royaltechbd'),
			'elixir' => __('Elixir', 'royaltechbd'),
			'elm' => __('Elm', 'royaltechbd'),
			'erb' => __('Erb', 'royaltechbd'),
			'erlang' => __('Erlang', 'royaltechbd'),
			'fsharp' => __('Fsharp', 'royaltechbd'),
			'firestore-security-rules' => __('Firestore-security-rules', 'royaltechbd'),
			'flow' => __('Flow', 'royaltechbd'),
			'fortran' => __('Fortran', 'royaltechbd'),
			'gcode' => __('Gcode', 'royaltechbd'),
			'gdscript' => __('Gdscript', 'royaltechbd'),
			'gedcom' => __('Gedcom', 'royaltechbd'),
			'gherkin' => __('Gherkin', 'royaltechbd'),
			'git' => __('Git', 'royaltechbd'),
			'glsl' => __('Glsl', 'royaltechbd'),
			'gml' => __('Gml', 'royaltechbd'),
			'go' => __('Go', 'royaltechbd'),
			'graphql' => __('Graphql', 'royaltechbd'),
			'groovy' => __('Groovy', 'royaltechbd'),
			'haml' => __('Haml', 'royaltechbd'),
			'handlebars' => __('Handlebars', 'royaltechbd'),
			'haskell' => __('Haskell', 'royaltechbd'),
			'haxe' => __('Haxe', 'royaltechbd'),
			'hcl' => __('Hcl', 'royaltechbd'),
			'http' => __('Http', 'royaltechbd'),
			'hpkp' => __('Hpkp', 'royaltechbd'),
			'hsts' => __('Hsts', 'royaltechbd'),
			'ichigojam' => __('Ichigojam', 'royaltechbd'),
			'icon' => __('Icon', 'royaltechbd'),
			'inform7' => __('Inform7', 'royaltechbd'),
			'ini' => __('Ini', 'royaltechbd'),
			'io' => __('Io', 'royaltechbd'),
			'j' => __('J', 'royaltechbd'),
			'java' => __('Java', 'royaltechbd'),
			'javadoc' => __('Javadoc', 'royaltechbd'),
			'javadoclike' => __('Javadoclike', 'royaltechbd'),
			'javastacktrace' => __('Javastacktrace', 'royaltechbd'),
			'jolie' => __('Jolie', 'royaltechbd'),
			'jq' => __('Jq', 'royaltechbd'),
			'jsdoc' => __('Jsdoc', 'royaltechbd'),
			'js-extras' => __('Js-extras', 'royaltechbd'),
			'js-templates' => __('Js-templates', 'royaltechbd'),
			'json' => __('Json', 'royaltechbd'),
			'jsonp' => __('Jsonp', 'royaltechbd'),
			'json5' => __('Json5', 'royaltechbd'),
			'julia' => __('Julia', 'royaltechbd'),
			'keyman' => __('Keyman', 'royaltechbd'),
			'kotlin' => __('Kotlin', 'royaltechbd'),
			'latex' => __('Latex', 'royaltechbd'),
			'less' => __('Less', 'royaltechbd'),
			'lilypond' => __('Lilypond', 'royaltechbd'),
			'liquid' => __('Liquid', 'royaltechbd'),
			'lisp' => __('Lisp', 'royaltechbd'),
			'livescript' => __('Livescript', 'royaltechbd'),
			'lolcode' => __('Lolcode', 'royaltechbd'),
			'lua' => __('Lua', 'royaltechbd'),
			'makefile' => __('Makefile', 'royaltechbd'),
			'markdown' => __('Markdown', 'royaltechbd'),
			'markup-templating' => __('Markup-templating', 'royaltechbd'),
			'matlab' => __('Matlab', 'royaltechbd'),
			'mel' => __('Mel', 'royaltechbd'),
			'mizar' => __('Mizar', 'royaltechbd'),
			'monkey' => __('Monkey', 'royaltechbd'),
			'n1ql' => __('N1ql', 'royaltechbd'),
			'n4js' => __('N4js', 'royaltechbd'),
			'nand2tetris-hdl' => __('Nand2tetris-hdl', 'royaltechbd'),
			'nasm' => __('Nasm', 'royaltechbd'),
			'nginx' => __('Nginx', 'royaltechbd'),
			'nim' => __('Nim', 'royaltechbd'),
			'nix' => __('Nix', 'royaltechbd'),
			'nsis' => __('Nsis', 'royaltechbd'),
			'objectivec' => __('Objectivec', 'royaltechbd'),
			'ocaml' => __('Ocaml', 'royaltechbd'),
			'opencl' => __('Opencl', 'royaltechbd'),
			'oz' => __('Oz', 'royaltechbd'),
			'parigp' => __('Parigp', 'royaltechbd'),
			'parser' => __('Parser', 'royaltechbd'),
			'pascal' => __('Pascal', 'royaltechbd'),
			'pascaligo' => __('Pascaligo', 'royaltechbd'),
			'pcaxis' => __('Pcaxis', 'royaltechbd'),
			'perl' => __('Perl', 'royaltechbd'),
			'php' => __('Php', 'royaltechbd'),
			'phpdoc' => __('Phpdoc', 'royaltechbd'),
			'php-extras' => __('Php-extras', 'royaltechbd'),
			'plsql' => __('Plsql', 'royaltechbd'),
			'powershell' => __('Powershell', 'royaltechbd'),
			'processing' => __('Processing', 'royaltechbd'),
			'prolog' => __('Prolog', 'royaltechbd'),
			'properties' => __('Properties', 'royaltechbd'),
			'protobuf' => __('Protobuf', 'royaltechbd'),
			'pug' => __('Pug', 'royaltechbd'),
			'puppet' => __('Puppet', 'royaltechbd'),
			'pure' => __('Pure', 'royaltechbd'),
			'python' => __('Python', 'royaltechbd'),
			'q' => __('Q', 'royaltechbd'),
			'qore' => __('Qore', 'royaltechbd'),
			'r' => __('R', 'royaltechbd'),
			'jsx' => __('Jsx', 'royaltechbd'),
			'tsx' => __('Tsx', 'royaltechbd'),
			'renpy' => __('Renpy', 'royaltechbd'),
			'reason' => __('Reason', 'royaltechbd'),
			'regex' => __('Regex', 'royaltechbd'),
			'rest' => __('Rest', 'royaltechbd'),
			'rip' => __('Rip', 'royaltechbd'),
			'roboconf' => __('Roboconf', 'royaltechbd'),
			'ruby' => __('Ruby', 'royaltechbd'),
			'rust' => __('Rust', 'royaltechbd'),
			'sas' => __('Sas', 'royaltechbd'),
			'sass' => __('Sass', 'royaltechbd'),
			'scss' => __('Scss', 'royaltechbd'),
			'scala' => __('Scala', 'royaltechbd'),
			'scheme' => __('Scheme', 'royaltechbd'),
			'shell-session' => __('Shell-session', 'royaltechbd'),
			'smalltalk' => __('Smalltalk', 'royaltechbd'),
			'smarty' => __('Smarty', 'royaltechbd'),
			'soy' => __('Soy', 'royaltechbd'),
			'splunk-spl' => __('Splunk-spl', 'royaltechbd'),
			'sql' => __('Sql', 'royaltechbd'),
			'stylus' => __('Stylus', 'royaltechbd'),
			'swift' => __('Swift', 'royaltechbd'),
			'tap' => __('Tap', 'royaltechbd'),
			'tcl' => __('Tcl', 'royaltechbd'),
			'textile' => __('Textile', 'royaltechbd'),
			'toml' => __('Toml', 'royaltechbd'),
			'tt2' => __('Tt2', 'royaltechbd'),
			'turtle' => __('Turtle', 'royaltechbd'),
			'twig' => __('Twig', 'royaltechbd'),
			'typescript' => __('Typescript', 'royaltechbd'),
			't4-cs' => __('T4-cs', 'royaltechbd'),
			't4-vb' => __('T4-vb', 'royaltechbd'),
			't4-templating' => __('T4-templating', 'royaltechbd'),
			'vala' => __('Vala', 'royaltechbd'),
			'vbnet' => __('Vbnet', 'royaltechbd'),
			'velocity' => __('Velocity', 'royaltechbd'),
			'verilog' => __('Verilog', 'royaltechbd'),
			'vhdl' => __('Vhdl', 'royaltechbd'),
			'vim' => __('Vim', 'royaltechbd'),
			'visual-basic' => __('Visual-basic', 'royaltechbd'),
			'wasm' => __('Wasm', 'royaltechbd'),
			'wiki' => __('Wiki', 'royaltechbd'),
			'xeora' => __('Xeora', 'royaltechbd'),
			'xojo' => __('Xojo', 'royaltechbd'),
			'xquery' => __('Xquery', 'royaltechbd'),
			'yaml' => __('Yaml', 'royaltechbd'),
		];
	}

    public function get_categories() {
        return [ 'royaltech' ];
    }

	protected function _register_controls() {
		$this->source_code_content_controls();
		$this->custom_color_content_controls();
		$this->register_style_controls();
	}

	protected function source_code_content_controls() {

		$this->start_controls_section(
			'_section_source_code',
			[
				'label' => __('Source Code', 'royaltechbd'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'lng_type',
			[
				'label' => __('Language Type', 'royaltechbd'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => 'markup',
				'options' => $this->lng_type(),
			]
		);

		$this->add_control(
			'theme',
			[
				'label' => __('Theme', 'royaltechbd'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => 'prism',
				'options' => [
					'prism' => __('Default', 'royaltechbd'),
					'prism-coy' => __('Coy', 'royaltechbd'),
					'prism-dark' => __('Dark', 'royaltechbd'),
					'prism-funky' => __('Funky', 'royaltechbd'),
					'prism-okaidia' => __('Okaidia', 'royaltechbd'),
					'prism-solarizedlight' => __('Solarized light', 'royaltechbd'),
					'prism-tomorrow' => __('Tomorrow', 'royaltechbd'),
					'prism-twilight' => __('Twilight', 'royaltechbd'),
					'custom' => __('Custom Color', 'royaltechbd'),
				],
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'source_code',
			[
				'label' => __('Source Code', 'royaltechbd'),
				'type' => Controls_Manager::CODE,
				'rows' => 20,
				'default' => '<p class="random-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>',
				'placeholder' => __('Source Code....', 'royaltechbd'),
				'condition' => [
					'lng_type!' => '',
				],
			]
		);
		$this->add_control(
			'copy_btn_text_show',
			[
				'label' => __('Copy Button Text Show?', 'royaltechbd'),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
                'style_transfer' => true,
			]
		);
		$this->add_control(
			'copy_btn_text',
			[
				'label' => __('Copy Button Text', 'royaltechbd'),
				'type' => Controls_Manager::TEXT,
				'rows' => 10,
				'default' => __('Copy to clipboard', 'royaltechbd'),
				'placeholder' => __('Copy Button Text', 'royaltechbd'),
				'condition' => [
					'copy_btn_text_show' => 'yes',
				],
			]
		);
		$this->add_control(
			'after_copy_btn_text',
			[
				'label' => __('After Copy Button Text', 'royaltechbd'),
				'type' => Controls_Manager::TEXT,
				'rows' => 10,
				'default' => __('Copied', 'royaltechbd'),
				'placeholder' => __('Copied', 'royaltechbd'),
				'condition' => [
					'copy_btn_text_show' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function custom_color_content_controls() {

		$this->start_controls_section(
			'_section_source_code_custom_color',
			[
				'label' => __('Custom Color', 'royaltechbd'),
				'tab' => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_background',
			[
				'label' => __( 'Background Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom :not(pre) > code[class*="language-"],{{WRAPPER}} .custom pre[class*="language-"]' => 'background: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_text_color',
			[
				'label' => __( 'Text Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom code[class*="language-"],{{WRAPPER}} .custom pre[class*="language-"]' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_text_shadow_color',
			[
				'label' => __( 'Text shadow Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom code[class*="language-"],{{WRAPPER}} .custom pre[class*="language-"]' => 'text-shadow: 0 1px {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_slate_gray',
			[
				'label' => __( 'Slate Gray Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.comment,{{WRAPPER}} .custom .token.prolog,{{WRAPPER}} .custom .token.doctype,{{WRAPPER}} .custom .token.cdata' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_dusty_gray',
			[
				'label' => __( 'Dusty Gray Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.punctuation' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_fresh_eggplant',
			[
				'label' => __( 'Fresh Eggplant Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.property,{{WRAPPER}} .custom .token.tag,{{WRAPPER}} .custom .token.boolean,{{WRAPPER}} .custom .token.number,{{WRAPPER}} .custom .token.constant,{{WRAPPER}} .custom .token.symbol,{{WRAPPER}} .custom .token.deleted' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_limeade',
			[
				'label' => __( 'Limeade Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.selector,{{WRAPPER}} .custom .token.attr-name,{{WRAPPER}} .custom .token.string,{{WRAPPER}} .custom .token.char,{{WRAPPER}} .custom .token.builtin,{{WRAPPER}} .custom .token.inserted' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_sepia_skin',
			[
				'label' => __( 'Sepia Skin Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.operator,{{WRAPPER}} .custom .token.entity,{{WRAPPER}} .custom .token.url,{{WRAPPER}} .custom .language-css .token.string,{{WRAPPER}} .custom .style .token.string' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_xanadu',
			[
				'label' => __( 'Xanadu Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.operator,{{WRAPPER}} .custom .token.entity,{{WRAPPER}} .custom .token.url,{{WRAPPER}} .custom .language-css .token.string,{{WRAPPER}} .custom .style .token.string' => 'background: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_deep_cerulean',
			[
				'label' => __( 'Deep Cerulean Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.atrule,{{WRAPPER}} .custom .token.attr-value,{{WRAPPER}} .custom .token.keyword' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_cabaret',
			[
				'label' => __( 'Cabaret Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.function,{{WRAPPER}} .custom .token.class-name' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);
		$this->add_control(
			'custom_tangerine',
			[
				'label' => __( 'Tangerine Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .custom .token.regex,{{WRAPPER}} .custom .token.important,{{WRAPPER}} .custom .token.variable' => 'color: {{VALUE}}',
				],
				'condition' => [
					'theme' => 'custom',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
     * Register widget style controls
     */
	protected function register_style_controls() {

		$this->start_controls_section(
			'_section_source_code_style',
			[
				'label' => __('Style', 'royaltechbd'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'source_code_box_height',
			[
				'label' => __('Height', 'royaltechbd'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royal-source-code pre' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'label' => __('Box Border', 'royaltechbd'),
				'selector' => '{{WRAPPER}}  .royal-source-code pre[class*="language-"]',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_border_radius',
			[
				'label' => __('Border Radius', 'royaltechbd'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .royal-source-code pre[class*="language-"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'source_code_box_padding',
			[
				'label' => __('Padding', 'royaltechbd'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .royal-source-code pre' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'source_code_box_margin',
			[
				'label' => __('Margin', 'royaltechbd'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .royal-source-code pre' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_control(
			'copy_btn_color',
			[
				'label' => __( 'Copy Button Text Color', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .royal-copy-code-button' => 'color: {{VALUE}}',
				],
				'separator' => 'before',
				'condition' => [
					'copy_btn_text_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'copy_btn_bg',
			[
				'label' => __( 'Copy Button Background', 'royaltechbd' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .royal-copy-code-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'copy_btn_text_show' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$source_code = $settings['source_code'];
		$theme = !empty($settings['theme']) ? $settings['theme'] : 'prism';
		$this->add_render_attribute('ha-code-wrap', 'class', 'royal-source-code');
		$this->add_render_attribute('ha-code-wrap', 'class', $theme);
		$this->add_render_attribute('ha-code-wrap', 'data-lng-type', $settings['lng_type']);
		if ('yes' == $settings['copy_btn_text_show'] && $settings['after_copy_btn_text']) {
			$this->add_render_attribute('ha-code-wrap', 'data-after-copy', $settings['after_copy_btn_text']);
		}
		$this->add_render_attribute('ha-code', 'class', 'language-' . $settings['lng_type']);
		?>
		<?php if (!empty($source_code)): ?>
			<div <?php $this->print_render_attribute_string('ha-code-wrap'); ?>>
			<pre>
			<?php if ('yes' == $settings['copy_btn_text_show'] && $settings['copy_btn_text']): ?>
				<button class="royal-copy-code-button"><?php echo esc_html($settings['copy_btn_text']) ?></button>
			<?php endif; ?>
				<code <?php $this->print_render_attribute_string('ha-code'); ?>>
					<?php echo esc_html($source_code); ?>
				</code>
			</pre>
			</div>
		<?php endif; ?>
		<?php

	}

	public function content_template() {
		?>
		<#
		var source_code = settings.source_code;
		view.addRenderAttribute( 'ha-code-wrap', 'class', 'royal-source-code');
		view.addRenderAttribute( 'ha-code-wrap', 'class', settings.theme);
		view.addRenderAttribute( 'ha-code-wrap', 'data-lng-type', settings.lng_type);
		if('yes' == settings.copy_btn_text_show && settings.after_copy_btn_text){
		view.addRenderAttribute( 'ha-code-wrap', 'data-after-copy', settings.after_copy_btn_text);
		}
		view.addRenderAttribute( 'ha-code', 'class', 'language-'+settings.lng_type);

		#>
		<# if( source_code ){ #>
		<div {{{ view.getRenderAttributeString( 'ha-code-wrap' ) }}}>
		<pre>
			<# if( 'yes' == settings.copy_btn_text_show && settings.copy_btn_text ){ #>
				<button class="royal-copy-code-button">{{{settings.copy_btn_text}}}</button>
			<# } #>
				<code {{{ view.getRenderAttributeString( 'ha-code' ) }}}>{{ source_code }}</code>
			</pre>
		</div>
		<# } #>

		<?php
	}

}
