<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalNavMenuDesktop extends Widget_Base {

	public function get_name() {
		return 'royalnavmenudesktop';
	}

	
	public function get_title() {
		return __( 'Royal Desktop Menu', 'royaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-nav-menu';
	}


	public function get_keywords() {
		return [ 'Nav', 'Menu', 'Desktop', 'Dropdown', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = ['royaldesktopnavmenu'];
		return $styles;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content',
			[
				'label' => __( 'Menu Selection', 'royaltech' ),
			]
		);


		$menus = $this->get_available_menus();

		if ( ! empty( $menus ) ) {
			$this->add_control(
				'menu',
				[
					'label' => __( 'Select Menu', 'royaltech' ),
					'type' => Controls_Manager::SELECT,
					'options' => $menus,
					'default' => array_keys( $menus )[0],
					'separator' => 'after',
					'description' => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'royaltech' ), admin_url( 'nav-menus.php' ) ),
					'label_block' => 'true',
				]
			);
		} else {
			$this->add_control(
				'menu',
				[
					'type' => Controls_Manager::RAW_HTML,
					'raw' => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus</a> screen to create one.', 'royaltech' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}
		$this->end_controls_section();


		$this->start_controls_section(
			'common_section',
			[
				'label' => esc_html__( 'Common Section', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'menu_warper_hover_effect',
			[
				'label' => esc_html__( 'Hover Effect', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'menuhoverstroke',
				'options' => [
					'menuhoverstroke'  => esc_html__( 'Stroke', 'royaltech' ),
					'menuhovershift'  => esc_html__( 'Shift', 'royaltech' ),
					'menuhovercircle'  => esc_html__( 'Circle', 'royaltech' ),
					'menuhoverfill'  => esc_html__( 'Fill', 'royaltech' ),

					'none' => esc_html__( 'None', 'royaltech' ),
				],
			]
		);
		$this->add_control(
			'menu_warper_hover_effect_color1',
			[
				'label' => __( 'Hover Effect Color 1', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff000',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .menuhoverstroke ul li a:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .menuhovershift ul li a:after' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .menuhoverfill ul li a:after' => 'background-color: {{VALUE}};',
					
				],
			]
		);
		$this->add_control(
			'menu_warper_hover_effect_color2',
			[
				'label' => __( 'Hover Effect Color 2', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#333333',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu' => 'background-color: {{VALUE}};',
				],
			]
		);		
        $this->add_control(
            'menu_warper_border_radius',
            [
                'label' => __( 'Warper Border Radius', 'royaltech' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .royaldesktopnavmenu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();	








		$this->start_controls_section(
			'mainmenu_section',
			[
				'label' => esc_html__( 'Main Menu Section', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'mainmenu_typography',
				'selector' => '{{WRAPPER}} .royaldesktopmenu > li > a',
			]
		);
		$this->add_control(
			'mainmenu_full_background',
			[
				'label' => __( 'Background Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#00000000',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'mainmenu_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'mainmenu_border_radius',
            [
                'label' => __( 'Border Radius', 'royaltech' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .royaldesktopmenu > li > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'mainmenu_border',
				'label' => esc_html__( 'Border', 'royaltech' ),
				'selector' => '{{WRAPPER}} .royaldesktopmenu > li',
			]
		);



		$this->add_control(
			'mainmenu_text_align',
			[
				'label' => __( 'Text Align', 'royaltech' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'selectors_dictionary' => [
					'left' => 'text-align: left',
					'center' => 'text-align: center',
					'right' => 'text-align: right',
				],
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu' => '{{VALUE}}',
				],
			]
		);


		$this->start_controls_tabs( 'tabs_mainmenu_style' );
		$this->start_controls_tab(
			'tab_mainmenu_normal',
			[
				'label' => __( 'Normal', 'royaltech' ),
			]
		);
		$this->add_control(
			'mainmenu_color',
			[
				'label' => __( 'Main Menu Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'mainmenu_background',
			[
				'label' => __( 'Main Menu Background', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#FFFFFF00',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu > li > a' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();


		$this->start_controls_tab(
			'tab_mainmenu_hover',
			[
				'label' => __( 'Hover', 'royaltech' ),
			]
		);
		$this->add_control(
			'mainmenu_color_hover',
			[
				'label' => __( 'Main Menu Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'mainmenu_background_hover',
			[
				'label' => __( 'Main Menu Background', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6E383840',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu > li:hover > a' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();		
		$this->end_controls_tabs();





		$this->end_controls_section();	











		$this->start_controls_section(
			'submenu_section',
			[
				'label' => esc_html__( 'Sub Menu Section', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'submenu_typography',
				'label' => __( 'Submenu Typography', 'royaltech' ),
				'selector' => '{{WRAPPER}} .royaldesktopmenu li ul.sub-menu li a',
			]
		);	



		$this->add_responsive_control(
			'submenu_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Sub Menu Padding', 'royaltech' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li ul.sub-menu li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);



		$this->start_controls_tabs( 'tabs_submenu_style' );
		$this->start_controls_tab(
			'tab_submenu_normal',
			[
				'label' => __( 'Normal', 'royaltech' ),
			]
		);

		$this->add_control(
			'submenu_color',
			[
				'label' => __( 'Submenu Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li ul.sub-menu a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submenu_background',
			[
				'label' => __( 'Submenu Background Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgb(88 89 91/0.80)',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li ul.sub-menu' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();


		$this->start_controls_tab(
			'tab_submenu_style_hover',
			[
				'label' => __( 'Hover', 'royaltech' ),
			]
		);
		$this->add_control(
			'submenu_color_hover',
			[
				'label' => __( 'Submenu Hover Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li ul.sub-menu a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submenu_background_hover',
			[
				'label' => __( 'Submenu Background Color', 'royaltech' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'rgb(88 89 91/0.80)',
				'separator' => 'none',
				'selectors' => [
					'{{WRAPPER}} .royaldesktopmenu li ul.sub-menu a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);		
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();







	}




	private function get_available_menus() {
		$menus = wp_get_nav_menus();

		$options = [];

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$available_menus = $this->get_available_menus();

		if ( ! $available_menus ) {
			return;
		}

		$args = [
			'echo' => false,
			'menu' => $settings['menu'],
			'menu_class' => 'royaldesktopmenu',
			'menu_id' => '',
			'fallback_cb' => '__return_empty_string',
			'container' => '',
		];
		$content_html = wp_nav_menu( $args );
		?>

		<div class="royaldesktopnavmenu">
			<div class="<?php echo esc_attr( $settings['menu_warper_hover_effect'] ); ?>">
				<?php echo $content_html; ?>
			</div>
		</div>
		<?php
	}


	protected function content_template() {

	}

}
