<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class RoyalFlipbox extends Widget_Base {

	public function get_name() {
		return 'royalflipbox';
	}


	public function get_title() {
		return __( 'Royal Flipbox', 'rroyaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-flip-box';
	}


	public function get_keywords() {
		return [ 'royalflipbox', 'flip', 'box', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = ['royalflipbox'];
		return $styles;
	}


	protected function _register_controls() {
		$this->start_controls_section(
			'section_type',
			[
				'label' => __( 'FlipBox Type', 'rroyaltech' ),
			]
		);

		$this->add_control(
            'tp_flipbox_style',
            [
                'label' => esc_html__('Style', 'rroyaltech'),
                'type' => Controls_Manager::SELECT,
                'default' => 'flip-box-style',
                'options' => [
                    'flip-box-style'      => esc_html__('Flip Box',  'rroyaltech'),
                    'rotate-box-style'    => esc_html__('Rotate Style',  'rroyaltech'),
                    'zoomin-box-style'    => esc_html__('Zoom In Style',  'rroyaltech'),
                    'zoomout-box-style'   => esc_html__('Zoom Out Style',  'rroyaltech'),
                    'side-right-style'    => esc_html__('Right Side Style',  'rroyaltech'),
                    'side-left-style'     => esc_html__('Left Side Style',  'rroyaltech'),
                    'to-top-style'        => esc_html__('To Top Style',  'rroyaltech'),
                    'to-bottom-style'     => esc_html__('To Bottom Style',  'rroyaltech'),
				],
			]
		);


		$this->add_control(
    'tp_flipbox_type',
		    [
		        'label' => __( 'Filp Box Type', 'rroyaltech' ),
		        'type' => Controls_Manager::CHOOSE,
						'default'     => __( 'vertical', 'rroyaltech' ),
		        'options' => [
		            'horizontal'    => [
		                'title' => __( 'Horizontal', 'rroyaltech' ),
		                'icon' => 'eicon-spacer',
		            ],
		            'vertical' => [
		                'title' => __( 'Vertical', 'rroyaltech' ),
		                'icon' => 'eicon-v-align-stretch',
		            ]
		        ],
				'condition' => [
					'tp_flipbox_style' => 'flip-box-style',
				],
		    ]
		);

		$this->add_control(
			'tp_flipbox_type-min-height',
			[
				'label' => esc_html__( 'Min Height', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 1000,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 150,
				],
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__holder' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);



		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'rroyaltech' ),
				'type' => 'dimensions',
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .tp-flipbox__back' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			'box-shadow',
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .tp-flipbox__back, {{WRAPPER}} .tp-flipbox__front',
			]
		);

		$this->add_control(
			'tp_flipbox_border_color',
			[
				'label' => __( 'Color', 'rroyaltech' ),
				'type' => 'color',
				'selectors' => [
					'{{WRAPPER}}  .tp-flipbox__front' => 'border-color: {{VALUE}};',
					'{{WRAPPER}}  .tp-flipbox__back' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'border_border!' => '',
				],
			]
		);

		$this->add_group_control(
			'border',
			[
				'name' => 'border',
				'placeholder' => '1px',
				'exclude' => [ 'color' ],
				'fields_options' => [
					'width' => [
						'label' => __( 'Border Width', 'rroyaltech' ),
					],
				],
				'selector' => '{{WRAPPER}} .tp-flipbox__back, {{WRAPPER}} .tp-flipbox__front',
			]
		);

		$this->add_control(
			'tp_flipbox_border_radius',
			[
				'label' => __( 'Border Radius', 'rroyaltech' ),
				'type' => 'dimensions',
				'size_units' => [ 'px', '%' ],
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__front' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .tp-flipbox__back' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();






		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Background & Colors', 'rroyaltech' ),
			]
		);




		$this->add_control(
			'tp_flipbox_f_icon',
			[
				 'label' => __( 'Front Side Image Icon', 'rroyaltech' ),
				 'type' => Controls_Manager::MEDIA
			]
		);

		$this->add_control(
			'tp_flipbox_f_bg_img',
			[
				 'label' => __( 'Front Side Image background', 'rroyaltech' ),
				 'type' => Controls_Manager::MEDIA,
				 'dynamic' => [
						'active' => true,
				 ],
				 'selectors' => [
 					'{{WRAPPER}} .tp-flipbox__front' => 'background-image: url({{URL}});',
 				]
			]
		);

		$this->add_control(
			'tp_flipbox_f_bg_color',
			[
				'label' => __( 'Front Side Background Color', 'rroyaltech' ),
				'default' => '#52ffaf',
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__front' => 'background-color: {{VALUE}};',
				]
			]

		);













		$this->add_control(
		  'tp_flipbox_b_icon',
		  [
		     'label' => __( 'Back Side Image Icon', 'rroyaltech' ),
		     'type' => Controls_Manager::MEDIA
		  ]
		);

		$this->add_control(
		  'tp_flipbox_b_bg_img',
		  [
		     'label' => __( 'Back Side Image background', 'rroyaltech' ),
			 'type' => Controls_Manager::MEDIA,
			 'dynamic' => [
				'active' => true,
		 		],
				 'selectors' => [
 					'{{WRAPPER}} .tp-flipbox__back' => 'background-image:url({{URL}});',
 				]
		  ]
		);

		$this->add_control(
		  'tp_flipbox_b_bg_color',
		  [
		    'label' => __( 'Back Side Background Color', 'rroyaltech' ),
				'default' => '#ee8cff',
		    'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__back' => 'background-color: {{VALUE}};',
				]
		  ]
		);




		$this->end_controls_section();


		/*
		Title & Contents
		----------------------------------------------------------------------------
		*/
				$this->start_controls_section(
					'section_texts',
					[
						'label' => __( 'Title & Contents', 'rroyaltech' ),
					]
				);


				$this->add_control(
            'title_tag',
            [
                'label' => __( 'Title HTML Tag', 'rroyaltech' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1'   => __( 'H1',   'rroyaltech' ),
                    'h2'   => __( 'H2',   'rroyaltech' ),
                    'h3'   => __( 'H3',   'rroyaltech' ),
                    'h4'   => __( 'H4',   'rroyaltech' ),
                    'h5'   => __( 'H5',   'rroyaltech' ),
                    'h6'   => __( 'H6',   'rroyaltech' ),
                    'div'  => __( 'div',  'rroyaltech' ),
                    'span' => __( 'Span', 'rroyaltech' ),
                ],
                'default' => 'div',
            ]
        );


				$this->add_control(
            'content_tag',
            [
                'label' => __( 'Description HTML Tag', 'rroyaltech' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'div'  => __( 'div',  'rroyaltech' ),
                    'span' => __( 'Span', 'rroyaltech' ),
                    'p'    => __( 'P',    'rroyaltech' ),
                ],
                'default' => 'div',
            ]
        );


				$this->add_control(
					'tp_flipbox_f_title',
					[
						'label' => __( 'Front Side Title', 'rroyaltech' ),
						'type' => Controls_Manager::TEXT,
						'dynamic' => [
							'active' => true,
					 	],
						'default'     => __( 'We Are So Glad You Are Here', 'rroyaltech' ),
				 'placeholder' => __( 'Please enter the flipbox front title', 'rroyaltech' ),
					]
				);

				$this->add_control(
					'tp_flipbox_f_desc',
					[
						'label' => __( 'Front Side Description', 'rroyaltech' ),
						'type' => Controls_Manager::TEXTAREA,
						'default'     => __( 'Hover Me Please, to check the back side', 'rroyaltech' ),
						'dynamic' => [
							'active' => true,
					 	],
						'placeholder' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin ultricies sem lorem, non ullamcorper neque tincidunt id.', 'rroyaltech' ),
					]
				);

				$this->add_control(
				  'tp_flipbox_b_title',
				  [
				    'label' => __( 'Back Side Title', 'rroyaltech' ),
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					 ],
				    'default'     => __( 'Contact Us', 'rroyaltech' ),
				 'placeholder' => __( 'Please enter the flipbox front title', 'rroyaltech' ),
				  ]
				);

				$this->add_control(
				  'tp_flipbox_b_desc',
				  [
				    'label' => __( 'Back Side Description', 'rroyaltech' ),
					'type' => Controls_Manager::TEXTAREA,
					'dynamic' => [
						'active' => true,
					 ],
				    'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin ultricies sem lorem, non ullamcorper neque tincidunt id.', 'rroyaltech' ),
				    'placeholder' => __( 'Please enter the flipbox back description', 'rroyaltech' ),
				  ]
				);


$this->end_controls_section();



/*
Typography tab
================================================================================
*/
		$this->start_controls_section(
			'section_typo',
			[
				'label' => __( 'Typography', 'rroyaltech' ),
			]
		);

		$this->add_group_control(			//Add group control to perform typography for button2.

			Group_Control_Typography::get_type(),
			[
				'name' => 'tp_flipbox_f_title_typo',
				'label' => __( 'Front Side Title Typography', 'rroyaltech' ),
				'selector' => '{{WRAPPER}} .tp-flipbox__title-front',
			]
		);



		$this->add_group_control(			//Add group control to perform typography for button2.

			Group_Control_Typography::get_type(),
			[
				'name' => 'tp_flipbox_f_desc_typo',
				'label' => __( 'Front Side Description Typography', 'rroyaltech' ),
				'selector' => '{{WRAPPER}} .tp-flipbox__desc-front',
			]
		);

		$this->add_group_control(			//Add group control to perform typography for button2.

			Group_Control_Typography::get_type(),
			[
				'name' => 'tp_flipbox_b_title_typo',
				'label' => __( 'Back Side Title Typography', 'rroyaltech' ),
				'selector' => '{{WRAPPER}} .tp-flipbox__title-back',
			]
		);


		$this->add_group_control(			//Add group control to perform typography for button2.

			Group_Control_Typography::get_type(),
			[
				'name' => 'tp_flipbox_b_desc_typo',
				'label' => __( 'Back Side Description Typography', 'rroyaltech' ),
				'selector' => '{{WRAPPER}} .tp-flipbox__desc-back',
			]
		);


$this->end_controls_section();

/*
color tab
================================================================================
*/
		$this->start_controls_section(
			'section_color',
			[
				'label' => __( 'Texts Colors', 'rroyaltech' ),
			]
		);

		$this->add_control(
			'tp_flipbox_f_title_color',
			[
				'label' => __( 'Front Side Title color', 'rroyaltech' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__title-front ' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'tp_flipbox_f_desc_color',
			[
				'label' => __( 'Front Side Description color', 'rroyaltech' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__desc-front ' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'tp_flipbox_b_title_color',
			[
				'label' => __( 'Back Side Title color', 'rroyaltech' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__title-back ' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'tp_flipbox_b_desc_color',
			[
				'label' => __( 'Back Side Description color', 'rroyaltech' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-flipbox__desc-back ' => 'color: {{VALUE}};',
				]
			]
		);


			$this->end_controls_section();

			/*
			Button settings tab
			================================================================================
			*/

			$this->start_controls_section(
				'section_button',
				[
					'label' => __( 'Button Settings', 'rroyaltech' ),
				]
			);


			$this->add_control(
						'tp_flipbox_show_btn',
						[
							'label' => __( 'Show Button?', 'rroyaltech' ),
							'type' => Controls_Manager::SWITCHER,
							'label_on' => __( 'Show', 'rroyaltech' ),
							'label_off' => __( 'Hide', 'rroyaltech' ),
							'return_value' => 'yes',
							'default' => 'yes',
						]
					);


					$this->add_control(
					  'tp_flipbox_b_btn_text',
					  [
					    'label' => __( 'Button Text', 'rroyaltech' ),
					    'type' => Controls_Manager::TEXT,
					    'default'     => __( 'View All', 'rroyaltech' ),
					 'placeholder' => __( 'Please enter the flipbox button text', 'rroyaltech' ),
					 'condition' => [
	 					'tp_flipbox_show_btn' => 'yes',
	 				],
					  ]
					);

					$this->add_control(
			  'tp_flipbox_b_btn_url',
			  [
			     'label' => __( 'Button URL', 'rroyaltech' ),
			     'type' => Controls_Manager::URL,
			     'default' => [
			        'url' => 'http://',
			        'is_external' => '',
			     ],
			     'show_external' => true,
					 'condition' => [
	 					'tp_flipbox_show_btn' => 'yes',
	 				],
			  ]
			);


			$this->add_control(
				'tp_flipbox_b_btn_bg_color',
				[
					'label' => __( 'Button Background Color', 'rroyaltech' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#f96161',
					'condition' => [
					 'tp_flipbox_show_btn' => 'yes',
				 ],
					'selectors' => [
						'{{WRAPPER}} .tp-flipbox__action a' => 'background-color: {{VALUE}};',
					]
				]
			);


			$this->add_control(
				'tp_flipbox_b_btn_text_color',
				[
					'label' => __( 'Button Text Color', 'rroyaltech' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#ffffff',
					'condition' => [
					 'tp_flipbox_show_btn' => 'yes',
				 ],
					'selectors' => [
						'{{WRAPPER}} .tp-flipbox__action a' => 'color: {{VALUE}};',
					]
				]
			);


			$this->add_control(
				'tp_flipbox_b_btn_bg_color_hover',
				[
					'label' => __( 'Button Background Color On Hover', 'rroyaltech' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#fcb935',
					'condition' => [
					 'tp_flipbox_show_btn' => 'yes',
				 ],
					'selectors' => [
						'{{WRAPPER}} .tp-flipbox__action a:hover' => 'background-color: {{VALUE}} !important;',
					]
				]
			);


			$this->add_control(
				'tp_flipbox_b_btn_text_color_hover',
				[
					'label' => __( 'Button Text Color On Hover', 'rroyaltech' ),
					'type' => Controls_Manager::COLOR,
					'default' => '#f7f7f7',
					'condition' => [
					 'tp_flipbox_show_btn' => 'yes',
				 ],
					'selectors' => [
						'{{WRAPPER}} .tp-flipbox__action a:hover' => 'color: {{VALUE}};',
					]
				]
			);


$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
	$settings = $this->get_settings_for_display();
	$tp_bg_img_front =       $settings['tp_flipbox_f_bg_img'];
	$tp_bg_img_back =        $settings['tp_flipbox_b_bg_img'];
	$tp_flipbox_show_btn =   $settings['tp_flipbox_show_btn'];
	$tp_flipbox_f_bg_color = $settings['tp_flipbox_f_bg_color'];




	 echo '<div id="flip-demo-0" class="tp-flipbox '.$settings['tp_flipbox_style'].' tp-flipbox--'.$settings['tp_flipbox_type'].'" onclick="">';
	  echo '    <div class="tp-flipbox__holder" >';
	  echo '        <div class="tp-flipbox__front" style=" background-color:'.$tp_flipbox_f_bg_color.';background-image: url('.$tp_bg_img_front['url'].');">';

	  echo '            <div class="tp-flipbox__content">';
	  $this->iconfront();
	  $this->titlefront();
	  $this->descfront();	  
	  echo '            </div>';
	  echo '        </div>';
	  echo '        <div class="tp-flipbox__back" style="background-image: url('.$tp_bg_img_back['url'].');" >';

	  echo '            <div class="tp-flipbox__content">';
	  $this->iconback();
	  $this->titleback();
	  $this->descback();	
		if($tp_flipbox_show_btn == "yes"){
	  echo '               <div class="tp-flipbox__action">';
		$btn_external = "";
		$btn_nofollow = "";
		if( $settings['tp_flipbox_b_btn_url']['is_external'] ) {
			$btn_external = ' target="_blank" ';
		}

		if( $settings['tp_flipbox_b_btn_url']['nofollow'] ) {
			$btn_nofollow = ' rel="nofollow" ';
		}

	  echo '                    <a ' . $btn_external . ' ' . $btn_nofollow . ' href="'.$settings['tp_flipbox_b_btn_url']['url'].'" class="tp-flipbox__btn">'.$settings['tp_flipbox_b_btn_text'].'</a>';
	  echo '                   </div>';
	}
	  echo '                </div>';
	  echo '            </div>';

	  echo '        </div>';
	  echo '    </div>';
	}



	protected function iconfront() {
		$settings 			= $this->get_settings();

		$iconfront 			= $settings['tp_flipbox_f_icon'];
		$iconfront_id 		= $iconfront["id"];
		$iconfront_alt 		= get_post_meta($iconfront, '_wp_attachment_image_alt', TRUE);
		$iconfront_title 	= get_the_title($iconfront);

		if ( $iconfront_id ) {
			echo '<div class="tp-flipbox__icon-front">';
			echo '<img alt="'.$iconfront_alt.'" title="'. $iconfront_title .'" src="'.$iconfront["url"].'"/>';
			echo '</div>';
		}
	}


	protected function titlefront() {
		$settings 			= $this->get_settings();
		$titlefront 		= $settings['tp_flipbox_f_title'];
		if ( $titlefront ) {
			echo '<' . esc_html($settings['title_tag']) . ' class="tp-flipbox__title-front">'.$settings['tp_flipbox_f_title'].'</' . esc_html($settings['title_tag']) . '>';
		}
	}		


	protected function descfront() {
		$settings 			= $this->get_settings();
		$descfront 		= $settings['tp_flipbox_f_desc'];
		if ( $descfront ) {
			echo '<' . esc_html($settings['content_tag']) . ' class="tp-flipbox__desc-front">'.$settings['tp_flipbox_f_desc'].'</' . esc_html($settings['content_tag']) . '>';
		}
	}	



	protected function iconback() {
		$settings 			= $this->get_settings();
		$iconback 			= $settings['tp_flipbox_b_icon'];
		$iconback_id 		= $iconback["id"];
		$iconback_alt 		= get_post_meta($iconback, '_wp_attachment_image_alt', TRUE);
		$iconback_title 	= get_the_title($iconback);
		if ( $iconback_id ) {
			echo '<div class="tp-flipbox__icon-back">';
			echo '<img alt="'.$iconback_alt.'" title="'. $iconback_title .'"  src="'.$iconback["url"].'"/>';
			echo '</div>';
		}
	}


	protected function titleback() {
		$settings 			= $this->get_settings();
		$titleback 		= $settings['tp_flipbox_b_title'];
		if ( $titleback ) {
			echo '<' . esc_html($settings['title_tag']) . ' class="tp-flipbox__title-back">'.$settings['tp_flipbox_b_title'].'</' . esc_html($settings['title_tag']) . '>';
		}
	}		


	protected function descback() {
		$settings 			= $this->get_settings();
		$descback 		= $settings['tp_flipbox_b_desc'];
		if ( $descback ) {
			echo '<' . esc_html($settings['content_tag']) . ' class="tp-flipbox__desc-back">'.$settings['tp_flipbox_b_desc'].'</' . esc_html($settings['content_tag']) . '>';
		}
	}	


	protected function content_template() {
		?>
		<div class="title">
			{{{ settings.title }}}
		</div>


		<div id="flip-demo-0" class="tp-flipbox tp-flipbox--{{settings.tp_flipbox_type}} {{settings.tp_flipbox_style}}" onclick="">
	      <div class="tp-flipbox__holder" >
	          <div class="tp-flipbox__front">

	              <div class="tp-flipbox__content">
	                  <div class="tp-flipbox__icon-front">

	                      <img src="{{settings.tp_flipbox_f_icon.url}}"/>


	                  </div>
	                  <{{{ settings.title_tag }}} class="tp-flipbox__title-front">{{{ settings.tp_flipbox_f_title }}}</{{{ settings.title_tag }}}>
	                  <{{{ settings.content_tag }}} class="tp-flipbox__desc-front">{{{ settings.tp_flipbox_f_desc }}}</{{{ settings.content_tag }}}>
	              </div>
	          </div>
	          <div class="tp-flipbox__back" >

	              <div class="tp-flipbox__content">
									<div class="tp-flipbox__icon-back">
											<img src="{{settings.tp_flipbox_b_icon.url}}"/>
									</div>
	                  <{{{ settings.title_tag }}} class="tp-flipbox__title-back">{{{ settings.tp_flipbox_b_title }}}</{{{ settings.title_tag }}}>
										<{{{ settings.content_tag }}} class="tp-flipbox__desc-back">{{{ settings.tp_flipbox_b_desc }}}</{{{ settings.content_tag }}}>
<# if ( settings.tp_flipbox_show_btn == 'yes' ) { #>
	                 <div class="tp-flipbox__action">
	                      <a href="{{ settings.tp_flipbox_b_btn_url.url}}" class="tp-flipbox__btn">{{{ settings.tp_flipbox_b_btn_text }}}</a>
	                  </div>
										<# } #>
	              </div>
	          </div>
	      </div>
		<?php
	}
}
