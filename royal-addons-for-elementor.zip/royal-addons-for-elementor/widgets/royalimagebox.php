<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalImageBox extends Widget_Base{

  public function get_name(){
    return 'royalimagebox';
  }


  public function get_title(){
    return 'Royal Image Box';
  }


  public function get_icon(){
    return 'royalicon eicon-image-box';
  }


  public function get_keywords() {
    return [ 'image', 'box', 'feature', 'photo', 'visual', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
  }


  public function get_categories(){
    return ['royaltech'];
  }

  
	public function get_style_depends() {
		$styles = ['royalimagebox'];
		return $styles;
	}


  protected function _register_controls(){
    $this->start_controls_section(
        'section_content',
        [
            'label' => __( 'Content', 'royaltech' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
      'imagebox_style',
      [
        'label' => __( 'Image Box Style', 'royaltech'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'imageboxstyle1',
        'options' => [
          'imageboxstyle1'    => __( 'Style 1', 'royaltech'),
          'imageboxstyle2'    => __( 'Style 2', 'royaltech'),
          'imageboxstyle3'    => __( 'Style 3', 'royaltech'),
        ],
      ]
    );

    $this->add_control(
      'imagebox_title',
      [
        'label' => __( 'Title', 'royaltech'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __( 'Collection', 'royaltech' ),
        'placeholder' => __( 'Type your title here', 'royaltech'),
      ]
    );


    $this->add_control(
      'title_position',
      [
        'label' => __( 'Title Position', 'royaltech'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'titletop',
        'options' => [
          'titletop'  => __( 'Top', 'royaltech'),
          'titlebottom' => __( 'Bottom', 'royaltech'),
        ],
      ]
    );


    $this->add_control(
      'imagebox_content',
      [
        'label' => __( 'Imagebox Content', 'royaltech'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __( 'Imagebox Content here', 'royaltech' ),
        'placeholder' => __( 'Type your title here', 'royaltech'),
      ]
    );


    $this->add_control(
      'show_button',
      [
        'label' => __( 'Show Button', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __( 'Show', 'royaltech' ),
        'label_off' => __( 'Hide', 'royaltech' ),
        'return_value' => 'yes',
        'default' => 'yes',
      ]
    );

    $this->add_control(
      'button_url',
      [
        'label' => __( 'Button Link', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __( 'http://www.royaltechbd.com', 'royaltech' ),
        'show_external' => true,
        'default' => [
          'url' => '',
          'is_external' => true,
          'nofollow' => true,
        ],
        'condition' => array(
          'show_button' => 'yes',
        ),        
      ]
    );


    $this->add_control(
      'button_text',
      [
        'label' => __( 'Button Text', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __( 'Buy Now', 'royaltech' ),
        'show_external' => true,
        'default' => 'Buy Now',
        'condition' => array(
          'show_button' => 'yes',
        ),        
      ]
    );


    $this->add_control(
      'imagebox_image',
      [
        'label' => __( 'Image Box Image', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
          'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Image_Size::get_type(),
      [
        'name' => 'imagebox_image_size', 
        'default' => 'royalimage600X600',
        'separator' => 'none',
      ]
    );



    $this->end_controls_section();




    $this->start_controls_section(
      'title_color_section',
      [
        'label' => __( 'Style', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );

    $this->add_control(
      'imagebox_hover_animation',
      [
        'label' => __( 'Image Box Hover Animation', 'plugin-domain' ),
        'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
        'prefix_class' => 'elementor-animation-',
      ]
    );




   $this->add_control(
        'box_bg_color',
        [
            'label' => __( 'Box Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'condition' => array(
              'imagebox_style' => 'imageboxstyle3',
            ), 
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .imageboxstyle3 .royalimagebox:hover .boxinfo' => 'background: {{VALUE}}',
            ],
        ]
    );   






    $this->add_control(
      '_title_style',
      [
        'label' => __( 'Title Style', 'plugin-name' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'title_typo',
        'label' => __( 'Title Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .royalimagebox .boxinfo .title',
      ]
    );


    $this->add_control(
      'title_hover_animation',
      [
        'label' => __( 'Title Hover Animation', 'royaltech'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'default' => 'royalhovernone',
        'options' => [
          'royalhovernone'    => __( 'None', 'royaltech'),
          'royalhoverstroke'  => __( 'Stroke', 'royaltech'),
          'royalhovershift'   => __( 'Shift', 'royaltech'),
        ],
      ]
    );  




   $this->add_control(
        'title_color',
        [
            'label' => __( 'Title Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_1,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo .title' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'title_bg_color',
        [
            'label' => __( 'Title Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo .title' => 'background: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'title_hover_color',
        [
            'label' => __( 'Title Hover Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#ddd',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .royalhoverstroke:after' => 'color: {{VALUE}}',
                '{{WRAPPER}} .royalimagebox .royalhovershift:after' => 'color: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'title_hover_bg',
        [
            'label' => __( 'Title Hover Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#ddd',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .royalhoverstroke:after' => 'background: {{VALUE}}',
                '{{WRAPPER}} .royalimagebox .royalhovershift:after' => 'background: {{VALUE}}',
            ],
        ]
    );   


    $this->add_control(
      '_content_style',
      [
        'label' => __( 'Content Style', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'content_typo',
        'label' => __( 'Content Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
        'selector' => '{{WRAPPER}} .royalimagebox .boxinfo .content',
      ]
    );


  
   $this->add_control(
        'content_color',
        [
            'label' => __( 'Content Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo .content' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'content_bg_color',
        [
            'label' => __( 'Content Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo .content' => 'background: {{VALUE}}',
            ],
        ]
    );   




    $this->add_control(
      '_button_style',
      [
        'label' => __( 'Button Style', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'button_typo',
        'label' => __( 'Button Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
        'selector' => '{{WRAPPER}} .royalimagebox .boxinfo a.button',
      ]
    );


  
   $this->add_control(
        'button_color',
        [
            'label' => __( 'Button Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo a.button' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'button_bg_color',
        [
            'label' => __( 'Button Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo a.button' => 'background: {{VALUE}}',
            ],
        ]
    );   


  
   $this->add_control(
        'button_color_hover',
        [
            'label' => __( 'Button Hover Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo a.button:hover' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'button_bg_color_hover',
        [
            'label' => __( 'Button Hover Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalimagebox .boxinfo a.button:hover' => 'background: {{VALUE}}',
            ],
        ]
    );   



   $this->end_controls_section();   








  }
  



  protected function render() {
    $settings = $this->get_settings_for_display();
    ?>
        <div class="<?php echo $settings['imagebox_style'] ?>"> 
        <div class="royalimagebox"> 
            <div class="boxinfo">
            <?php if ( $settings['imagebox_title'] ) : ?>
            <h3 class="title <?php echo $settings['title_position'] ?> <?php echo $settings['title_hover_animation'] ?>"><?php echo $settings['imagebox_title'] ?></h3>
            <?php endif; ?>
            <?php if ( $settings['imagebox_content'] ) : ?>
            <div class="content"><?php echo $settings['imagebox_content'] ?></div>
            <?php endif; ?>
            <?php if ( 'yes' === $settings['show_button'] ) { ?>
            <a class="button" href="<?php echo $settings['button_url']['url'] ?>"><?php echo $settings['button_text'] ?></a>
            <?php } ?>
            </div> 
            <?php if ( ! empty( $settings['imagebox_image']['url'] ) ) { 
            $image = Group_Control_Image_Size::get_attachment_image_html( $settings, 'imagebox_image_size', 'imagebox_image' );
            echo '<div class="bgimg">' . $image . '</div>';
            } ?>
        </div>
        </div>
    <?php
  }





}