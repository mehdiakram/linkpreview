<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalAnimatedHeadline extends Widget_Base {

	public function get_name() {
		return 'royalanimatedheadline';
	}


	public function get_title() {
		return __( 'Royal Animated Headline', 'royaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-animated-headline';
	}


  	public function get_keywords() {
    	return ['RoyalAnimatedHeadline', 'heading', 'Headline', 'Animated Headline', 'Header', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
  	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = [ 'royalanimatedheadline' ];
		return $styles;
	}


	public function get_script_depends() {
		$scripts = ['royalanimatedheadline'];
		return $scripts;
	}	


	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'header_tag',
			[
				'label' => __( 'Header Tag', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'  					=> __( 'H1', 'royaltech' ),
					'h2'  					=> __( 'H2', 'royaltech' ),
					'h3'  					=> __( 'H3', 'royaltech' ),
					'h4'  					=> __( 'H4', 'royaltech' ),
					'h5'  					=> __( 'H5', 'royaltech' ),
					'h6'  					=> __( 'H6', 'royaltech' ),
					'div'  					=> __( 'DIV', 'royaltech' ),
				],
			]
		);


		$this->add_control(
			'animation_style',
			[
				'label' => __( 'Animation Style', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'rotate-1',
				'options' => [
					'rotate-1'  			=> __( 'Word Rotate', 'royaltech' ),
					'letters rotate-2'		=> __( 'Letters Rotate2', 'royaltech' ),
					'letters rotate-3'		=> __( 'Letters Rotate3', 'royaltech' ),
					'letters scale'			=> __( 'Letters Scale', 'royaltech' ),
					'letters type'  		=> __( 'Letters Type', 'royaltech' ),
					'loading-bar'  			=> __( 'Loading Bar', 'royaltech' ),
					'slide'  				=> __( 'Slide', 'royaltech' ),
					'clip is-full-width' 	=> __( 'Clip Full Width', 'royaltech' ),
					'zoom' 					=> __( 'Zoom', 'royaltech' ),
					'push' 					=> __( 'Push', 'royaltech' ),

				],
			]
		);


    	// Headline 1st Static
		$this->add_control(
			'headline_first',
			[
				'label' => __( 'Headline First Static Text', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'label_block' => true,
        'default' => 'Hi, I am ',
				'placeholder' => __( 'Write Headline Here', 'royaltech' ),
			]
   		);
        

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'headline_second', [
				'label' => __( 'Animated Text', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Animated Text' , 'royaltech' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'headline_list',
			[
				'label' => __( 'Animated Text List', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
        'default' => [
	          [
	            'headline_second' => __( 'Bangladeshi', 'royaltech' ),
	          ],
	          [
	            'headline_second' => __( 'Mushlim', 'royaltech' ),
	          ],	
          ],		
				'title_field' => '{{{ headline_second }}}',
			]
		);


    	// Headline Last Static
		$this->add_control(
			'headline_last',
			[
				'label' => __( 'Headline Last Static Text', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'label_block' => true,
        'default' => '',
				'placeholder' => __( 'Write Last Headline Here', 'royaltech' ),
			]
    	);
        

		$this->add_control(
			'headline_align',
			[
				'label' => __( 'Alignment', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'toggle' => false,
				'selectors' => [
					'{{WRAPPER}} .royaldheadline' => 'justify-content: {{VALUE}};',
				],
			]
		);


    $this->end_controls_section();

    



    $this->start_controls_section(
        'section_typing_style',
        [
            'label' => __('Text', 'royaltech'),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'text_color',
        [
            'label' => __( 'Text Color', 'royaltech' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#000000',
            'selectors' => [
                '{{WRAPPER}} .royaldheadline' => 'color: {{VALUE}};',
                
            ],
        ]
    );

    $this->add_control(
        'text_color_animated',
        [
            'label' => __( 'Animated Text Color', 'royaltech' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#000000',
            'selectors' => [
                '{{WRAPPER}} .royaldheadlinewrapper' => 'color: {{VALUE}};',
                '{{WRAPPER}} .royaldheadline.type .royaldheadlinewrapper.selected b i' => 'color: {{VALUE}};',
            ],
        ]
    );


    $this->add_control(
        'text_bgcolor_animated',
        [
            'label' => __( 'Animated Text Background', 'royaltech' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#000000',
            'selectors' => [
                '{{WRAPPER}} .royaldheadline.loading-bar .royaldheadlinewrapper::after' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .royaldheadline.type .royaldheadlinewrapper.selected' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .royaldheadline.type .royaldheadlinewrapper::after' => 'background-color: {{VALUE}};',
            ],
        ]
    );


    $this->add_control(
        'text_bg_color',
        [
            'label' => __( 'Whole Text Background', 'royaltech' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'selectors' => [
                '{{WRAPPER}} .royaldheadline' => 'background-color: {{VALUE}};',
            ],
        ]
    );


    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'typography',
            'scheme' => Typography::TYPOGRAPHY_1,
            'selector' => '{{WRAPPER}} .royaldheadline',
        ]
    );

    $this->end_controls_section();



	}


  protected function render() {
    $settings = $this->get_settings_for_display();
    ?>
	<section class="royalanimatedheadlines">
		<<?php echo $settings['header_tag'];?> class="royaldheadline <?php echo $settings['animation_style']; ?>">
		<span><?php echo $settings['headline_first']; ?></span>
		<span class="royaldheadlinewrapper">
			<?php if ( $settings['headline_list'] ) {
					foreach (  $settings['headline_list'] as $item ) { ?>
			<b><?php echo $item['headline_second']; ?></b>
			<?php } } ?>
		</span><?php if ( $settings['headline_list'] ) { echo '<span>'. $settings['headline_last'].'</span>'; } ?>
		</<?php echo $settings['header_tag'];?>>
	</section>

	<?php
	}









}