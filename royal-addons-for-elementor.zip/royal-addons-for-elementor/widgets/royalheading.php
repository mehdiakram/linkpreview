<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalHeading extends Widget_Base {

	public function get_name() {
		return 'royalheading';
	}


	public function get_title() {
		return __( 'Royal Heading', 'royaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-heading';
	}


	public function get_keywords() {
		return [ 'heading', 'Header', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}

	
	public function get_style_depends() {
		$styles = [ 'royalheading' ];
		return $styles;
	}


	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'heading_style',
			[
				'label' => __( 'Heading Style', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => esc_html__( 'Style 1', 'royaltech' ),
					'2' => esc_html__( 'Style 2', 'royaltech' ),
					'3' => esc_html__( 'Style 3', 'royaltech' ),
					'4' => esc_html__( 'Style 4', 'royaltech' ),
				],
			]
		);



        // Sub Heading Start
		$this->add_control(
			'main_sub_heading',
			[
				'label' => __( 'Sub Heading', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Sub Heading',
				'condition' => [
					'heading_style' => '1',
				],				
				'placeholder' => __( 'Write Sub Heading Here', 'royaltech' ),
			]
        );

        //Color
        $this->add_control(
			'subtitle_color',
			[
				'label' => __( 'Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#777',
				'condition' => [
					'heading_style' => '1',
				],				
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 h4' => 'color: {{VALUE}}',
				],
			]
        );		
        //Typography 
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'condition' => [
					'heading_style' => '1',
				],					
				'label' => __( 'Typography', 'royaltech' ),
				'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .royalheading h4',			
			]
        );		
		// Sub Heading End




        // Heading Start
		$this->add_control(
			'main_heading',
			[
				'label' => __( 'Heading', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Heading',
                'separator'=> 'before',
				'placeholder' => __( 'Write Heading Here', 'royaltech' ),
			]
        );
        //Color
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#333',
				'selectors' => [
					'{{WRAPPER}} .royalheading h2' => 'color: {{VALUE}}',
				],
			]
        );
        
        //Typography 
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'royaltech' ),
				'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .royalheading h2',	
			]
        );        
        // Heading End


        // Description Start
		$this->add_control(
			'main_description',
			[
				'label' => __( 'Description', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => 'Description',
				'condition' => [
					'heading_style' => '1',
				],					
                'separator'=> 'before',
				'placeholder' => __( 'Write Description Here', 'royaltech' ),
			]
        );

        //Color
        $this->add_control(
			'desc_color',
			[
				'label' => __( 'Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#333',
				'condition' => [
					'heading_style' => '1',
				],					
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 p' => 'color: {{VALUE}}',
				],
			]
        );
        
        //Typography 
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'label' => __( 'Typography', 'royaltech' ),
				'separator'=> 'after',
				'condition' => [
					'heading_style' => '1',
				],					
				'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .royalheading p',				
			]
        );
		// Description End



		// Primary Line
		$this->add_control(
			'primaryline_options',
			[
				'label' => esc_html__( 'Primary / Right Line', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'heading_style' => ['1', '2', '4'],
				],					
				'separator' => 'before',
			]
		);

		$this->add_control(
			'primaryline_width',
			[
				'label' => esc_html__( 'Width', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition' => [
					'heading_style' => ['1', '2', '4'],
				],				
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 h2:after' => 'width: {{SIZE}}{{UNIT}}; margin-left:calc(-{{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .royalheadingtitle2 h2:after' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle3 h2:after' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle4 h2:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);		

		$this->add_control(
			'primaryline_height',
			[
				'label' => esc_html__( 'Height', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition' => [
					'heading_style' => ['1', '2', '4'],
				],				
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 h2:after' => 'height: {{SIZE}}{{UNIT}}; bottom: calc(-{{SIZE}}{{UNIT}}/2);',
					'{{WRAPPER}} .royalheadingtitle2 h2:after' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle3 h2:after' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle4 h2:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);		


        $this->add_control(
			'primaryline_color',
			[
				'label' => __( 'color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'heading_style' => ['1', '2', '4'],
				],					
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#e16038',
				'selectors' => [
					'{{WRAPPER}} .royalheading h2::after' => 'background-color: {{VALUE}}',
				],
			]
        );

		// Secondary
		$this->add_control(
			'secondaryline_options',
			[
				'label' => esc_html__( 'Secondary / Left Line', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'heading_style' => ['1', '3', '4'],
				],					
				'separator' => 'before',
			]
		);

		$this->add_control(
			'secondaryline_width',
			[
				'label' => esc_html__( 'Width', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition' => [
					'heading_style' => ['1', '3', '4'],
				],					
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 h2:before' => 'width: {{SIZE}}{{UNIT}}; margin-left:calc(-{{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .royalheadingtitle2 h2:before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle3 h2:before' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle4 h2:before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);		

		$this->add_control(
			'secondaryline_height',
			[
				'label' => esc_html__( 'Height', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition' => [
					'heading_style' => ['1', '3', '4'],
				],					
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1 h2:before' => 'height: {{SIZE}}{{UNIT}}; bottom: calc(-{{SIZE}}{{UNIT}}/2);',
					'{{WRAPPER}} .royalheadingtitle2 h2:before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle3 h2:before' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royalheadingtitle4 h2:before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);		


        $this->add_control(
			'secondary_color',
			[
				'label' => __( 'Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#777',
				'condition' => [
					'heading_style' => ['1', '3', '4'],
				],					
				'selectors' => [
					'{{WRAPPER}} .royalheading h2:before' => 'background-color: {{VALUE}}',
				],
			]
        );

		$this->add_control(
			'main_heading_align',
			[
				'label' => __( 'Alignment', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'separator'=> 'before',				
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .royalheadingtitle1' => 'text-align: {{VALUE}};',
					'{{WRAPPER}} .royalheadingtitle2 h2' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .royalheadingtitle3 h2' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}} .royalheadingtitle4 h2' => 'justify-content: {{VALUE}};',
				],
			]
		);
       
        $this->end_controls_section();

	}


	protected function render() {

        $settings = $this->get_settings_for_display();
		$heading_style = $settings['heading_style'];
        $main_sub_heading = $settings['main_sub_heading'];
        $main_heading = $settings['main_heading'];
        $main_description = $settings['main_description'];


		if( 1 == $heading_style ){
			echo '<div class="royalheading">';
				echo '<div class="royalheadingtitle1">';
					echo '<h4>'.$main_sub_heading.'</h4>';
					echo '<h2>'.$main_heading.'</h2>';
					echo '<p>'.$main_description.'</p>';
				echo '</div>';
			echo '</div>';

		}elseif( 2 == $heading_style ){
			echo '<div class="royalheading">';
				echo '<div class="royalheadingtitle2">';
					echo '<h2>'.$main_heading.'</h2>';
				echo '</div>';
			echo '</div>';

		}elseif( 3 == $heading_style ){
			echo '<div class="royalheading">';
				echo '<div class="royalheadingtitle3">';
					echo '<h2>'.$main_heading.'</h2>';
				echo '</div>';
			echo '</div>';

		}elseif( 4 == $heading_style ){
			echo '<div class="royalheading">';
				echo '<div class="royalheadingtitle4">';
					echo '<h2>'.$main_heading.'</h2>';
				echo '</div>';
			echo '</div>';
		}else{


		}


    ?>




<?php
	}

}