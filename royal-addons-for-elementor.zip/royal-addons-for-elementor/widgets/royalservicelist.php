<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalServiceList extends Widget_Base{

  public function get_name(){
    return 'royalservicelist';
  }


  public function get_title(){
    return 'Royal Service List';
  }


  public function get_icon(){
    return 'royalicon eicon-editor-list-ul';
  }


  public function get_keywords() {
    return [ 'service', 'list', 'image', 'photo', 'feature', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
  }


  public function get_categories(){
    return ['royaltech'];
  }

  
	public function get_style_depends() {
		$styles = ['royalservicelist'];
		return $styles;
	}


  protected function _register_controls(){
    $this->start_controls_section(
        'section_content',
        [
            'label' => __( 'Content', 'royaltech' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
      'servicetitle',
      [
        'label' => __( 'Title', 'royaltech'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __( 'Collection', 'royaltech' ),
        'placeholder' => __( 'Type your title here', 'royaltech'),
      ]
    );


    $this->add_control(
      'image',
      [
        'label' => __( 'Image', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
          'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
      ]
    );

    $this->add_group_control(
      Group_Control_Image_Size::get_type(),
      [
        'name' => 'imagebox_image_size', 
        'default' => 'royalimage600X600',
        'separator' => 'none',
      ]
    );

    $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'plugin-name' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_url',
			[
				'label' => esc_html__( 'Link', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#' , 'plugin-name' ),
			]
		);

  	$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater List', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'plugin-name' ),
						'list_url' => esc_html__( 'https://royaltechbd.com', 'plugin-name' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'plugin-name' ),
						'list_url' => esc_html__( 'https://royaltechbd.com', 'plugin-name' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);


    $this->end_controls_section();




    $this->start_controls_section(
      'title_color_section',
      [
        'label' => __( 'Style', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );


    $this->add_control(
      'title_style',
      [
        'label' => __( 'Title Style', 'plugin-name' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'title_typo',
        'label' => __( 'Title Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .royalservicelist .boxinfo .title',
      ]
    );


   $this->add_control(
        'title_color',
        [
            'label' => __( 'Title Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_1,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .boxinfo .title' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'title_bg_color',
        [
            'label' => __( 'Title Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .boxinfo .title' => 'background: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'title_hover_color',
        [
            'label' => __( 'Title Hover Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .boxinfo .title:hover' => 'color: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'title_hover_bg',
        [
            'label' => __( 'Title Hover Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#ffffff00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .boxinfo .title:hover' => 'background: {{VALUE}}',
            ],
        ]
    );   


    $this->add_control(
      '_content_style',
      [
        'label' => __( 'Content Style', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );


    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'content_typo',
        'label' => __( 'Content Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
        'selector' => '{{WRAPPER}} .royalservicelist .imageboxcontent ul li a',
      ]
    );


  
   $this->add_control(
        'content_color',
        [
            'label' => __( 'Content Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#000',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .imageboxcontent ul li a' => 'color: {{VALUE}}',
            ],
        ]
    );


   $this->add_control(
        'content_bg_color',
        [
            'label' => __( 'Content Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#FFFFFF00',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalservicelist .imageboxcontent ul li a' => 'background: {{VALUE}}',
            ],
        ]
    );   


    $this->end_controls_section();







    $this->start_controls_section(
      'List_section',
      [
        'label' => __( 'List Style', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );    




		$this->add_control(
			'list_icon',
			[
			  'label' => __( 'List Icon', 'royaltech' ),
			  'type' => \Elementor\Controls_Manager::ICONS,
			  'separator' => 'before',
			  'fa4compatibility' => 'icon',
			  'default' => [
				'value' => 'fas fa-caret-right',
				'library' => 'fa-solid',
			  ],
			  'recommended' => [
				'fa-solid' => [
				  'angle-right',
				  'angle-double-right',
				  'chevron-circle-right',
				  'long-arrow-alt-right',
				  'arrow-alt-circle-right',
				  'arrow-right',
				  'play',
				],
				'fa-regular' => [
				  'caret-square-right',
				],
			  ],
			  'skin' => 'inline',
			  'label_block' => false,        
			]
		  );

		  $this->add_control(
			'list_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'royaltech' ),
				'default' 	=> '#29C944',
				'selectors' => [
					'{{WRAPPER}} .royalservicelist .imageboxcontent ul li>i' => 'border-color: {{VALUE}};',
				],
			]
		);



    $this->end_controls_section();




  

}
  



  protected function render() {
    $settings = $this->get_settings_for_display();
    ?>
        <div class="royalservicelist"> 
            <div class="boxinfo">
                <?php if ( $settings['servicetitle'] ) : ?>
                <h3 class="title"><?php echo $settings['servicetitle'] ?></h3>
                <?php endif; ?>

              <div class="imageboxcontent">
                <?php if ( ! empty( $settings['image']['url'] ) ) { 
                $image = Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'image' );
                echo '<div class="image">' . $image . '</div>';
                } ?>
              <ul>
              <?php
                  if ( $settings['list'] ) {
                    foreach (  $settings['list'] as $item ) {    
                      echo'<li><i class="'.$settings['list_icon']['value'].'"></i><a href="'.$item['list_url'].'">'.$item['list_title'].'</a></li>';                  
                    }
                  }
              ?>
              </ul>
              </div>
            </div> 
        </div>
    <?php
  }






}