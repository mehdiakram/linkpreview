<?php

namespace RoyalAddons\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Frontend;
use \Elementor\Repeater;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RoyalContentSlider extends Widget_Base{

	public function get_name() {
		return 'royalcontentslider';
	}

	public function get_title() {
		return esc_html__( 'Royal Content Slider', 'royaltech' );
	}

	public function get_icon() {
		return 'royalicon eicon-post-slider';
	}

	public function get_categories() {
		return [ 'royaltech' ];
	}

	public function get_keywords() {
		return [ 'content slider', 'carousel', 'content slider', 'content carousel' ];
	}


	public function get_style_depends() {
		$styles = ['royalowlcarousel', 'royalowlcarouseltheme' ,'royalcarousel'];
		return $styles;
	}

	public function get_script_depends() {
		$scripts = ['royalowlcarousel'];
		return $scripts;
	}	

	protected function register_controls() {
		$this->rt_content_layout_options();
		$this->rt_carousel_options();

		$this->rt_style_carousel_options();
		$this->rt_style_navigation_options();
	}


	private function rt_content_layout_options() {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'royaltech' ),
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'slider_title',
			[
				'label' => __( 'Carousel Title', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Carousel Title #1', 'royaltech' ),
				'label_block' => true
			]
		);

		$repeater->add_control(
			'posttype',
			[
				'label' => esc_html__( 'Post Type', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'post' => esc_html__( 'Post', 'royaltech' ),
					'page' => esc_html__( 'Page', 'royaltech' ),
					'elementor_library' => esc_html__( 'Elementor Template', 'royaltech' ),
				],
				'default' => 'post',
			]
		);

		$repeater->add_control(
			'post',
			[
				'label' => esc_html__( 'Choose Post', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'posttype' => 'post'
				],
				'options'     => \RoyalAddons\Elementor\RoyalClass::royal_any_post_type('post'),
			]
		);

		$repeater->add_control(
			'page',
			[
				'label' => esc_html__( 'Choose Page', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'posttype' => 'page'
				],				
				'options'     => \RoyalAddons\Elementor\RoyalClass::royal_any_post_type('page'),
			]
		);


		$repeater->add_control(
			'elementor_library',
			[
				'label' => esc_html__( 'Choose Elementor Library', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'posttype' => 'elementor_library'
				],					
				'options'     => \RoyalAddons\Elementor\RoyalClass::royal_any_post_type('elementor_library'),
			]
		);


		$this->add_control(
			'slider',
			[
				'label' => __( 'Carousel', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'slider_title' => __( 'Carousel Title', 'royaltech' ),
					],
				],
				'title_field' => '{{{ slider_title }}}',
			]
		);
		$this->end_controls_section();		
	}
	private function rt_carousel_options() {
	// Slider Settings
		$this->start_controls_section(
			'carousel_settings',
			[
				'label' => __( 'Carousel Settings', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'navigation_options',
			[
				'label' => esc_html__( 'Navigation', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'navposition',
			[
				'label' => __( 'Navigation Position', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'royalcarouselnavboth' 	=> 'Both Side',
					'royalcarouselnavbothlast'=> 'Both Side Last',
					'royalcarouselnavboth' 	=> 'Both Side',
					'' 						=> 'Bottom Center',					
					'royalcarouselnavleft' 	=> 'Bottom Left',
					'royalcarouselnavright' => 'Bottom Right',
				],
				'default' => '',
			]
		);
		$this->add_control(
			'dotposition',
			[
				'label' => __( 'Dot Position', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' 						=> 'Bottom Center',
					'royalcarouseldotleft' 	=> 'Bottom Left',
					'royalcarouseldotright'	=> 'Bottom Right',
					'royalcarouseldotinsidecenter'	=> 'Bottom Inside Center',
				],
				'default' => '',
			]
		);

		$this->add_control(
			'previousicon',
			[
				'label' => esc_html__( 'Nav Previous Icon', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-chevron-left',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'nexticon',
			[
				'label' => esc_html__( 'Nav Next Icon', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-chevron-right',
					'library' => 'solid',
				],
			]
		);        
		
		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Auto Play', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => true,
				'default' => true,
			]
		);
		
		$this->add_control(
			'loop',
			[
				'label' => __( 'Loop', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => true,
				'default' => true,
			]
		);

		$this->add_control(
			'margin',
			[
				'label' => __( 'Carousel Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 10,
			]
		);


		$this->add_control(
			'timeout',
			[
				'label' => __( 'Autoplay Timeout (ms)', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 2500,
			]
		);

		$this->add_control(
			'desktop_options',
			[
				'label' => esc_html__( 'Desktop', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'desktop_settings',
			[
				'label' => __( 'Desktop Settings', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktopitems',
			[
				'label' => __( 'Items', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 10,
				'step' => 1,                
				'default' => 1,
			]
		);

		//Dots
		$this->add_control(
			'desktopdots',
			[
				'label' => __( 'Dots', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		//Navs
		$this->add_control(
			'desktopnav',
			[
				'label' => __( 'Navigation', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tab_settings',
			[
				'label' => __( 'Tablet Settings', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'tab_options',
			[
				'label' => esc_html__( 'Tablet', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'tabitems',
			[
				'label' => __('Items', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 6,
				'step' => 1,
				'default' => 1,
			]
		);
		//Dots
		$this->add_control(
			'tabdots',
			[
				'label' => __( 'Dots', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		//Navs
		$this->add_control(
			'tabnav',
			[
				'label' => __( 'Navigation', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mobile_settings',
			[
				'label' => __( 'Mobile Settings', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mobile_options',
			[
				'label' => esc_html__( 'Mobile', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'mobileitems',
			[
				'label' => __('Items', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 3,
				'step' => 1,                
				'default' => 1,
			]
		);
		//Dots
		$this->add_control(
			'mobiledots',
			[
				'label' => __( 'Dots', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		//Navs
		$this->add_control(
			'mobilenav',
			[
				'label' => __( 'Navigation', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->end_controls_section();
	
	
	}


	private function rt_style_carousel_options() {
		$this->start_controls_section(
			'section_style_carousel',
			[
				'label' => __( 'Carousel', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'carousel_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Carousel Background Color', 'royaltech' ),
				'default'	=> '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();		
	}



	private function rt_style_navigation_options() {
		$this->start_controls_section(
			'section_navigation',
			[
				'label' => __( 'Navigation', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'nav_options',
			[
				'label' => esc_html__( 'Nav Options', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'nav_dev_size',
			[
				'label'     => __( 'Nav Dev height & width', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nav_size',
			[
				'label'     => __( 'Nav Size', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 30,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nav_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Color', 'royaltech' ),
				'default'	=> '#869791',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'nav_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Color Hover', 'royaltech' ),
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button:hover i' => 'color: {{VALUE}};',
				],
			]
		);	
		
		$this->add_control(
			'nav_radius',
			[
				'label'     => __( 'Nav Border Radius', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);
		
		$this->add_control(
			'nav_background',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Background', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'background-color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'nav_background_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Background Hover', 'royaltech' ),
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i:hover' => 'background-color: {{VALUE}}!important;',
				],
			]
		);	
		

		$this->add_control(
			'nav_whole_background',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Whole Background', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button' => 'background-color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'nav_whole_background_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Whole Background Hover', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button:hover' => 'background-color: {{VALUE}}!important;',
				],
			]
		);	
	


		$this->add_control(
			'dot_options',
			[
				'label' => esc_html__( 'Dot Options', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
		$this->add_control(
			'dot_size',
			[
				'label'     => __( 'Dot Size', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 10,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .royalcarouseldotinsidecenter.owl-carousel .owl-dots .owl-dot' => 'width: calc({{SIZE}}{{UNIT}} + 10px); height: calc({{SIZE}}{{UNIT}} + 10px);',
				],
			]
		);

		$this->add_control(
			'dot_radius',
			[
				'label'     => __( 'Dot Border Radius', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'dot_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Dot Color', 'royaltech' ),
				'default'	=> '#869791',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dot_color_active',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Active Dot Color', 'royaltech' ),
				'default'	=> '#dddddd',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot.active span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}






	protected function render() {
		$settings 			= $this->get_settings();
        $id         	= $this->get_id();
        $carouselid     = 'royalcarousel'.$id;
        $loop           = $settings['loop'];
        $autoplay       = $settings['autoplay'];
        $margin         = $settings['margin'];
        $timeout        = $settings['timeout'];
        $navposition    = $settings['navposition'];
        $dotposition    = $settings['dotposition'];
        $previousicon   = $settings['previousicon']['value'];
        $nexticon    	= $settings['nexticon']['value'];
        $navtext    	= "[\"<i class='".$previousicon."'></i>\",\"<i class='".$nexticon."'></i>\"]";

        $desktopitems   = $settings['desktopitems'];
        if ( 'yes' === $settings['desktopdots'] ) {
			$desktopdots = 'true';
		} else{
            $desktopdots = 'false';
        } 
        if ( 'yes' === $settings['desktopnav'] ) {
			$desktopnav = 'true';
		} else{
            $desktopnav = 'false';
        }           


        $tabitems       = $settings['tabitems'];
        if ( 'yes' === $settings['tabdots'] ) {
			$tabdots = 'true';
		} else{
            $tabdots = 'false';
        }
        if ( 'yes' === $settings['tabnav'] ) {
			$tabnav = 'true';
		} else{
            $tabnav = 'false';
        }                     


        $mobileitems    = $settings['mobileitems'];
        if ( 'yes' === $settings['mobiledots'] ) {
			$mobiledots = 'true';
		} else{
            $mobiledots = 'false';
        } 
        if ( 'yes' === $settings['mobilenav'] ) {
			$mobilenav = 'true';
		} else{
            $mobilenav = 'false';
        } 

        $this->add_render_attribute(
            'royal_carousel_options',
            [
                'id'                	=> $carouselid,
                'data-loop'         	=> $loop,
                'data-autoplay'     	=> $autoplay,
                'data-margin'       	=> $margin,
                'data-autoplayTimeout'	=> $timeout,
                'data-navtext'   		=> $navtext,	

                'data-desktopitems' 	=> $desktopitems,
                'data-desktopdots'  	=> $desktopdots,
                'data-desktopnav'   	=> $desktopnav,

                'data-tabitems'     	=> $tabitems,
				'data-tabdots'  		=> $tabdots,
                'data-tabnav'   		=> $tabnav,

                'data-mobileitems'  	=> $mobileitems,
                'data-mobiledots'  		=> $mobiledots,
                'data-mobilenav'   		=> $mobilenav,	
			
            ]
        );


		echo'<div class="royalmastercarousel">';
		echo '<div class="royalcarousel owl-carousel owl-theme '.$navposition.' '.$dotposition.'" '.$this->get_render_attribute_string( 'royal_carousel_options' ).'>';
		foreach( $settings[ 'slider' ] as $slide ):
			$posttype 			= $slide['posttype'];
			$post 				= $slide['post'];
			$page 				= $slide['page'];
			$elementor_library 	= $slide['elementor_library'];
			
			if( 'post' == $posttype ){
				$p = $post;
			} elseif( 'page' == $posttype ){
				$p = $page;
			} elseif( 'elementor_library' == $posttype ){
				$p = $elementor_library;
			} else{
				$p = $post;
			}
			$elementor_page = get_post_meta( $p, '_elementor_edit_mode', true );

			if ( ! ! $elementor_page ) {
				$frontend = new \Elementor\Frontend();
				echo '<div class="item">'.$frontend->get_builder_content_for_display( $p, $with_css = true ).'</div>';
			} else{
			$all_posts = new \WP_Query( array( 'p' => $p ) );
			if ( $all_posts->have_posts() ) :
				while ( $all_posts->have_posts() ) :
					$all_posts->the_post();
					$the_content = apply_filters('the_content', get_the_content());
					echo '<div class="item">'.$the_content.'</div>';
				endwhile; 
				wp_reset_postdata();
			endif;				
			}
		endforeach; 
		echo'</div>';	
		echo'</div>';	
	}


	protected function content_template() {

	}
}