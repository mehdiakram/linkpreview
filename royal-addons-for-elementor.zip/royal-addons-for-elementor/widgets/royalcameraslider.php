<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



class RoyalCameraSlider extends Widget_Base {

    public function get_name() {
        return 'royalcameraslider';
    }


    public function get_title() {
        return 'Royal Camera Slider';
    }


    public function get_icon() {
        return 'royalicon eicon-slider-album';
    }


    public function get_categories() {
        return array('royaltech');
    }


    protected function _register_controls() {
        $this->start_controls_section(
            'section_typing_text',
            [
                'label' => __('Camera Slider', 'royaltech'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );



        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
          'slider_image',
          [
            'label' => __( 'Slider Image', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
              'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
          ]
        );

        $repeater->add_group_control(
          Group_Control_Image_Size::get_type(),
          [
            'name' => 'slider_image_size', 
            'default' => 'royalimage1400X560',
            'separator' => 'none',
          ]
        );

        $repeater->add_control(
          'slider_title',
          [
            'label' => __( 'Slider Title', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Slider Title', 'royaltech' ),
            'placeholder' => __( 'Type your title here', 'royaltech' ),
          ]
        );

        $repeater->add_control(
          'show_title',
          [
            'label' => __( 'Show Title', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'royaltech' ),
            'label_off' => __( 'Hide', 'royaltech' ),
            'return_value' => 'yes',
            'default' => 'flase',
          ]
        );


        $repeater->add_control(
          'description1',
          [
            'label' => __( 'Description1', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Slider Description1', 'royaltech' ),
            'placeholder' => __( 'Type your description here', 'royaltech' ),
          ]
        );

        $repeater->add_control(
            'desc1_color',
            [
                'label' => __( 'Description1 Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#fff',
            ]
        );

        $repeater->add_control(
            'desc1_animation',
            [
                'label' => __( 'Description1 Animation', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::ANIMATION,
                // 'prefix_class' => 'animated ',
            ]
        );


        $repeater->add_control(
            'description2',
            [
                'label' => __( 'Description2', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Slider Description2', 'royaltech' ),
                'placeholder' => __( 'Type your description here', 'royaltech' ),
            ]
        );

        $repeater->add_control(
            'desc2_color',
            [
                'label' => __( 'Description2 Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#fff',
            ]
        );

        $repeater->add_control(
            'desc2_animation',
            [
                'label' => __( 'Description2 Animation', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::ANIMATION,
                // 'prefix_class' => 'animated ',
            ]
        );


        $this->add_control(
            'sliderimages',
            [
                'label' => __( 'Slider Images', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ slider_title }}}',
            ]
        );


        $this->add_control(
            'slider_Settings',
            [
                'label' => __( 'Slider Settings', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'slider_loader',
            [
                'label' => __( 'Slider Loader', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'pie'  => __( 'Pie', 'royaltech' ),
                    'bar' => __( 'Bar', 'royaltech' ),
                    'none' => __( 'None', 'royaltech' ),
                ],
            ]
        );        


        $this->add_control(
            'slider_navigation',
            [
                'label' => __( 'Slider Navigation', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'false'  => __('Hide', 'royaltech'),
                    'true' => __('Show', 'royaltech'),
                ],
            ]
        );


        $this->add_control(
            'duration',
            [
                'label'         => __( 'Slider Duration (Milliseconds)', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min'           => 1000,
                'max'           => 30000,
                'step'          => 100,
                'default'       => 7000,
            ]
        );



        $this->add_control(
            'transperiod',
            [
                'label'         => __( 'Slider Trans Period (Milliseconds)', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min'           => 100,
                'max'           => 9000,
                'step'          => 100,
                'default'       => 1500,
            ]
        );


        $this->end_controls_section();



    }



    protected function render() {
        $settings = $this->get_settings_for_display();
        $sliderid =   'cameraslider'.esc_attr( $this->get_id() );
        

        if ( $settings['sliderimages'] ) { ?>
        <div class="fluid_container">
            <div class="camera_wrap camera_azure_skin" id="<?php echo $sliderid;?>">
            <?php foreach ( $settings['sliderimages'] as $item ) {
            $slider_image_id = $item['slider_image']['id'];
            $image_src = Group_Control_Image_Size::get_attachment_image_src($slider_image_id, 'slider_image_size', $item);
            ?>
                <div data-thumb="<?php echo $image_src; ?>" data-src="<?php echo $image_src; ?>">
                    <div class="cameraverticalcenter">
                      <?php if ( $item['description1'] ) : ?>
                        <div class="camera_effected cameradescription1 animated <?php echo $item['desc1_animation'] ?>" style="color:<?php echo $item['desc1_color']?>;"><?php echo $item['description1']?></div>
                      <?php endif; ?>
                      <?php if ( $item['description2'] ) : ?>
                        <div class="camera_effected cameradescription2 animated <?php echo $item['desc2_animation'] ?>" style="color:<?php echo $item['desc2_color']?>;"><?php echo $item['description2']?></div>
                      <?php endif; ?>
                    </div>
                    <?php if ( 'yes' === $item['show_title'] ) { ?>
                    <div class="camera_caption fadeFromBottom"><?php echo $item['slider_title'];?></div>
                    <?php } ?>
                </div>
            <?php } ?>
            </div>
        </div>
        <?php } ?>

        <script type="text/javascript">
        jQuery.noConflict();
            jQuery(function(){
                jQuery('#<?php echo $sliderid;?>').camera({
                    height      : '40%',
                    loader      : "<?php echo $settings['slider_loader'] ?>", //pie, bar, none
                    navigation  : <?php echo $settings['slider_navigation'] ?>,
                    playPause   : <?php echo $settings['slider_navigation'] ?>,
                    time        : <?php echo $settings['duration'] ?>,  // Millisecond stay
                    transPeriod : <?php echo $settings['transperiod'] ?>, // MS txn time

                    pagination  : false,                    
                    thumbnails  : false
                });
            });
        </script>

    <?php
    }



    protected function content_template() {
        
    }



}