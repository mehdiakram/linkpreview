<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalBlobBackground extends Widget_Base {

    public function get_name() {
        return  'royalblobbackground';
    }

    public function get_title() {
        return esc_html__( 'Royal Blob Background', 'royaltech' );
    }

    public function get_icon() {
        return 'royalicon eicon-background';
    }

    public function get_keywords() {
        return [ 'blob', 'animation', 'shape', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
    }

    public function get_categories() {
        return [ 'royaltech' ];
    }

	public function get_style_depends() {
		$styles = ['royalblob'];
		return $styles;
	}


    public function _register_controls() {
        
        // Background Section
        $this->start_controls_section(
            'background_section',
            [
                'label' => __( 'Background', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'royaltech' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .royalblobbackground',
			]
		);

        $this->add_control(
            'backgroundoverlay_heading',
            [
                'label' => __( 'Background Overlay', 'royaltech' ),
                'separator' => 'before',                
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'backgroundoverlay',
				'label' => __( 'Background Overlay', 'royaltech' ),
				'types' => ['gradient'],
				'selector' => '{{WRAPPER}} .royalblobbackground:before',
			]
		);

        $this->end_controls_section();


      
        // Background Section
        $this->start_controls_section(
            'size_section',
            [
                'label' => __( 'Size', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );



        $this->add_responsive_control(
            'blobwidth',
            [
                'label' => __( 'Blob Width', 'royaltech' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'description' => 'Default: 300px',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalblobbackground' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blobheight',
            [
                'label' => __( 'Blob Height', 'royaltech' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'description' => 'Default: 300px',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalblobbackground' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();








		$this->start_controls_section(
			'shape_section',
			[
				'label'         => __( 'Shape & Animation', 'royaltech' ),
				'tab'           => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'shapestyle',
			[
				'label'         => __( 'Shape Style', 'royaltech' ),
				'type'          => \Elementor\Controls_Manager::SELECT,
				'default'       => 'blobshape001',
                'description'   => 'Note<br>Blob Shape upto 200 have animation,<br>Blob Shape 201-500 have only hover animation<br>Blob Shape 501 & abobe have no animation',
				'options'       => [
					'blobshape001'      => __( 'Shape 1', 'royaltech' ),


					'blobshape101'      => __( 'Shape 101', 'royaltech' ),
					'blobshape102'      => __( 'Shape 102', 'royaltech' ),


					'blobshape501'      => __( 'Shape 501', 'royaltech' ),                    

				],              
			]
		);


        $this->add_control(
			'animationcontrol',
			[
				'label'         => __( 'Auto Animation', 'royaltech' ),
				'type'          => \Elementor\Controls_Manager::SELECT,
				'default'       => 'animationyes',
                'description'   => 'Note<br>For hover animation please set Z-index 1 from advanced tab',
				'options'       => [
					'animationyes'      => __( 'Animation', 'royaltech' ),
					'animationhover'    => __( 'Hover animation', 'royaltech' ),
					'animationno'       => __( 'No animation', 'royaltech' ),
				],                   
			]
		);

		$this->end_controls_section();

   }





    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="royalblobbackground <?php echo $settings['animationcontrol'] ?> <?php echo $settings['shapestyle'] ?>"></div>
        <?php
    }












}
