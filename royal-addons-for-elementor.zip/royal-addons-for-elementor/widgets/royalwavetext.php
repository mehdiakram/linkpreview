<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalWaveText extends Widget_Base {

	public function get_name() {
		return 'royalwavetext';
	}


	public function get_title() {
		return __( 'Royal Wave Text', 'royaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-heading';
	}


	public function get_keywords() {
		return [ 'wave', 'text', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = ['royalwavetext'];
		return $styles;
	}

	
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Sub Heading
		$this->add_control(
			'wavetext',
			[
				'label' => __( 'Wave Text', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'ROYAL',
			]
        );
        


		$this->add_control(
			'wavetext_align',
			[
				'label' => __( 'Alignment', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} section.royalwavetext' => 'justify-content: {{VALUE}};',
				],
			]
		);
       
        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Styles', 'royaltech' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
        );


        $this->add_control(
			'wavetext_color',
			[
				'label' => __( 'Main Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ],
                'default' => '#61CE70',
				'selectors' => [
					'{{WRAPPER}} .royalwavetextcontent h2:nth-child(1)' => 'color: {{VALUE}}',
				],
			]
        );
        
        $this->add_control(
			'wavetext_stroke_color',
			[
				'label' => __( 'Stroke Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_2,
                ],
                'default' => '#049FFF00',
				'selectors' => [
					'{{WRAPPER}} .royalwavetextcontent h2:nth-child(1)' => '-webkit-text-stroke: 3px {{VALUE}}',
				],
			]
        );

        $this->add_control(
			'wavetext_2nd_color',
			[
				'label' => __( 'Color', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Core\Schemes\Color::get_type(),
					'value' => \Elementor\Core\Schemes\Color::COLOR_3,
                ],
                'default' => '#59A6D6',
				'selectors' => [
					'{{WRAPPER}} .royalwavetextcontent h2:nth-child(2)' => 'color: {{VALUE}}',
				],
			]
        );

        // Wavetext Typography 
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wavetext_typography',
				'label' => __( 'Typography', 'royaltech' ),
				'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .royalwavetextcontent h2',
			]
        );
 
        $this->end_controls_section();
	}


	protected function render() {

        $settings = $this->get_settings_for_display();
        $wavetext = $settings['wavetext'];
    ?>
	<section class="royalwavetext">
		<div class="royalwavetextcontent">
			<h2><?php echo $wavetext; ?></h2>
			<h2><?php echo $wavetext; ?></h2>
		</div>
	</section>			
<?php
	}

}