<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly



class RoyalProfileCard extends Widget_Base {

	public function get_name() {
		return 'royalprofilecard';
	}

  
	public function get_title() {
		return 'Royal Profile Card';
	}


	public function get_icon() {
		return 'royalicon eicon-image-box';
	}


	public function get_keywords() {
		return [ 'Profile', 'Card', 'Animated', 'Image', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = ['royalprofilecard'];
		return $styles;
	}


	protected function register_controls() {
		$this->rt_content_options();
		$this->rt_style_title_options();
		$this->rt_style_desig_options();
		$this->rt_style_content_options();
		$this->rt_style_social_options();
	}



  private function rt_content_options() {

      $this->start_controls_section(
        'content_settings',
        [
          'label' => __( 'Content', 'royaltech' ),
          'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
      );


      $this->add_control(
        'profilecardstyle',
        [
          'label' => __( 'Profile Card Style', 'royaltech' ),
          'label_block' => true,
          'type' => \Elementor\Controls_Manager::SELECT,
          'default' => '1',
          'options' => [
            '1'     => __( 'Style 1', 'royaltech' ),
            '2'     => __( 'Style 2', 'royaltech' ),
            '3'     => __( 'Style 3', 'royaltech' ),
            '4'     => __( 'Style 4', 'royaltech' ),
            '5'     => __( 'Style 5', 'royaltech' ),
            '6'     => __( 'Style 6', 'royaltech' ),
            '7'     => __( 'Style 7', 'royaltech' ),
            '8'     => __( 'Style 8', 'royaltech' ),
            '9'     => __( 'Style 9', 'royaltech' ),
            '10'    => __( 'Style 10', 'royaltech' ),
            '11'    => __( 'Style 11', 'royaltech' ),
            '12'    => __( 'Style 12', 'royaltech' ),
            '13'    => __( 'Style 13', 'royaltech' ),
            '14'    => __( 'Style 14', 'royaltech' ),

            '100' 	=> __( 'Style 100', 'royaltech' ),
          ],
        ]
      );


      $this->add_control(
        'profilebackground',
        [
          'label' => esc_html__( 'Background Image', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::MEDIA,
          'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
          ],
        ]
      );


      $this->add_control(
        'profiletitle',
        [
          'label' => __( 'Title', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'condition' => [
            'profilecardstyle!' => ['100'],
          ],            
          'default' => __( 'S M Mehdi Akram', 'royaltech' ),
          'placeholder' => __( 'Type your title here', 'royaltech' ),
        ]
      );
  
      $this->add_control(
        'profiledesig',
        [
          'label' => __( 'Designation', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'condition' => [
            'profilecardstyle!' => ['100'],
          ],            
          'default' => __( 'Engineer', 'royaltech' ),
          'placeholder' => __( 'Type your designation here', 'royaltech' ),
        ]
      );

      $this->add_control(
        'profilecontent',
        [
          'label' => __( 'Content', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXTAREA,
          'rows' => 10,
          'condition' => [
            'profilecardstyle!' => ['100'],
          ],            
          'default' => __( 'Hi, this is Mehdi Akram', 'royaltech' ),
          'placeholder' => __( 'Type your designation here', 'royaltech' ),
        ]
      );

      $this->add_control(
        'content_bg_color1',
        [
          'type'      => Controls_Manager::COLOR,
          'label'     => __( 'Hover Background 1', 'royaltech' ),
          'default'	=> '#ffffff',
          'selectors' => [
            '{{WRAPPER}} .royalprofilecard .profilecardstyle1 .info' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle2:after' => 'border-color: transparent transparent transparent {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle3' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle4:hover figcaption::before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle5:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle6' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle7' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle8' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle9:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle10:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle10:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle12 figcaption' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle13 .picture::before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle13 .picture::after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle14 .designation' => 'background-color: {{VALUE}};',

            '{{WRAPPER}} .royalprofilecard .profilecardstyle100 a.wholelink' => 'background-image: linear-gradient(to top, {{VALUE}} 50%, transparent 50%);',
          ],
        ]
      );
      $this->add_control(
        'content_bg_color2',
        [
          'type'      => Controls_Manager::COLOR,
          'label'     => __( 'Hover Background 2', 'royaltech' ),
          'default'	=> '#00000047',
          'condition' => [
            'profilecardstyle!' => ['3', '5', '9', '100'],
          ],       
          'selectors' => [
            '{{WRAPPER}} .royalprofilecard figure.profilecardstyle1 .name' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle2:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle4' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle6 figcaption::before' => 'border-left: 4px solid {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle7 .tblock:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle7 .tblock:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle7 .tblock div:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle7 .tblock div:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle8:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle8:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle8 figcaption:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle8 figcaption:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle10 figcaption:before' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle10 figcaption:after' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle12 .profile-image' => 'border: 2px solid {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle13 .socialstyle' => 'background-color: {{VALUE}};',
            '{{WRAPPER}} .royalprofilecard .profilecardstyle14 img.profilepic' => 'border: 4px solid {{VALUE}};',



          ],
        ]
      );

      $repeater = new \Elementor\Repeater();
      $repeater->add_control(
        'socialtitle',
        [
          'label' => __( 'Title', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => __( 'Facebook', 'royaltech' ),
        ]
      );
      $repeater->add_control(
        'sociallink',
        [
          'label' => __( 'Social Link', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => __( 'http://royaltechbd.com', 'royaltech' ),
        ]
      );      
      $repeater->add_control(
        'socialicon',
        [
          'label' => __( 'Social Icon', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::ICONS,
          'fa4compatibility' => 'icon',
          'default' => [
            'value' => 'fab fa-facebook',
            'library' => 'fa-solid',
          ],
          'skin' => 'inline',
          'label_block' => false,        
        ]
      );

      $this->add_control(
        'show_socialcontent',
        [
          'label' => esc_html__( 'Show Social', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::SWITCHER,
          'label_on' => esc_html__( 'Show', 'your-plugin' ),
          'label_off' => esc_html__( 'Hide', 'your-plugin' ),
          'return_value' => 'yes',
          'default' => 'yes',
        ]
      );
      
      $this->add_control(
        'socialcontent',
        [
          'label' => __( 'Social Content', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::REPEATER,
          'condition' => [
            'profilecardstyle!' => ['100'],
            'show_socialcontent' => 'yes',
          ],            
          'fields' => $repeater->get_controls(),
          'default' => [
            [
              'socialtitle' => __( 'Social #1', 'royaltech' ),
            ],
            [
              'socialtitle' => __( 'Social #2', 'royaltech' ),
            ],
          ],
          'title_field' => '{{{ socialtitle }}}',
        ]
      );
      $this->add_control(
        'profilecardlink',
        [
          'label' => __( 'Link', 'royaltech' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => '#',
        ]
      );
		$this->end_controls_section();
	}


  private function rt_style_title_options() {
    $this->start_controls_section(
			'style_title_settings',
			[
				'label' => __( 'Title Style', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'title_typo',
        'label' => __( 'Title Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .royalprofilecard h2',
      ]
    );

    $this->add_control(
      'title_color',
      [
        'type'      => Controls_Manager::COLOR,
        'label'     => __( 'Title Color', 'royaltech' ),
        'default'	=> '#ffffff',
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard .title' => 'color: {{VALUE}};',
        ],
      ]
    );

		$this->add_control(
			'title_margin',
			[
				'label' => esc_html__( 'Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_align',
			[
				'label' => esc_html__( 'Alignment', 'royaltech' ),
				'type'  => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title'=> esc_html__( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left'
					],
					'center' => [
						'title'=> esc_html__( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center'
					],
					'right' => [
						'title'=> esc_html__( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right'
					]
				],
				'default' => 'left',
				'toggle'  => false,
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .title' => 'text-align: {{VALUE}};',
				],
			]
		);    
    $this->end_controls_section(); 
  }








  private function rt_style_desig_options() {
      $this->start_controls_section(
        'style_desig_settings',
        [
          'label' => __( 'Designation Style', 'royaltech' ),
          'tab' => Controls_Manager::TAB_STYLE,
        ]
      );
    

    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'desig_typo',
        'label' => __( 'Designation Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_2,
        'selector' => '{{WRAPPER}} .royalprofilecard .designation',
      ]
    );

    $this->add_control(
      'desig_color',
      [
        'type'      => Controls_Manager::COLOR,
        'label'     => __( 'Designation Color', 'royaltech' ),
        'default'	=> '#ffffff',
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard .designation' => 'color: {{VALUE}};',
        ],
      ]
    );

		$this->add_control(
			'desig_margin',
			[
				'label' => esc_html__( 'Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'desig_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'designation_align',
			[
				'label' => esc_html__( 'Alignment', 'royaltech' ),
				'type'  => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title'=> esc_html__( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left'
					],
					'center' => [
						'title'=> esc_html__( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center'
					],
					'right' => [
						'title'=> esc_html__( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right'
					]
				],
				'default' => 'left',
				'toggle'  => false,
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .designation' => 'text-align: {{VALUE}};',
				],
			]
		);

    $this->end_controls_section(); 
  }











  
  private function rt_style_content_options() {
      $this->start_controls_section(
        'style_content_settings',
        [
          'label' => __( 'Content Style', 'royaltech' ),
          'tab' => Controls_Manager::TAB_STYLE,
        ]
      );
    

    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'content_typo',
        'label' => __( 'Content Typography', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} .royalprofilecard .content',
      ]
    );

    $this->add_control(
      'content_color',
      [
        'type'      => Controls_Manager::COLOR,
        'label'     => __( 'Content Color', 'royaltech' ),
        'default'	=> '#000000',
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard .content' => 'color: {{VALUE}};',
        ],
      ]
    );

		$this->add_control(
			'content_margin',
			[
				'label' => esc_html__( 'Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_responsive_control(
			'content_align',
			[
				'label' => esc_html__( 'Alignment', 'royaltech' ),
				'type'  => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title'=> esc_html__( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left'
					],
					'center' => [
						'title'=> esc_html__( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center'
					],
					'right' => [
						'title'=> esc_html__( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right'
					]
				],
				'default' => 'left',
				'toggle'  => false,
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .content' => 'text-align: {{VALUE}};',
				],
			]
		);

    $this->end_controls_section(); 
  }





 
  private function rt_style_social_options() {
    $this->start_controls_section(
      'style_social_settings',
      [
        'label' => __( 'Social Style', 'royaltech' ),
        'tab' => Controls_Manager::TAB_STYLE,
      ]
    );
  
		$this->add_control(
			'social_font_size',
			[
				'label' => esc_html__( 'Font Size', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 32,
				],
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard ul.socialstyle li a i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

    $this->add_control(
      'social_color',
      [
        'type'      => Controls_Manager::COLOR,
        'label'     => __( 'Social Color', 'royaltech' ),
        'default'	=> '#000000',
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard ul.socialstyle li a i' => 'color: {{VALUE}};',
        ],
      ]
    );

    $this->add_control(
      'social_color_hover',
      [
        'type'      => Controls_Manager::COLOR,
        'label'     => __( 'Social Hover Color', 'royaltech' ),
        'default'	=> '#ffffff',
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard ul.socialstyle li a i:hover' => 'color: {{VALUE}};',
        ],
      ]
    );

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'social_border',
				'label' => esc_html__( 'Border', 'royaltech' ),
				'selector' => '{{WRAPPER}} .royalprofilecard ul.socialstyle li a i',
			]
		);


    $this->add_control(
      'social_margin',
      [
        'label' => esc_html__( 'Margin', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard ul.socialstyle li a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

    $this->add_control(
      'social_padding',
      [
        'label' => esc_html__( 'Padding', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors' => [
          '{{WRAPPER}} .royalprofilecard ul.socialstyle li a i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
      ]
    );

		$this->add_responsive_control(
			'social_align',
			[
				'label' => esc_html__( 'Alignment', 'royaltech' ),
				'type'  => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title'=> esc_html__( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left'
					],
					'center' => [
						'title'=> esc_html__( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center'
					],
					'right' => [
						'title'=> esc_html__( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right'
					]
				],
				'default' => 'left',
				'toggle'  => false,
				'selectors' => [
					'{{WRAPPER}} .royalprofilecard .socialstyle' => 'text-align: {{VALUE}};',
				],
			]
		);

    $this->end_controls_section(); 
}





	protected function render() {
		$settings           = $this->get_settings_for_display();
		$profilecardstyle	  = $settings['profilecardstyle'];
		$profilebackground	= $settings['profilebackground']['url'];
		$profiletitle	      = $settings['profiletitle'];
		$profiledesig	      = $settings['profiledesig'];
		$profilecontent	    = $settings['profilecontent'];
		$profilecardlink	  = $settings['profilecardlink'];
		$alt	= \Elementor\Control_Media::get_image_alt( $settings['profilecardstyle'] );
  ?>
  <div class="royalprofilecard">
  <?php if('1'== $profilecardstyle){ ?>
    <figure class="profilecardstyle1">
    <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
    <figcaption>
    <div class="name">
    <h2 class="title"><?php echo $profiletitle;?></h2>
      <h3 class="designation"><?php echo $profiledesig;?></h3>
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
    </div>
    <div class="info">
    <p class="content"><?php echo $profilecontent;?></p>
    <?php $this->socialcontent(); ?> 
    </div>      	
    </figcaption>	
    </figure>


    <?php }elseif('2'== $profilecardstyle){ ?>
      <figure class="profilecardstyle2">
        <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
        <figcaption>
        <div class="name">
          <h2 class="title"><?php echo $profiletitle;?></h2>
          <h3 class="designation"><?php echo $profiledesig;?></h3>
          <p class="content"><?php echo $profilecontent;?></p>
          <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
        </div>
          <div class="icons">
          <?php $this->socialcontent(); ?>  
          </div>
        </figcaption>       
      </figure>


      <?php }elseif('3'== $profilecardstyle){ ?>
        <figure class="profilecardstyle3">
        <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
        <figcaption>
        <div class="name">
        <h2 class="title"><?php echo $profiletitle;?></h2>
        <h3 class="designation"><?php echo $profiledesig;?></h3>
        <p class="content"><?php echo $profilecontent;?></p>
        <a href="#" class="readmore">Read More</a>
        <?php $this->socialcontent(); ?>       
        </div>
        </figcaption>
        </figure>


        <?php }elseif('4'== $profilecardstyle){ ?>
          <figure class="profilecardstyle4">
          <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
          <figcaption>
            <div class="name">
            <h2 class="title"><?php echo $profiletitle;?></h2>
            <h3 class="designation"><?php echo $profiledesig;?></h3>
            <p class="content"><?php echo $profilecontent;?></p>
            <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>            
            </div>
            <?php $this->socialcontent(); ?> 
          </figcaption>			
        </figure>
          

      <?php }elseif('5'== $profilecardstyle){ ?>
        <figure class="profilecardstyle5">
        <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
        <figcaption>
          <div class="name">
            <h2 class="title"><?php echo $profiletitle;?></h2>
            <h3 class="designation"><?php echo $profiledesig;?></h3>
            <p class="content"><?php echo $profilecontent;?></p>
            <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
          </div>
          <?php $this->socialcontent(); ?>  
        </figcaption>
      </figure>


    <?php }elseif('6'== $profilecardstyle){ ?>
      <figure class="profilecardstyle6">
      <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <figcaption>
      <div class="name">
        <h2 class="title"><?php echo $profiletitle;?></h2>
        <h3 class="designation"><?php echo $profiledesig;?></h3>
      </div>        
      <p class="content"><?php echo $profilecontent;?></p>
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
      <?php $this->socialcontent(); ?>
      </figcaption>			
      </figure>


    <?php }elseif('7'== $profilecardstyle){ ?>
    <figure class="profilecardstyle7">
    <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <div class="tblock">
        <div>
          <h2 class="title"><?php echo $profiletitle;?></h2>
          <h4 class="designation"><?php echo $profiledesig;?></h4>
        </div>
      </div>
      <figcaption>
      <p class="content"><?php echo $profilecontent;?></p>
      <?php $this->socialcontent(); ?>
      </figcaption>
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
    </figure>


    <?php }elseif('8'== $profilecardstyle){ ?>
      <figure class="profilecardstyle8">
      <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <figcaption>
        <h2 class="title"><?php echo $profiletitle;?></h2>
        <h3 class="designation"><?php echo $profiledesig;?></h3>
        <p class="content"><?php echo $profilecontent;?></p>
        <?php $this->socialcontent(); ?>
      </figcaption>
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
      </figure>


  <?php }elseif('9'== $profilecardstyle){ ?>
  <figure class="profilecardstyle9">
    <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
    <figcaption>
      <h2 class="title"><?php echo $profiletitle;?></h2>
      <h3 class="designation"><?php echo $profiledesig;?></h3>
      <p class="content"><?php echo $profilecontent;?></p>
      <?php $this->socialcontent(); ?>
    </figcaption>
    <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
  </figure>


  <?php }elseif('10'== $profilecardstyle){ ?>
    <figure class="profilecardstyle10">
      <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <figcaption>
      <h2 class="title"><?php echo $profiletitle;?></h2>
      <h3 class="designation"><?php echo $profiledesig;?></h3>
      <p class="content"><?php echo $profilecontent;?></p>
      <?php $this->socialcontent(); ?>
      </figcaption>
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
    </figure>


    <?php }elseif('11'== $profilecardstyle){ ?>
      <figure class="profilecardstyle11">
        <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
        <figcaption>
        <h2 class="title"><?php echo $profiletitle;?></h2>
        <h3 class="designation"><?php echo $profiledesig;?></h3>
        <p class="content"><?php echo $profilecontent;?></p>
        <?php $this->socialcontent(); ?>
        <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>
        </figcaption>			
			</figure>


      <?php }elseif('12'== $profilecardstyle){ ?>
        <figure class="profilecardstyle12">
          <div class="profile-image"><img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/></div>
          <figcaption>
          <h2 class="title"><?php echo $profiletitle;?></h2>
          <h3 class="designation"><?php echo $profiledesig;?></h3>
          <p class="content"><?php echo $profilecontent;?></p>
          <?php $this->socialcontent(); ?>
          </figcaption>
        </figure>


    <?php }elseif('13'== $profilecardstyle){ ?>
     <div class="profilecardstyle13">
        <div class="picture">
        <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
        </div>
        <div class="name">
          <h2 class="title"><?php echo $profiletitle;?></h2>
          <h3 class="designation"><?php echo $profiledesig;?></h3>
          <p class="content"><?php echo $profilecontent;?></p>
        </div>
        <?php $this->socialcontent(); ?>
      </div>


    <?php }elseif('14'== $profilecardstyle){ ?>
      <figure class="profilecardstyle14">
      <figcaption>
      <h2 class="title"><?php echo $profiletitle;?></h2>
      <p class="content"><?php echo $profilecontent;?></p>
      <?php $this->socialcontent(); ?>
      <img class="profilepic" src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      </figcaption>
      
      <h3 class="designation"><?php echo $profiledesig;?></h3>
      </figure>







    






    <?php }elseif('100'== $profilecardstyle){ ?>
      <figure class="profilecardstyle100">
      <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <figcaption> 
      <a class="wholelink" href="<?php echo $profilecardlink;?>"></a>	
      </figcaption>	
      </figure>


    <?php }else{ ?>
      <figure class="profilecardstyle1">
      <img src="<?php echo $profilebackground;?>" alt="<?php echo $alt;?>"/>
      <figcaption>
        <div class="name">
          <h2 class="title"><?php echo $profiletitle;?></h2>
          <h3 class="designation"><?php echo $profiledesig;?></h3>
          <a class="wholelink" href="#"></a>
        </div>
        <div class="info">
        <p class="content"><?php echo $profilecontent;?></p>
        <?php $this->socialcontent(); ?>
      </div>      	
      </figcaption>	
    </figure>
    <?php } ?>
  </div>
  <?php
	}












	protected function socialcontent() {
		$settings = $this->get_settings();
		$show_socialcontent = $settings['show_socialcontent'];
		$socialcontent = $settings['socialcontent'];
		if ( 'yes' !== $show_socialcontent ) {
			return;
		}

    if ( $settings['socialcontent'] ) {
      echo '<ul class="socialstyle socialstyle1">';
      foreach (  $settings['socialcontent'] as $item ) {
        echo '<li><a href="'.$item['sociallink'].'"><i class="'.$item['socialicon']['value'].'"></i><span>'. $item['socialtitle'].'</span></a></li>';
      }
      echo '</ul>';
    }
	}

	


}

