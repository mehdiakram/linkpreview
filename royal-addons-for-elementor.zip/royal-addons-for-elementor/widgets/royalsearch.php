<?php

namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalSearch extends Widget_Base{

  public function get_name(){
    return 'royalasearch';
  }


  public function get_title(){
    return 'Royal Search';
  }


  public function get_icon(){
    return 'royalicon eicon-site-search';
  }


  public function get_keywords() {
    return [ 'Site', 'search', 'Royal' ];
  }


  public function get_categories(){
    return ['royaltech'];
  }


	public function get_style_depends() {
		$styles = ['royalsearch'];
		return $styles;
	}


  protected function _register_controls(){

   $this->start_controls_section(
      'content_section',
      [
        'label' => __( 'Royal Search', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );


		$this->add_control(
			'search_type',
			[
				'label' => __( 'Search Type', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'   => __( 'Default', 'royaltech' ),
					'woo'       => __( 'Woo', 'royaltech' ),
					'woocat'    => __( 'Woo with Cat', 'royaltech' ),
				],
			]
		);


		$this->add_control(
			'search_style',
			[
				'label' => __( 'Search Style', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'fullscreen',
				'options' => [
          'fullscreen' => __( 'Fullscreen', 'royaltech' ),
				],
			]
		);



    $this->add_control(
      'royalsearchicon',
      [
        'label' => __( 'Search Icon', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'separator' => 'before',
        'default' => [
          'value' => 'fas fa-search',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-solid' => [
            'search',
            'search-plus',
            'search-minus',
            'search-location',
            'search-dollar',
          ],
          'fa-brands' => [
            'searchengin',
          ],
        ],
        'skin' => 'inline',
        'label_block' => false,        
      ]
    );
    
    $this->add_control(
      'royalcartsearchicon',
      [
        'label' => __( 'Cart Search Icon', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'separator' => 'before',
        'fa4compatibility' => 'icon',
        'default' => [
          'value' => 'fas fa-search',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-solid' => [
            'search',
            'search-plus',
            'search-minus',
            'search-location',
            'search-dollar',
          ],
          'fa-brands' => [
            'searchengin',
          ],
        ],
        'skin' => 'inline',
        'label_block' => false,        
      ]
    );
    $this->add_control(
      'royalcartcloseicon',
      [
        'label' => __( 'Cart Close Icon', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'separator' => 'before',
        'fa4compatibility' => 'icon',
        'default' => [
          'value' => 'fas fa-times',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-regular' => [
              'window-close',
              'times-circle',
              'times-circle',
          ],
          'fa-solid' => [
              'window-close',
              'times-circle',
              'times',
          ]
          ],
        'skin' => 'inline',
        'label_block' => false,        
      ]
    );    
    $this->end_controls_section();




    $this->start_controls_section(
      'search_color_section',
      [
        'label' => __( 'Search Colors', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );

  
   $this->add_control(
        'title_bg_color_close',
        [
            'label' => __( 'Title Background Color Close', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#6EC1E4',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_1,
            ],
            'selectors' => [
                '{{WRAPPER}} .close h3.royalaccitemheading' => 'background: {{VALUE}}',
            ],
        ]
    );

   $this->add_control(
        'title_bg_color_open',
        [
            'label' => __( 'Title Background Color Open', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#DBDBDB',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .open h3.royalaccitemheading' => 'background: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'body_bg_color',
        [
            'label' => __( 'Body Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#F2F2F2',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalaccitemcontent' => 'background: {{VALUE}}',
            ],
        ]
    );     


   $this->end_controls_section();   








  }
  



  protected function render() {
    $settings = $this->get_settings_for_display();
    ?>
    <div class="royalsearchicon"><i class="<?php echo $settings['royalsearchicon']['value'] ?>"></i></div>
    
    <?php
    if ('default' == $settings['search_type']  &&  'default' == $settings['search_style'] ){

    } 
    elseif ('default' == $settings['search_type']  &&  'fullscreen' == $settings['search_style'] ){
      ?>
      <div class="royalsearchoverly">
        <span class="closebtn" title=""><i class="<?php echo $settings['royalcartcloseicon']['value'] ?>"></i></span>
        <div class="searchoverlycontent">
          <form class="royalsearchform" method="GET" action="<?php echo esc_url(home_url('/'));?>">
          <input type="text"  name="s" class="searchbox" maxlength="128" value="<?php echo get_search_query();?>" placeholder="<?php esc_attr_e('Search entire here...', 'royaltech');?>">
          <button type="submit"><i class="<?php echo $settings['royalcartsearchicon']['value'] ?>"></i></button> 
          </form>
        </div>
    </div>
    <?php
    } 
    elseif ('woo' == $settings['search_type']  &&  'fullscreen' == $settings['search_style'] ){
      ?>
      <div class="royalsearchoverly">
        <span class="closebtn" title=""><i class="<?php echo $settings['royalcartcloseicon']['value'] ?>"></i></span>
        <div class="searchoverlycontent">
          <form class="royalsearchform" method="GET" action="<?php echo esc_url(home_url('/'));?>">
          <input type="hidden" value="product" name="post_type">
          <input type="text"  name="s" class="searchbox" maxlength="128" value="<?php echo get_search_query();?>" placeholder="<?php esc_attr_e('Search product here...', 'royaltech');?>">
          <button type="submit"><i class="<?php echo $settings['royalcartsearchicon']['value'] ?>"></i></button> 
          </form>
        </div>
    </div>
    <?php
    }  
    elseif ('woocat' == $settings['search_type']  &&  'fullscreen' == $settings['search_style'] ){
      ?>
      <div class="royalsearchoverly">
        <span class="closebtn" title=""><i class="<?php echo $settings['royalcartcloseicon']['value'] ?>"></i></span>
        <div class="searchoverlycontent">
        <form class="royalsearchform" method="GET" action="<?php echo esc_url(home_url('/'));?>">
          <?php if (class_exists('WooCommerce')): ?>
          <?php
          if (isset($_REQUEST['product_cat']) && !empty($_REQUEST['product_cat'])) {
              $optsetlect = $_REQUEST['product_cat'];
          } else {
              $optsetlect = 0;
          }
          $args = array(
              'show_option_all' => esc_html__('All Categories', 'royaltech'),
              'hierarchical' => 1,
              'class' => 'cat',
              'echo' => 1,
              'value_field' => 'slug',
              'selected' => $optsetlect,
          );
          $args['taxonomy'] = 'product_cat';
          $args['name'] = 'product_cat';
          $args['class'] = 'cate-dropdown hidden-xs';
          wp_dropdown_categories($args);

          ?>
          <input type="hidden" value="product" name="post_type">
          <?php endif;?>
          <input type="text"  name="s" class="searchbox" maxlength="128" value="<?php echo get_search_query();?>" placeholder="<?php esc_attr_e('Search product here...', 'royaltech');?>">
          <button type="submit"><i class="<?php echo $settings['royalcartsearchicon']['value'] ?>"></i></button> 
          </form>
        </div>
    </div>
    <?php
    }
    else
    {

    }
    

  }









}