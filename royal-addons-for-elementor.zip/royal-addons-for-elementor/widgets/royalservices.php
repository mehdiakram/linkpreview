<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalServices extends Widget_Base {

    public function get_name() {
        return  'royalservices';
    }

    public function get_title() {
        return esc_html__( 'Royal Services', 'royaltech' );
    }

    public function get_icon() {
        return 'royalicon eicon-post-list';
    }

    public function get_keywords() {
        return [ 'services', 'action', 'facility', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
    }

    public function get_categories() {
        return [ 'royaltech' ];
    }


	public function get_style_depends() {
		$styles = [ 'royalservices' ];
		return $styles;
	}


    public function _register_controls() {
        
        // Background Section
        $this->start_controls_section(
            'background_section',
            [
                'label' => __( 'Background', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'royaltech' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .royalelementservices',
			]
		);

        $this->end_controls_section();


        // Icon & Number Section
        $this->start_controls_section(
            'iconandnumber_section',
            [
                'label' => __( 'Icon & Number', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'text-domain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
                'skin' => 'inline',
                'label_block' => false,                
			]
		);


        $this->add_control(
            'number',
            [
                'label' => __( 'Number', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( '0', 'royaltech' ),
                'label_block' => false,
            ]
        );
        $this->end_controls_section();







        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Default title', 'royaltech' ),
                'label_block' => true,
                'placeholder' => __( 'Type your title here', 'royaltech' ),
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => __( 'Title Link', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'royaltech' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );  
        $this->add_control(
            'content',
            [
                'label' => __( 'Description', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Default description', 'royaltech' ),
                'placeholder' => __( 'Type your description here', 'royaltech' ),
            ]
        );

        $this->end_controls_section();




        // Style Tab
        $this->style_tab();
    }

    private function style_tab() {

        /* Services Style Section */
        $this->start_controls_section(
            'services_style_section',
            [
                'label' => __( 'Services Style', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        
        // Heading
        $this->add_control(
            'services_heading',
            [
                'label' => __( 'Services', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );
        
        
        // Service Padding
        $this->add_responsive_control(
            'services_padding',
            [
                'label' => __( 'Padding', 'royaltech' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default' => [
                    'top' => 20,
                    'right' => 20,
                    'bottom' => 20,
                    'left' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'description' => 'Default: 20px',
            ]
        );


        // Icon & Number
        $this->add_control(
            'icon_number_heading',
            [
                'label' => __( 'Icon & Number', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Service Padding
        $this->add_responsive_control(
            'iconandnumber_padding',
            [
                'label' => __( 'Padding', 'royaltech' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default' => [
                    'top' => 20,
                    'right' => 0,
                    'bottom' => 20,
                    'left' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .iconandnumber' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'description' => 'Default: 20px 0 20px 0',
            ]
        );        

        // Icon Color
        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Icon Color', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .iconandnumber .icon' => 'color: {{VALUE}}',
                ],
                'default' => '#FFF',
            ]
        );

        // Icon Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'icon_typography',
                'label' => __( 'Icon Typography', 'royaltech' ),
                'selector' => '{{WRAPPER}} .royalelementservices .iconandnumber .icon',
            ]
        );

        // Number Color
        $this->add_control(
            'number_color',
            [
                'label' => __( 'Icon Color', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .iconandnumber .number' => 'color: {{VALUE}}',
                ],
                'default' => '#FFF',
            ]
        );


        // Number Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'number_typography',
                'label' => __( 'Number Typography', 'royaltech' ),
                'selector' => '{{WRAPPER}} .royalelementservices .iconandnumber .number',
            ]
        );

        // Title heading
        $this->add_control(
            'content_title_heading',
            [
                'label' => __( 'Title', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Title Bottom Spacing
        $this->add_responsive_control(
            'content_title_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'royaltech' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'description' => 'Default: 15px',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );





        // Title Tabs
        $this->start_controls_tabs(
            'but_button_style_tabs'
        );
        // Normal State
        $this->start_controls_tab(
            'buy_button_normal_state',
            [
                'label' => __( 'Normal', 'royaltech' ),
            ]
        );

        // Title Color
        $this->add_control(
            'content_title_color',
            [
                'label' => __( 'Title Color', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .title' => 'color: {{VALUE}}',
                ],
                'default' => '#42B7DD',
            ]
        );

        // Title Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_title_typography',
                'label' => __( 'Typography', 'royaltech' ),
                'selector' => '{{WRAPPER}} .royalelementservices .title h2',
            ]
        );

        $this->end_controls_tab();


        // Title Hover Style
        $this->start_controls_tab(
            'title_hover_style',
            [
                'label' => __( 'Hover', 'royaltech' ),
            ]
        );

        // Title Color
        $this->add_control(
            'content_title_hover_color',
            [
                'label' => __( 'Title Hover Color', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .title:hover' => 'color: {{VALUE}}',
                ],
                'default' => '#10A6D7',
            ]
        );

        // Title Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_title_hover_typography',
                'label' => __( 'Typography', 'royaltech' ),
                'selector' => '{{WRAPPER}} .royalelementservices .title:hover',
            ]
        );

            $this->end_controls_tab();
            $this->end_controls_tabs();




        // Description heading
        $this->add_control(
            'content_description_heading',
            [
                'label' => __( 'Description', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Content Bottom Spacing
        $this->add_responsive_control(
            'content_Content_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'royaltech' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'description' => 'Default: 30px',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Content Color
        $this->add_control(
            'content_color',
            [
                'label' => __( 'Content Color', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .royalelementservices .content' => 'color: {{VALUE}}',
                ],
                'default' => '#FFF',
            ]
        );

        // Content Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __( 'Typography', 'royaltech' ),
                'selector' => '{{WRAPPER}} .royalelementservices .content',
            ]
        );

        $this->end_controls_section();
    }









    protected function render() {
        $settings = $this->get_settings_for_display();

        $target = $settings[ 'link' ][ 'is_external' ] ? ' target="_blank"' : '';
        $nofollow = $settings[ 'link' ][ 'nofollow' ] ? ' rel="nofollow"' : '';


        // For Inline Editing
        $this->add_inline_editing_attributes( 'number', 'none' );
        $this->add_inline_editing_attributes( 'title', 'none' );
        $this->add_inline_editing_attributes( 'content', 'advanced' );
        ?>
        <div class="royalelementservices">
            <div class="iconandnumber">
                <div class="icon"><i class="<?php echo $settings['icon']['value'] ?>"></i></div>
                <div class="number">
                <div <?php echo $this->get_render_attribute_string( 'number' ); ?>>
                            <?php echo $settings[ 'number' ]; ?>
                </div>
                </div>
            </div>
            <a href="<?php echo esc_url( $settings[ 'link' ][ 'url' ] ); ?>" <?php echo $target; ?> <?php echo $nofollow; ?>"><div class="title"><h2 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo $settings[ 'title' ]; ?></h2></div></a>
            <div class="content">
                <div <?php echo $this->get_render_attribute_string( 'content' ); ?>>
                            <?php echo $settings[ 'content' ]; ?>
                </div>                
            </div>
        </div>


        <?php
    }








    protected function _content_template() {
        ?>
        <#
		var target = settings.link.is_external ? ' target="_blank"' : '';
		var nofollow = settings.link.nofollow ? ' rel="nofollow"' : '';

        view.addInlineEditingAttributes( 'icon', 'none' );
        view.addInlineEditingAttributes( 'number', 'none' );
        view.addInlineEditingAttributes( 'title', 'none' );
        view.addInlineEditingAttributes( 'content', 'none' );
        #>
        <div class="royalelementservices">
            <div class="iconandnumber">
                <div class="icon"><i class="{{ settings.icon.value }}"></i></div>
                <div class="number"><div {{{ view.getRenderAttributeString( 'number' ) }}}>{{{ settings.number }}}</div></div>
            </div>
            <a href="{{ settings.link.url }}"{{ target }}{{ nofollow }}"><div class="title"><h2 {{{ view.getRenderAttributeString( 'title' ) }}} >{{{ settings.title }}}</h2></div></a>
            
            <div class="content">
                <div {{{ view.getRenderAttributeString( 'content' ) }}}>{{{ settings.content }}}</div>
            </div>

        </div>

        

        <?php
    }

}
