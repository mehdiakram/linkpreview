<?php

namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly



class RoyalAccordion extends Widget_Base{

  public function get_name(){
    return 'royalaccordion';
  }


  public function get_title(){
    return 'Royal Accordion';
  }


  public function get_icon(){
    return 'royalicon eicon-accordion';
  }


  public function get_keywords() {
    return [ 'accordion', 'tabs', 'toggle', 'royalaccordion', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
  }


  public function get_categories(){
    return ['royaltech'];
  }


	public function get_style_depends() {
		$styles = [ 'royalaccordion' ];
		return $styles;
	}


  protected function _register_controls(){

   $this->start_controls_section(
      'content_section',
      [
        'label' => __( 'Royal Accordion', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $repeater = new \Elementor\Repeater();

    $repeater->add_control(
      'royal_acc_title',
      [
        'label' => __( 'Title', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __( 'SM Mehdi Akram', 'royaltech' ),
        'placeholder' => __( 'Type your title here', 'royaltech' ),
      ]
    );



    $repeater->add_control(
      'royal_acc_description',
      [
        'label' => __( 'Description', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::WYSIWYG,
        'rows' => 10,
        'default' => __( 'SM Mehdi Akram is IT specialist in Bangladesh', 'royaltech' ),
        'placeholder' => __( 'Type your description here', 'royaltech' ),
      ]
    );



    $this->add_control(
      'royalaccordions',
      [
        'label' => __( 'Accordions Items', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $repeater->get_controls(),
        'default' => [
          [
            'royal_acc_title' => __( 'Accordion #1', 'royaltech' ),
            'royal_acc_description' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'royaltech' ),
          ],
          [
            'royal_acc_title' => __( 'Accordion #2', 'royaltech' ),
            'royal_acc_description' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'royaltech' ),
          ],
        ],
        'title_field' => '{{{ royal_acc_title }}}',
      ]
    );


    $this->add_control(
      'royal_acc_icon_open',
      [
        'label' => __( 'Icon Open', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'separator' => 'before',
        'fa4compatibility' => 'icon',
        'default' => [
          'value' => 'fas fa-plus',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-solid' => [
            'chevron-down',
            'angle-down',
            'angle-double-down',
            'caret-down',
            'caret-square-down',
          ],
          'fa-regular' => [
            'caret-square-down',
          ],
        ],
        'skin' => 'inline',
        'label_block' => false,        
      ]
    );



    $this->add_control(
      'royal_acc_icon_close',
      [
        'label' => __( 'Icon Close', 'royaltech' ),
        'type' => \Elementor\Controls_Manager::ICONS,
        'fa4compatibility' => 'icon_active',
        'default' => [
          'value' => 'fas fa-minus',
          'library' => 'fa-solid',
        ],
        'recommended' => [
          'fa-solid' => [
            'chevron-up',
            'angle-up',
            'angle-double-up',
            'caret-up',
            'caret-square-up',
          ],
          'fa-regular' => [
            'caret-square-up',
          ],
        ],
        'skin' => 'inline',
        'label_block' => false,  
        'condition' => [
          'royal_acc_icon_open[value]!' => '',
        ],                
      ]
    );



    $this->end_controls_section();




    $this->start_controls_section(
      'accordion_color_section',
      [
        'label' => __( 'Accordion Colors', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );

  
   $this->add_control(
        'title_bg_color_close',
        [
            'label' => __( 'Title Background Color Close', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#6EC1E4',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_1,
            ],
            'selectors' => [
                '{{WRAPPER}} .close h3.royalaccitemheading' => 'background: {{VALUE}}',
            ],
        ]
    );

   $this->add_control(
        'title_bg_color_open',
        [
            'label' => __( 'Title Background Color Open', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#DBDBDB',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_2,
            ],
            'selectors' => [
                '{{WRAPPER}} .open h3.royalaccitemheading' => 'background: {{VALUE}}',
            ],
        ]
    );   


   $this->add_control(
        'body_bg_color',
        [
            'label' => __( 'Body Background Color', 'royaltech' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '#F2F2F2',
            'scheme' => [
                'type' => \Elementor\Core\Schemes\Color::get_type(),
                'value' => \Elementor\Core\Schemes\Color::COLOR_3,
            ],
            'selectors' => [
                '{{WRAPPER}} .royalaccitemcontent' => 'background: {{VALUE}}',
            ],
        ]
    );     


   $this->end_controls_section();   





    $this->start_controls_section(
      'accordion_typography_section',
      [
        'label' => __( 'Accordion Typography', 'royaltech' ),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
      ]
    );
    $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'title_typo',
        'label' => __( 'Title', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
        'selector' => '{{WRAPPER}} h3.royalaccitemheading',
      ]
    );

        $this->add_group_control(
      \Elementor\Group_Control_Typography::get_type(),
      [
        'name' => 'desc_typo',
        'label' => __( 'Description', 'royaltech' ),
        'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_3,
        'selector' => '{{WRAPPER}} .royalaccitemcontent div',
      ]
    );
        $this->end_controls_section();



  }
  



  protected function render() {
    $settings = $this->get_settings_for_display();

    if ( $settings['royalaccordions'] ) {
        echo '<div class="royalaccwrapper">';
        foreach (  $settings['royalaccordions'] as $item ) { ?>
        <div class="royalaccitem item-<?php echo $item['_id'] ?> close">
            <h3 class="royalaccitemheading"><?php echo $item['royal_acc_title'] ?> <span class="openicon"><i class="<?php echo $settings['royal_acc_icon_open']['value'] ?>"></i></span><span class="closeicon"><i class="<?php echo $settings['royal_acc_icon_close']['value'] ?>"></i></span></h3>
            <div class="royalaccitemcontent">
                <div><?php echo $item['royal_acc_description'] ?></div>
            </div>
        </div>
        <?php }
        echo '</div>';
    }

    ?>
    <style type="text/css">
    .close h3.royalaccitemheading{
      background-color: <?php echo $settings['title_bg_color_close'] ?>;
    }

    .open h3.royalaccitemcontent{
      background-color: <?php echo $settings['title_bg_color_open'] ?>;
    }

    .royalaccitemcontent{
      background-color: <?php echo $settings['body_bg_color'] ?>;
    }
    </style>

    <script type="text/javascript">
    jQuery(function() {
        //
        var accwarp = document.getElementsByClassName('royalaccwrapper');
        var accitem1st = accwarp[0].children[0];
        accitem1st.classList.remove("close");
        accitem1st.className += ' open';


        var accItem = document.getElementsByClassName('royalaccitem');
        var accHD = document.getElementsByClassName('royalaccitemheading');

        for (i = 0; i < accHD.length; i++) {
            accHD[i].addEventListener('click', toggleItem, false);
        }
        function toggleItem() {
            var itemClass = this.parentNode.className;
            for (i = 0; i < accItem.length; i++) {
                accItem[i].className = 'royalaccitem close';
            }
            if (itemClass == 'royalaccitem close') {
                this.parentNode.className = 'royalaccitem open';
            }
        }

        //
    });
    </script>    
    <?php



  }









}