<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class RoyalPostCategory extends Widget_Base {

	public function get_name() {
		return 'royalpostcategory';
	}


	public function get_title() {
		return __( 'Royal Post Category', 'royaltech' );
	}


	public function get_icon() {
		return 'royalicon eicon-post-list';
	}


	public function get_keywords() {
		return [ 'List', 'Post', 'Category', 'Blog', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = ['royalpost'];
		return $styles;
	}


	protected function _register_controls() {

		$this->rt_content_layout_options();
		$this->rt_style_box_options();
	}

	/**
	 * Content Layout Options.
	 */
	private function rt_content_layout_options() {

		$this->start_controls_section(
			'post_query_section',
			[
				'label' => esc_html__( 'Post Query', 'royaltech' ),
			]
		);

		$this->add_control(
			'cat_style',
			[
				'label' => __( 'Category Style', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style1' 	=> 'Style 1',
					'style2' 	=> 'Style 2',
					'style3' 	=> 'Style 3',
					'style4' 	=> 'Style 4',
				],
				'default' => 'style1',
			]
		);


		$this->add_control(
			'post_category',
			[
				'label'       => __( 'Category', 'royaltech' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'multiple'    => true,
				'options'     => \RoyalAddons\Elementor\RoyalClass::royal_categories('post' ),

			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label' => __( 'Posts Per Page', 'royaltech' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5,
			]
		);
		
		$this->add_control(
			'offset',
			[
				'label' => __( 'Posts Offset', 'royaltech' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'post_cat_title_section',
			[
				'label' => esc_html__( 'Category Title', 'royaltech' ),
			]
		);


		$this->add_control(
			'cat_show',
			[
				'label' => __( 'Category Title Show', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'original' 	=> 'Original Cat Name',
					'custom' 	=> 'Custom Cat Name',
					'no' 		=> 'Hide Cat Name',
				],
				'default' => 'original',
			]
		);

		$this->add_control(
			'custom_title',
			[
				'label' => __( 'Custom Category Title', 'royaltech' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Category Name', 'royaltech' ),
				'condition' => [
					'cat_show' => 'custom',
				],				
			]
		);

		$this->add_control(
			'category_title_url',
			[
				'label' => __( 'Category Title URL', 'royaltech' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'default' => 'yes',
				'separator' => 'before',
				'condition' => [
					'show_all_button' => 'yes',
					'cat_show!' 	=> 'no',
				],					
			]
		);

		$this->add_control(
			'content_align',
			[
				'label' => __( 'Title Alignment', 'royaltech' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'condition' => [
					'cat_show!' 	=> 'no',
				],				
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory h2' => 'text-align: {{VALUE}};',
				],
				'separator' => 'after',
			]
		);


		// Title typography.
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
				'selector' => '{{WRAPPER}} .royalpostcategory h2',
			]
		);


		$this->start_controls_tabs( 'cat_title_color_tabs' );
		// Normal tab.
		$this->start_controls_tab(
			'cat_title_style_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'royaltech' ),
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
			)
		);

		// Title color.
		$this->add_control(
			'cat_title_style_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_SECONDARY,
				],
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .royalpostcategory h2 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		// Hover tab.
		$this->start_controls_tab(
			'cat_title_style_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'royaltech' ),
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
			)
		);

		// Title hover color.
		$this->add_control(
			'cat_title_style_hover_color',
			array(
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
				'selectors' => array(
					'{{WRAPPER}} .royalpostcategory h2:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .royalpostcategory h2 a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'cat_title_style_margin',
			[
				'label'      => __( 'Margin', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cat_title_style_padding',
			[
				'label'      => __( 'Padding', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'condition' => [
					'cat_show!' 	=> 'no',
				],					
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cat_title_border_width',
			[
				'label'      => __( 'Title Border', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory h2' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'cat_title_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Title Border Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory h2' => 'border-color: {{VALUE}};',
				],
			]
		);	


		$this->end_controls_section();


		$this->start_controls_section(
			'post_post_thumbnail_section',
			[
				'label' => esc_html__( 'Post Thumbnail', 'royaltech' ),
			]
		);


		$this->add_control(
			'show_thumbnail',
			[
				'label' => __( 'Show Thumbnail', 'royaltech' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'default' => '',
				'condition' => [
					'cat_style!' => 'style1',
				],					
			]
		);

		$this->add_responsive_control(
			'thumbnail_style_margin',
			[
				'label'      => __( 'Margin', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'condition' => [
					'cat_style!' => 'style1',
					'show_thumbnail' => 'yes',
				],					
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .thumbnail img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_style_padding',
			[
				'label'      => __( 'Padding', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'condition' => [
					'cat_style!' => 'style1',
					'show_thumbnail' => 'yes',
				],					
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .thumbnail img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'thumbnail_border_width',
			[
				'label'      => __( 'Border', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'condition' => [
					'cat_style!' => 'style1',
					'show_thumbnail' => 'yes',
				],					
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .thumbnail img' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'thumbnail_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'condition' => [
					'cat_style!' => 'style1',
					'show_thumbnail' => 'yes',
				],					
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .thumbnail img' => 'border-color: {{VALUE}};',
				],
			]
		);	







		$this->end_controls_section();


		$this->start_controls_section(
			'post_post_content_section',
			[
				'label' => esc_html__( 'Post Content', 'royaltech' ),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
					'post_date' => __( 'Date', 'royaltech' ),
					'post_title' => __( 'Title', 'royaltech' ),
					'rand' => __( 'Random', 'royaltech' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'royaltech' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __( 'ASC', 'royaltech' ),
					'desc' => __( 'DESC', 'royaltech' ),
				],
			]
		);

		$this->add_control(
			'list_icon',
			[
			  'label' => __( 'List Icon', 'royaltech' ),
			  'type' => \Elementor\Controls_Manager::ICONS,
			  'separator' => 'before',
			  'fa4compatibility' => 'icon',
			  'condition' => [
				'cat_style' => 'style1',
			],			  
			  'default' => [
				'value' => 'fas fa-caret-right',
				'library' => 'fa-solid',
			  ],
			  'recommended' => [
				'fa-solid' => [
				  'angle-right',
				  'angle-double-right',
				  'chevron-circle-right',
				  'long-arrow-alt-right',
				  'arrow-alt-circle-right',
				  'arrow-right',
				  'play',
				],
				'fa-regular' => [
				  'caret-square-right',
				],
			  ],
			  'skin' => 'inline',
			  'label_block' => false,        
			]
		  );

		  $this->add_control(
			'list_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'List Color', 'royaltech' ),
				'default' 	=> '#29C944',
				'condition' => [
					'cat_style' => 'style1',
				],					
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory ul li>i' => 'color: {{VALUE}};',
				],
			]
		);	

		  $this->add_control(
			'postexcerpt',
			[
				'label' => __( 'Post Excerpt', 'royaltech' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 40,
				'condition' => [
					'cat_style!' => 'style1',
				],					
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'post_title_typography',
				'label' => __( 'Post Title Typography', 'royaltech' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .royalpostcategory ul li a',
			]
		);

		$this->start_controls_tabs( 'post_title_style_color_tabs' );
		// Normal tab.
		$this->start_controls_tab(
			'post_title_color_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'royaltech' ),
			)
		);

		$this->add_control(
			'post_title_color_normal',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Post Title Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory h3 a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		

		// Hover tab.
		$this->start_controls_tab(
			'post_title_color_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'royaltech' ),
			)
		);
		$this->add_control(
			'post_title_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Post Title Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory h3 a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_tab();
		$this->end_controls_tabs();


		$this->add_control(
			'post_title_border_width',
			[
				'label'      => __( 'Post Title Border', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory ul li a' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'post_title_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Post Title Border Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory ul li a' => 'border-color: {{VALUE}};',
				],
			]
		);		

		$this->add_responsive_control(
			'post_title_style_margin',
			[
				'label'      => __( 'Post Title Margin', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory ul li h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'post_title_style_padding',
			[
				'label'      => __( 'Post Title Padding', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory ul li h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

	


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'post_content_typography',
				'label' => __( 'Post Content Typography', 'royaltech' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'condition' => [
					'cat_style!' => 'style1',
				],				
				'selector'  => '{{WRAPPER}} .royalpostcategory .royalpostexcerpt',
			]
		);

		$this->add_control(
			'post_content_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Post Content Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'condition' => [
					'cat_style!' => 'style1',
				],					
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .royalpostexcerpt' => 'color: {{VALUE}};',
				],
			]
		);	

		$this->end_controls_section();








		$this->start_controls_section(
			'post_cat_button_section',
			[
				'label' => esc_html__( 'Button', 'royaltech' ),
			]
		);

		$this->add_control(
			'show_all_button',
			[
				'label' => __( 'Show All Button', 'royaltech' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_all_text',
			[
				'label' => __( 'Show All Text', 'royaltech' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Show All', 'royaltech' ),
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);

		$this->add_control(
			'show_all_url',
			[
				'label' => __( 'Custom URL', 'royaltech' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'royaltech' ),
				'label_off' => __( 'Hide', 'royaltech' ),
				'default' => 'yes',
				'condition' => [
					'show_all_button' => 'yes',
				],					
			]
		);


		$this->add_control(
			'show_all_custom_url',
			[
				'label' => __( 'Show All URL', 'royaltech' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '#', 'royaltech' ),
				'condition' => [
					'show_all_button' 	=> 'yes',
					'show_all_url' 		=> 'yes',
				],				
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'button_style_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .royalpostcategory .allbutton',
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);


		$this->start_controls_tabs( 'button_text_style_normal_tabs' );
        // Normal tab.
		$this->start_controls_tab(
			'button_text_style_normal_tab',
			[
				'label'     => __( 'Normal', 'royaltech' ),
				'condition' => [
					'show_all_button' => 'yes',
				],					
			]
		);

		$this->add_control(
			'button_text_color_normal',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .allbutton' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);

		$this->add_control(
			'button_bg_color_normal',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'royaltech' ),
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .allbutton' => 'background: {{VALUE}};',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);		

		$this->end_controls_tab();


        // Hover tab.
		$this->start_controls_tab(
			'button_text_style_hover_tab',
			[
				'label'     => __( 'Hover', 'royaltech' ),
				'condition' => [
					'show_all_button' => 'yes',
				],					
			]
		);
		
		$this->add_control(
			'button_text_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .allbutton:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'royaltech' ),
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .allbutton:hover' => 'background: {{VALUE}};',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);			

		$this->end_controls_tab();
		$this->end_controls_tabs();




		$this->add_responsive_control(
			'button_style_padding',
			[
				'label'      => __( 'Padding', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .allbutton' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);

		$this->add_control(
			'button_border_width',
			[
				'label'      => __( 'Border', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .allbutton' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);

		$this->add_control(
			'button_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'royaltech' ),
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .allbutton' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_all_button' => 'yes',
				],				
			]
		);	





		$this->end_controls_section();

	}


	private function rt_style_box_options() {

		// Box.
		$this->start_controls_section(
			'section_box',
			[
				'label' => __( 'Block Style', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'block_border_width',
			[
				'label'      => __( 'Block Border Widget', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .catblock' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'block_order_radius',
			[
				'label'     => __( 'Border Radius', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 0,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .catblock' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'block_style_padding',
			[
				'label'      => __( 'Padding', 'royaltech' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .royalpostcategory .catblock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->start_controls_tabs( 'grid_button_style' );


		// Normal tab.
		$this->start_controls_tab(
			'block_style_normal',
			[
				'label'     => __( 'Normal', 'royaltech' ),
			]
		);

		// Normal background color.
		$this->add_control(
			'block_style_normal_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .catblock' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Normal border color.
		$this->add_control(
			'block_style_normal_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .catblock' => 'border-color: {{VALUE}};',
				],
			]
		);

		// Normal box shadow.
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'block_style_normal_box_shadow',
				'selector'  => '{{WRAPPER}} .royalpostcategory .catblock',
			]
		);

		$this->end_controls_tab();

		// Hover tab.
		$this->start_controls_tab(
			'block_style_hover',
			[
				'label'     => __( 'Hover', 'royaltech' ),
			]
		);

		// Hover background color.
		$this->add_control(
			'block_style_hover_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .catblock:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Hover border color.
		$this->add_control(
			'block_style_hover_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'royaltech' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .royalpostcategory .catblock:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		// Hover box shadow.
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'block_style_hover_box_shadow',
				'selector'  => '{{WRAPPER}} .royalpostcategory .catblock:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

	}




	protected function render_royalpostexcerpt() {
		$settings 				= $this->get_settings();
		$postexcerpt 			= ( ! empty( $settings['postexcerpt'] ) ?  $settings['postexcerpt'] : 40 );		
		\RoyalAddons\Elementor\RoyalClass::royalpostexcerpt($postexcerpt);
	}


	protected function render() {
		$settings 				= $this->get_settings();
		$posts_per_page 		= ( ! empty( $settings['posts_per_page'] ) ?  $settings['posts_per_page'] : 5 );
		$offset 				= ( ! empty( $settings['offset'] ) ?  $settings['offset'] : 0 );
		$cat_style 				= $settings['cat_style'];
		$show_thumbnail			= $settings['show_thumbnail'];
		$cat_show 				= $settings['cat_show'];
		$custom_title 			= $settings['custom_title'];
		$category_title_url 	= $settings['category_title_url'];
		$cat 					= $settings['post_category'];
		$show_all_button		= $settings['show_all_button'];
		$show_all_text			= $settings['show_all_text'];
		$show_all_url			= $settings['show_all_url'];
		$show_all_custom_url	= $settings['show_all_custom_url'];
		$idObj 					= get_category_by_slug($cat); 
		$category_id 			= $idObj->term_id;		
		$category_link 			= get_category_link( $category_id );
		$category_name			= get_cat_name( $category_id = $category_id );

		$query_args 			= array(
			'posts_per_page' 		=> absint( $posts_per_page ),
			'no_found_rows'  		=> true,
			'post_status'         	=> 'publish',
			'ignore_sticky_posts'   => true,
			'offset' 				=> $offset,
			'category_name' 		=> $cat
		);
		// Order by.
		if ( ! empty( $settings['orderby'] ) ) {
			$query_args['orderby'] = $settings['orderby'];
		}

		// Order .
		if ( ! empty( $settings['order'] ) ) {
			$query_args['order'] = $settings['order'];
		}

		// Category Title
		if('yes' == $category_title_url){
			if ('original' == $cat_show){
				$royalcattitle = '<h2><a href="'.esc_url( $category_link ).'">'.$category_name.'</a></h2>';			
			}elseif('custom' == $cat_show ){
				$royalcattitle = '<h2><a href="'.esc_url( $category_link ).'">'.$custom_title.'</a></h2>';
			}
		} else{
			if ('original' == $cat_show){
				$royalcattitle = '<h2>'.$category_name.'</h2>';			
			}elseif('custom' == $cat_show ){
				$royalcattitle = '<h2>'.$custom_title.'</h2>';
			}
		}

		// All Button
		if ('yes' == $show_all_button){					
			if('' == $show_all_url){
				$royalallbutton = '<a class="allbutton" href="'.esc_url( $category_link ).'">'.$show_all_text.'</a>';
			} elseif('yes' == $show_all_url){
				$royalallbutton ='<a class="allbutton" href="'.esc_url( $show_all_custom_url ).'">'.$show_all_text.'</a>';
			}										
		}
		
		$all_posts = new \WP_Query( $query_args );
		echo '<div class="royalpostcategory">';
		?>
		<?php if( 'style1' == $cat_style ){ ?>
			<div class="style1">		
			<div class="catblock">
				<?php echo $royalcattitle; ?>
				<ul>
				<?php
				if ( $all_posts->have_posts() ) :
					while ( $all_posts->have_posts() ) :
						$all_posts->the_post(); ?>
						<li><h3><i class="<?php echo $settings['list_icon']['value'] ?>"></i><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</li>	
					<?php endwhile; 						
				endif; ?>
				</ul>
			</div>	
			<?php echo $royalallbutton; ?>
			</div>


		<?php } elseif( 'style2' == $cat_style ){ ?>
			<div class="style2">		
			<div class="catblock">
				<?php echo $royalcattitle; ?>			
				<ul>
				<?php
				if ( $all_posts->have_posts() ) :
					while ( $all_posts->have_posts() ) :
						$all_posts->the_post(); ?>
						<li>
						<?php if ('yes' == $show_thumbnail){?>
						<div class="thumbnail">
							<?php 
							if ( has_post_thumbnail() ) {
								the_post_thumbnail('thumbnail', array('class' => '', 'alt' => ''));
								}							
							?>
						</div>
						<?php } ?>
						<div class="content">				
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<div class="royalpostexcerpt"><?php $this->render_royalpostexcerpt(); ?></div>
						</div>
					</li>	
					<?php endwhile; 						
				endif; ?>
				</ul>
			</div>
			<?php echo $royalallbutton; ?>
			</div>
		<?php } else{ ?>
			<div class="style1">		
			<div class="catblock">
				<?php echo $royalcattitle; ?>			
				<ul>
				<?php
				if ( $all_posts->have_posts() ) :
					while ( $all_posts->have_posts() ) :
						$all_posts->the_post(); ?>
						<li><i class="<?php echo $settings['list_icon']['value'] ?>"></i><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</li>
					<?php endwhile; 						
				endif; ?>
				</ul>
			</div>
			<?php echo $royalallbutton; ?>
			</div>	
		<?php } ?> 
			
		</div>
		<?php
	}



}	