<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly



class RoyalPriceList extends Widget_Base {

	public function get_name() {
		return 'royalpricelist';
	}

	public function get_title() {
		return 'Royal Price List';
	}

	public function get_icon() {
		return 'royalicon eicon-price-list';
	}

	public function get_keywords() {
		return [ 'Price', 'List', 'Menu', 'Menu List', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}


	public function get_categories() {
		return [ 'royaltech' ];
	}


	public function get_style_depends() {
		$styles = [ 'royalpricelist' ];
		return $styles;
	}

	
    protected function _register_controls() {
		$controls = $this;

        $controls->start_controls_section(
			'list_settings',
			[
				'label' => esc_html__( 'List', 'royaltech' )
			]
		);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'royaltech' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Exciting Feature', 'royaltech' ),
            ]
        );

		$repeater->add_control(
			'currency',
			[
				'label' => __( 'Currency', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'BDT',
				'options' => [
					'USD'  => __( 'USD', 'royaltech' ),
					'BDT' 	=> __( 'BDT', 'royaltech' ),
					'' 	=> __( 'None', 'royaltech' ),
				],
			]
		);


        $repeater->add_control(
            'price',
            [
                'label' => __( 'Price', 'royaltech' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '10', 'royaltech' ),
            ]
        );
		

        $repeater->add_control(
            'details',
            [
                'label' => __( 'Details', 'royaltech' ),
                'type' => Controls_Manager::TEXT,
				'default' => __( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'royaltech' ),
            ]
        );

        $repeater->add_control(
			'image',
			[
			  'label' => __( 'Price Menu Image', 'royaltech' ),
			  'type' => \Elementor\Controls_Manager::MEDIA,
			  'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			  ],
			]
		);


        $controls->add_control(
			'price_list',
			[
			  'label' => __( 'Price List Items', 'royaltech' ),
			  'type' => \Elementor\Controls_Manager::REPEATER,
			  'fields' => $repeater->get_controls(),
			  'show_label' => false,
			  'default' => [
				  [
					  'title' 		=> __( 'Chicken Dhaga Kabab', 'royaltech' ),
					  'currency' 	=> __( 'BDT', 'royaltech' ),
					  'price' 		=> __( '120', 'royaltech' ),					  
					  'details' 	=> __( 'Chicken Dhaga Kabab Just about everyone has eaten a kabab at one time or another in their lifetime', 'royaltech' ),
				  ],
				  [
					  'title'		=> __( 'Chicken Biryani', 'royaltech' ),
					  'currency' 	=> __( 'BDT', 'royaltech' ),
					  'price' 		=> __( '200', 'royaltech' ),
					  'details' 	=> __( 'Traditional chicken biryani is made by layering marinated chicken and then layered with parboiled rice, herbs,saffron milk & then ghee.', 'royaltech' ),
				  ],
				  [
					  'title' 		=> __( 'Burger', 'royaltech' ),
					  'currency' 	=> __( 'BDT', 'royaltech' ),
					  'price' 		=> __( '90', 'royaltech' ),
					  'details' 	=> __( 'Where are the Burger lovers? Are you Craving for some Cheesy trip to extra Happiness? A regular bite on Regular Chicken Cheese Burger will drive you', 'royaltech' ),
				  ],
				  [
					'title' 		=> __( 'Water', 'royaltech' ),
					'currency' 		=> '',
					'price' 		=> __( 'FREE', 'royaltech' ),
					'details' 		=> __( 'Water is always free', 'royaltech' ),
				],
  
			  ],
			  'title_field' => '{{{ title }}}',
			]
		  );

		  
		$controls->end_controls_section();


		

        $controls->start_controls_section(
            '_section_style_general',
            [
                'label' => __( 'General Style', 'royaltech' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $controls->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __( 'Background', 'royaltech' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .royalpricelist',
            ]
        );


		$controls->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'royaltech' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalpricelist' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$controls->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'royaltech' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royalpricelist' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);



		$controls->add_control(
			'item_separated_border_width',
			[
				'label' => __( 'Item Separated Border Width', 'royaltech' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$controls->end_controls_section();




        $controls->start_controls_section(
            '_section_style_title',
            [
                'label' => __( 'Title Style', 'royaltech' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );



		$controls->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title & Price Color', 'royaltech' ),
				'type'  => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem .itemandprice' => 'color: {{VALUE}};',
				],				
			]
		);

		$controls->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
			  'name' => 'title_typo',
			  'label' => __( 'Title Typography', 'royaltech' ),
			  'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
			  'selector' => '{{WRAPPER}} .royalpricelist .rplitem .itemandprice',
			]
		  );

		$controls->add_control(
			'title_border_style',
			[
				'label' => __( 'Border Type', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'dotted',
				'options' => [
					'dotted'  	=> __( 'Dotted', 'royaltech' ),
					'dashed' 	=> __( 'Dashed', 'royaltech' ),
					'double' 	=> __( 'Double', 'royaltech' ),
					'solid' 	=> __( 'Solid', 'royaltech' ),
					'none' 		=> __( 'None', 'royaltech' ),
				],
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem .itemandprice:after' => 'border-bottom-style: {{VALUE}};',
				],					
			]
		);



		$controls->add_control(
			'title_border_color',
			[
				'label' => esc_html__( 'Title & Price Color', 'royaltech' ),
				'type'  => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem .itemandprice:after' => 'border-bottom-color: {{VALUE}};',
				],				
			]
		);


		$controls->add_control(
			'title_border_width',
			[
				'label' => __( 'Title Border Width', 'royaltech' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem .itemandprice:after' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		  
		$controls->end_controls_section();


		

        $controls->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Content Style', 'royaltech' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );


		$controls->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'royaltech' ),
				'type'  => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .royalpricelist .rplitem .rplcontainer .rplitemcontent' => 'color: {{VALUE}};',
				],				
			]
		);


		$controls->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
			  'name' => 'content_typo',
			  'label' => __( 'Content Typography', 'royaltech' ),
			  'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_3,
			  'selector' => '{{WRAPPER}} .royalpricelist .rplitem .rplcontainer .rplitemcontent',
			]
		  );



		$controls->end_controls_section();


	}

	protected function render() {
		$settings = $this->get_settings_for_display();
	?>

	<div class="royalpricelist">
	<?php foreach ( $settings['price_list'] as $index => $pricelist ) : ?>   
	<div class="rplitem">
		<?php echo wp_get_attachment_image( $pricelist['image']['id'], 'thumbnail' ); ?>
		<div class="rplcontainer">
		<div class="itemandprice">
		<span><?php echo $pricelist['title'];?></span>
		<span><?php echo $pricelist['currency'];?><?php echo $pricelist['price'];?></span>
		</div>
		<div class="rplitemcontent"><?php echo $pricelist['details'];?></div>
		</div>
	</div>  
	<?php endforeach; ?> 

	</div>	
	
	<?php
	}	
	protected function content_template() {


	}

	


}

