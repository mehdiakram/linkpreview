<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class RoyalContactForm7 extends Widget_Base {

    public function get_name() {
        return 'royalcontactform7';
    }

    public function get_title() {
        return __( 'Royal Contact Form 7', 'royaltech' );
    }

    public function get_icon() {
        return 'royalicon eicon-mail';
    }

    public function get_categories() {
        return array( 'royaltech' );
    }

    public function get_form() {
        $forms = get_posts( array( 'post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1 ) );

        $form_info = array();
        
        foreach( $forms as $form ){
            $form_info = array(
                "[contact-form-7 id='" . $form->ID . "' title='" . $form->post_title . "']" => $form->post_title
            );
        }
        return $form_info;
    }


    protected function _register_controls() {
        $this->start_controls_section(
            'section_cf7',
            [
                'label' => __( 'Contact Form 7', 'royaltech' ),
            ]
        );


        $this->add_control(
            'royalcf7',
            [
                'type' => Controls_Manager::SELECT,
                'label' => __( 'Select a Form', 'royaltech' ),
                'default' => '',
                'options' => self::get_form()
            ]
        );


        $this->add_control(
            'field_border_color',
            [
                'label' => __( 'Fields Border Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="text"]'  => 'border-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="email"]' => 'border-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 textarea'            => 'border-color:{{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'field_background_color',
            [
                'label' => __( 'Fields Background Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="text"]'  => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="email"]' => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 textarea'            => 'background-color:{{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'field_text_color',
            [
                'label' => __( 'Fields Text Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="text"]'  => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="email"]' => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 textarea'            => 'color:{{VALUE}};',
                ]
            ]
        );



        $this->start_controls_tabs( '_tab_images' );
        $this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Button Normal', 'royaltech' ),
            ]
        );



        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Button Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="reset"]'  => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="submit"]' => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="search"]' => 'background-color:{{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Button Text Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="reset"]'  => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="submit"]' => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="search"]' => 'color:{{VALUE}};',
                ]
            ]
        );





        $this->end_controls_tab();


        $this->start_controls_tab(
            '_tab_button_hover',
            [
                'label' => __( 'Button Hover', 'royaltech' ),
            ]
        );


        $this->add_control(
            'button_background_color_hover',
            [
                'label' => __( 'Button Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="reset"]:hover'  => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="submit"]:hover' => 'background-color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="search"]:hover' => 'background-color:{{VALUE}};',
                ]
            ]
        );

        $this->add_control(
            'button_text_color_hover',
            [
                'label' => __( 'Button Text Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .royalcf7 input[type="reset"]:hover'  => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="submit"]:hover' => 'color:{{VALUE}};',
                    '{{WRAPPER}} .royalcf7 input[type="search"]:hover' => 'color:{{VALUE}};',
                ]
            ]
        );



        $this->end_controls_tab();
        $this->end_controls_tabs();

















        $this->add_control(
            'extraclass',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __( 'Extra Class', 'royaltech' ),
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'royaltech' ),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $extraclass = $settings['extraclass'];
        $royalcf7 = $settings['royalcf7'];

        echo '<div class="royalcf7 '. $extraclass . '">' . do_shortcode( $royalcf7 ) . '</div>';
    }



    protected function content_template() {
        
    }

}
