<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class RoyalTyping extends Widget_Base {

    public function get_name() {
        return 'royaltyping';
    }


    public function get_title() {
        return 'Royal Typing';
    }


    public function get_icon() {
        return 'royalicon eicon-animation-text';
    }


    public function get_keywords() {
        return [ 'Typed', 'Typing', 'Type', 'Text', 'Animation', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
    }

      
    public function get_categories() {
        return array('royaltech');
    }

	public function get_style_depends() {
		$styles = [ 'royaltyping' ];
		return $styles;
	}

	public function get_script_depends() {
		$scripts = ['royaltypedcustom'];
		return $scripts;
	}	


    protected function _register_controls() {
        $this->start_controls_section(
            'section_typing_text',
            [
                'label' => __('Typing', 'royaltech'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(

            'static_text',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Static Text', 'royaltech'),
                'default' => __('Hi ', 'royaltech'),
                'prefix_class' => 'melo-typing-',
            ]
        );

        $this->add_control(

            'typing_text',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label' => __('Typing Text', 'royaltech'),
                'default' => __('This is SM Mehdi Akram', 'royaltech'),
                'description' => __('One sentence or word per line.', 'royaltech'),
            ]
        );

        $this->add_control(

            'extra_class',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Extra Class', 'royaltech'),
                'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'royaltech'),
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label' => __( 'Alignment', 'royaltech' ),
                'type' => Controls_Manager::CHOOSE,
                'default' => 'left',
                'options' => array(
                    'left'    => array(
                        'title' => __( 'Left', 'royaltech' ),
                        'icon' => 'fa fa-align-left',
                    ),
                    'center' => array(
                        'title' => __( 'Center', 'royaltech' ),
                        'icon' => 'fa fa-align-center',
                    ),
                    'right' => array(
                        'title' => __( 'Right', 'royaltech' ),
                        'icon' => 'fa fa-align-right',
                    ),
                ),
                'selectors' => [
                    '{{WRAPPER}} .royaltypingtext' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'section_typing_style',
            [
                'label' => __('Text', 'royaltech'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => __( 'Text Color', 'royaltech' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .royaltypingtext' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'scheme' => Typography::TYPOGRAPHY_2,
                'selector' => '{{WRAPPER}} .royaltypingtext',
            ]
        );

        $this->end_controls_section();
    }



    protected function render() {
        $settings = $this->get_settings_for_display();
        $extraclass = $settings['extra_class'];

        $royal_typing_id           =   'royaltyping'.esc_attr( $this->get_id() );
        $royal_typing_text_color   =   $settings['text_color'];
        $royal_typing_static_text  =   $settings['static_text'];
        $typing_text               =   $settings['typing_text'];
        $royal_typing_text         =   preg_split( "/((\r?\n)|(\r\n?))/", wp_strip_all_tags($typing_text ) );
        $royal_typing_text         =   array_map( 'trim', $royal_typing_text ); //trim blank space char.
        $royal_typing_text         =   array_map(function($string) { return '"' . $string . '"';}, $royal_typing_text);

        $royal_typing_text_string  =   implode( ",",$royal_typing_text ); //convert array to string.
        $royal_typing_inline_style =   '';
        $royal_typing_separator    =   ',';

        if( $royal_typing_text_color !== '#000000' ){
            $royal_typing_inline_style = 'style="color:'.esc_attr( $royal_typing_text_color ) . '"';
        }

        if( $royal_typing_text !== '' ):
        ?>
        <div class="royaltypingtext <?php echo esc_attr($extraclass);?>" <?php echo $royal_typing_inline_style;?>>
          <?php echo esc_attr( $royal_typing_static_text );?>
          <span id="<?php echo esc_attr( $royal_typing_id ); ?>"></span>
        </div>

        <script type="text/javascript">
        jQuery(function($){
             $("#<?php echo $royal_typing_id;?>").typed({
                 strings: [<?php echo $royal_typing_text_string; ?>],
                 typeSpeed: 50,
                 loop:true
             });
        });
        </script>

        <?php endif;

    }



    protected function content_template() {
        
    }

}
