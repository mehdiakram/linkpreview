<?php
namespace RoyalAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
if (!defined('ABSPATH')) exit; // Exit if accessed directly


class RoyalTestimonialCarousel extends Widget_Base {

    public function get_name() {
        return  'royaltestimonialcarousel';
    }

    public function get_title() {
        return esc_html__( 'Royal Testimonial Carousel', 'royaltech' );
    }

    public function get_icon() {
        return 'royalicon eicon-testimonial-carousel';
    }

	public function get_keywords() {
		return ['RoyalTestimonialCarousel', 'Slide', 'Testimonial', 'Carousel', 'Animated', 'Image', 'royal', 'royaltech', 'Royal Technologies', 'Mehdi', 'Mehdi Akram'];
	}

    public function get_categories() {
        return [ 'royaltech' ];
    }


	public function get_style_depends() {
		$styles = ['royalowlcarousel', 'royalowlcarouseltheme' ,'royalcarousel'];
		return $styles;
	}

	public function get_script_depends() {
		$scripts = ['royalowlcarousel'];
		return $scripts;
	}


    public function _register_controls() {
		$this->rt_content_query_options();
		$this->rt_carousel_options();

        $this->rt_style_content_options();
        $this->rt_style_name_options();
        $this->rt_style_title_options();
        $this->rt_style_quote_options();
        $this->rt_style_image_options();
        
        $this->rt_style_navigation_options();
    }

    private function rt_content_query_options() {
        // Content Settings
        $this->start_controls_section(
            'content_settings',
            [
                'label' => __( 'Content', 'royaltech' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );       

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'image',
            [
                'label' => __( 'Image', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'content',
            [
                'label' => __( 'Content', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Royal Technologies provided the most prompt quote of three requested for website design, communicated well during the project, and provided a well-designed website with an easy to use content management system.',
                'label_block' => true
            ]
        );              
        $repeater->add_control(
            'name',
            [
                'label' => __( 'Name', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'S M Mehdi Akram', 'royaltech' ),
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'CEO', 'royaltech' ),
                'label_block' => true
            ]
        );


        $this->add_control(
            'slides',
            [
                'label' => __( 'Slides', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'content'=> 'Royal Technologies provided the most prompt quote of three requested for website design, communicated well during the project, and provided a well-designed website with an easy to use content management system.',
                        'name'   => 'S M Mehdi Akram',
                        'title'  => 'CEO, Royal Group',
                    ],
                    [
                        'content'=> 'As usual very helpful, nothing to much trouble and the end result as I envisaged. Good price point, you pay for what you get and Fluid are full value for money.',
                        'name'   => 'Kh Hasanuzzaman',
                        'title'  => 'Owner, Dania Machineries',
                    ],       
                    [
                        'content'=> 'Very grateful to Royal Technologies for all the hard work they put into our website, finished product was fantastic. Jessie is such a pleasure to work with, would recommend them!',
                        'name'   => 'Md. Masud Rana',
                        'title'  => 'CTO, One Solutions',
                    ],                                 
                ],
                'title_field' => '{{{ title }}}',
            ]
        );       

        $this->add_control(
            'layout',
            [
                'label' => __( 'Layout', 'royaltech' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout1' 	=> 'Layout 1',
                    'layout2'   => 'Layout 2',
                    'layout3' 	=> 'Layout 3',
                    'layout4' 	=> 'Layout 4',					
                    'layout5' 	=> 'Layout 5',
                    'layout6'   => 'Layout 6',
                ],
                'default' => 'layout1',
            ]
        );


        $this->add_control(
            'showarrow',
            [
                'label' => __( 'Arrow', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'royaltech' ),
                'label_off' => __( 'Hide', 'royaltech' ),
                'return_value' => 'showarrow',
                'default' => 'showarrow',
            ]
        );

		$this->add_control(
			'arrowposition',
			[
				'label' => esc_html__( 'Arrow Position', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition' => [
					'showarrow' => ['showarrow'],
				],				
				'size_units' => ['%' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .layout1 .showarrow::after' => 'left: calc({{SIZE}}{{UNIT}} - 25px);',
					'{{WRAPPER}} .royaltestimonialcarousel .layout2 .showarrow::after' => 'left: calc({{SIZE}}{{UNIT}} - 25px);',
					'{{WRAPPER}} .royaltestimonialcarousel .layout3 .showarrow::after' => 'top: calc({{SIZE}}{{UNIT}} - 25px);',
					'{{WRAPPER}} .royaltestimonialcarousel .layout4 .showarrow::after' => 'left: calc({{SIZE}}{{UNIT}} - 25px);',

				],
			]
		);		


        $this->add_control(
            'quotebefore',
            [
                'label' => __( 'Quote Before', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '“',
                'label_block' => true
            ]
        );               

        $this->add_control(
            'quoteafter',
            [
                'label' => __( 'Quote After', 'royaltech' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '„',
                'label_block' => true
            ]
        );   
      
		$this->add_control(
			'imageboxalignment',
			[
				'label' => __( 'Alignment', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'royaltech' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'royaltech' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'royaltech' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'separator'=> 'before',				
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .imagebox' => 'justify-content: {{VALUE}};',
				],
			]
		);
       

    $this->end_controls_section();
    }


	private function rt_carousel_options() {
        // Slider Settings
            $this->start_controls_section(
                'carousel_settings',
                [
                    'label' => __( 'Carousel Settings', 'royaltech' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'navigation_options',
                [
                    'label' => esc_html__( 'Navigation', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
    
            $this->add_control(
                'navposition',
                [
                    'label' => __( 'Navigation Position', 'royaltech' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'royalcarouselnavboth' 	=> 'Both Side',
                        'royalcarouselnavbothlast'=> 'Both Side Last',
                        'royalcarouselnavboth' 	=> 'Both Side',
                        '' 						=> 'Bottom Center',					
                        'royalcarouselnavleft' 	=> 'Bottom Left',
                        'royalcarouselnavright' => 'Bottom Right',
                    ],
                    'default' => '',
                ]
            );
            $this->add_control(
                'dotposition',
                [
                    'label' => __( 'Dot Position', 'royaltech' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' 						=> 'Bottom Center',
                        'royalcarouseldotleft' 	=> 'Bottom Left',
                        'royalcarouseldotright'	=> 'Bottom Right',
                        'royalcarouseldotinsidecenter'	=> 'Bottom Inside Center',
                    ],
                    'default' => '',
                ]
            );
    
            $this->add_control(
                'previousicon',
                [
                    'label' => esc_html__( 'Nav Previous Icon', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fas fa-chevron-left',
                        'library' => 'solid',
                    ],
                ]
            );
            $this->add_control(
                'nexticon',
                [
                    'label' => esc_html__( 'Nav Next Icon', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fas fa-chevron-right',
                        'library' => 'solid',
                    ],
                ]
            );        
            
            $this->add_control(
                'autoplay',
                [
                    'label' => __( 'Auto Play', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => true,
                    'default' => true,
                ]
            );
            
            $this->add_control(
                'loop',
                [
                    'label' => __( 'Loop', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => true,
                    'default' => true,
                ]
            );
    
            $this->add_control(
                'margin',
                [
                    'label' => __( 'Carousel Margin', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'default' => 10,
                ]
            );
    
    
            $this->add_control(
                'timeout',
                [
                    'label' => __( 'Autoplay Timeout (ms)', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'default' => 2500,
                ]
            );
    
            $this->add_control(
                'desktop_options',
                [
                    'label' => esc_html__( 'Desktop', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->end_controls_section();
    
            $this->start_controls_section(
                'desktop_settings',
                [
                    'label' => __( 'Desktop Settings', 'royaltech' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'desktopitems',
                [
                    'label' => __( 'Items', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 1,
                    'max' => 10,
                    'step' => 1,                
                    'default' => 1,
                ]
            );
    
            //Dots
            $this->add_control(
                'desktopdots',
                [
                    'label' => __( 'Dots', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
    
            //Navs
            $this->add_control(
                'desktopnav',
                [
                    'label' => __( 'Navigation', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
    
            $this->end_controls_section();
    
            $this->start_controls_section(
                'tab_settings',
                [
                    'label' => __( 'Tablet Settings', 'royaltech' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'tab_options',
                [
                    'label' => esc_html__( 'Tablet', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'tabitems',
                [
                    'label' => __('Items', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 1,
                    'max' => 6,
                    'step' => 1,
                    'default' => 1,
                ]
            );
            //Dots
            $this->add_control(
                'tabdots',
                [
                    'label' => __( 'Dots', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
    
            //Navs
            $this->add_control(
                'tabnav',
                [
                    'label' => __( 'Navigation', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
    
            $this->end_controls_section();
    
            $this->start_controls_section(
                'mobile_settings',
                [
                    'label' => __( 'Mobile Settings', 'royaltech' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'mobile_options',
                [
                    'label' => esc_html__( 'Mobile', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'mobileitems',
                [
                    'label' => __('Items', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 1,
                    'max' => 3,
                    'step' => 1,                
                    'default' => 1,
                ]
            );
            //Dots
            $this->add_control(
                'mobiledots',
                [
                    'label' => __( 'Dots', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
    
            //Navs
            $this->add_control(
                'mobilenav',
                [
                    'label' => __( 'Navigation', 'royaltech' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'royaltech' ),
                    'label_off' => __( 'Hide', 'royaltech' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
            $this->end_controls_section();
    
    
    }
    

	private function rt_style_content_options() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
              'name' => 'content_typo',
              'label' => __( 'Typography', 'royaltech' ),
              'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
              'selector' => '{{WRAPPER}} .royaltestimonialcarousel .content',
            ]
          );
      
          $this->add_control(
            'content_color',
            [
              'type'      => Controls_Manager::COLOR,
              'label'     => __( 'Color', 'royaltech' ),
              'default'	=> '#000',
              'selectors' => [
                '{{WRAPPER}} .royaltestimonialcarousel .content' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_control(
            'content_background',
            [
              'type'      => Controls_Manager::COLOR,
              'label'     => __( 'Background', 'royaltech' ),
              'default'	=> '#86787844',
              'selectors' => [
                '{{WRAPPER}} .royaltestimonialcarousel .content' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout1 .showarrow::after' => 'border-top-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout2 .showarrow::after' => 'border-top-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout3 .showarrow::after' => 'border-right-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout4 .showarrow::after' => 'border-bottom-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout5 .content:before' => 'border-top-color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .layout5 .content:after' => 'border-top-color: {{VALUE}};',
              ],
            ]
          );
          $this->add_control(
			'content_margin',
			[
				'label' => esc_html__( 'Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'content_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'royaltech' ),
				'selector' => '{{WRAPPER}} .royaltestimonialcarousel .content',
			]
		);        
        $this->end_controls_section();
    }



	private function rt_style_name_options() {
		$this->start_controls_section(
			'section_style_name',
			[
				'label' => __( 'Name', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'name_color',
            [
              'type'      => Controls_Manager::COLOR,
              'label'     => __( 'Color', 'royaltech' ),
              'default'	=> '#000',
              'selectors' => [
                '{{WRAPPER}} .royaltestimonialcarousel .name' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
              'name' => 'name_typo',
              'label' => __( 'Typography', 'royaltech' ),
              'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
              'selector' => '{{WRAPPER}} .royaltestimonialcarousel .name',
            ]
          );

          $this->add_control(
			'name_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);          

        $this->end_controls_section();
    }


	private function rt_style_title_options() {
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => __( 'Title', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'title_color',
            [
              'type'      => Controls_Manager::COLOR,
              'label'     => __( 'Color', 'royaltech' ),
              'default'	=> '#000',
              'selectors' => [
                '{{WRAPPER}} .royaltestimonialcarousel .title' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
              'name' => 'title_typo',
              'label' => __( 'Typography', 'royaltech' ),
              'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
              'selector' => '{{WRAPPER}} .royaltestimonialcarousel .title',
            ]
          );   

          $this->add_control(
			'title_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);  

        $this->end_controls_section();
    }


	private function rt_style_quote_options() {
		$this->start_controls_section(
			'section_style_quote',
			[
				'label' => __( 'Quote', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'quote_color',
            [
              'type'      => Controls_Manager::COLOR,
              'label'     => __( 'Color', 'royaltech' ),
              'default'	=> '#000',
              'selectors' => [
                '{{WRAPPER}} .royaltestimonialcarousel .quotebefore' => 'color: {{VALUE}};',
                '{{WRAPPER}} .royaltestimonialcarousel .quoteafter' => 'color: {{VALUE}};',
              ],
            ]
          );

          $this->add_control(
			'quote_fontsize',
			[
				'label' => esc_html__( 'Width', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
					'em' => [
						'min' => 0,
						'max' => 50,
                        'step' => .1,
					],
				],
				'default' => [
					'unit' => 'em',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .quotebefore' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .royaltestimonialcarousel .quoteafter' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'quotebefore_position',
			[
				'label' => esc_html__( 'Quote Before Position', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .quotebefore' => 'top: {{TOP}}{{UNIT}};  left:{{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'quoteafter_position',
			[
				'label' => esc_html__( 'Quote After Position', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .quoteafter' => 'right:{{RIGHT}}{{UNIT}}; bottom:{{BOTTOM}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
    }

	private function rt_style_image_options() {
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => __( 'Image', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
			'image_size',
			[
				'label' => esc_html__( 'Size', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 300,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],                    
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .image img' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);    
        $this->add_control(
			'image_padding',
			[
				'label' => esc_html__( 'Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .image img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		); 

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'label' => esc_html__( 'Border', 'royaltech' ),
				'selector' => '{{WRAPPER}} .royaltestimonialcarousel .image img',
			]
		);

        $this->add_control(
			'image_box_padding',
			[
				'label' => esc_html__( 'Image Box Padding', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);  
        
        $this->add_control(
			'image_box_margin',
			[
				'label' => esc_html__( 'Image Box Margin', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .royaltestimonialcarousel .image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);  

        $this->end_controls_section();
    }

	private function rt_style_navigation_options() {
		$this->start_controls_section(
			'section_navigation',
			[
				'label' => __( 'Navigation', 'royaltech' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'nav_options',
			[
				'label' => esc_html__( 'Nav Options', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'nav_dev_size',
			[
				'label'     => __( 'Nav Dev height & width', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nav_size',
			[
				'label'     => __( 'Nav Size', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 30,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nav_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Color', 'royaltech' ),
				'default'	=> '#869791',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'nav_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Color Hover', 'royaltech' ),
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button:hover i' => 'color: {{VALUE}};',
				],
			]
		);	
		
		$this->add_control(
			'nav_radius',
			[
				'label'     => __( 'Nav Border Radius', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);
		
		$this->add_control(
			'nav_background',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Background', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i' => 'background-color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'nav_background_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Background Hover', 'royaltech' ),
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button i:hover' => 'background-color: {{VALUE}}!important;',
				],
			]
		);	
		

		$this->add_control(
			'nav_whole_background',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Whole Background', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button' => 'background-color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'nav_whole_background_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Nav Whole Background Hover', 'royaltech' ),
				'default'	=> '#ffffff00',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-nav button:hover' => 'background-color: {{VALUE}}!important;',
				],
			]
		);	
	


		$this->add_control(
			'dot_options',
			[
				'label' => esc_html__( 'Dot Options', 'royaltech' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
		$this->add_control(
			'dot_size',
			[
				'label'     => __( 'Dot Size', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 10,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .royalcarouseldotinsidecenter.owl-carousel .owl-dots .owl-dot' => 'width: calc({{SIZE}}{{UNIT}} + 10px); height: calc({{SIZE}}{{UNIT}} + 10px);',
				],
			]
		);

		$this->add_control(
			'dot_radius',
			[
				'label'     => __( 'Dot Border Radius', 'royaltech' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 50,
				],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'dot_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Dot Color', 'royaltech' ),
				'default'	=> '#869791',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dot_color_active',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Active Dot Color', 'royaltech' ),
				'default'	=> '#dddddd',
				'selectors' => [
					'{{WRAPPER}} .royalmastercarousel .owl-dots .owl-dot.active span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}


    protected function render() {
		$settings 		= $this->get_settings_for_display();
        $id         	= $this->get_id();
        $carouselid     = 'royalcarousel'.$id;
        $loop           = $settings['loop'];
        $autoplay       = $settings['autoplay'];
        $margin         = $settings['margin'];
        $timeout        = $settings['timeout'];
        $navposition    = $settings['navposition'];
        $dotposition    = $settings['dotposition'];
        $previousicon   = $settings['previousicon']['value'];
        $nexticon    	= $settings['nexticon']['value'];
        $navtext    	= "[\"<i class='".$previousicon."'></i>\",\"<i class='".$nexticon."'></i>\"]";

        $desktopitems   = $settings['desktopitems'];
        if ( 'yes' === $settings['desktopdots'] ) {
			$desktopdots = 'true';
		} else{
            $desktopdots = 'false';
        } 
        if ( 'yes' === $settings['desktopnav'] ) {
			$desktopnav = 'true';
		} else{
            $desktopnav = 'false';
        }           


        $tabitems       = $settings['tabitems'];
        if ( 'yes' === $settings['tabdots'] ) {
			$tabdots = 'true';
		} else{
            $tabdots = 'false';
        }
        if ( 'yes' === $settings['tabnav'] ) {
			$tabnav = 'true';
		} else{
            $tabnav = 'false';
        }                     


        $mobileitems    = $settings['mobileitems'];
        if ( 'yes' === $settings['mobiledots'] ) {
			$mobiledots = 'true';
		} else{
            $mobiledots = 'false';
        } 
        if ( 'yes' === $settings['mobilenav'] ) {
			$mobilenav = 'true';
		} else{
            $mobilenav = 'false';
        } 

        $this->add_render_attribute(
            'royal_carousel_options',
            [
                'id'                	=> $carouselid,
                'data-loop'         	=> $loop,
                'data-autoplay'     	=> $autoplay,
                'data-margin'       	=> $margin,
                'data-autoplayTimeout'	=> $timeout,
                'data-navtext'   		=> $navtext,	

                'data-desktopitems' 	=> $desktopitems,
                'data-desktopdots'  	=> $desktopdots,
                'data-desktopnav'   	=> $desktopnav,

                'data-tabitems'     	=> $tabitems,
				'data-tabdots'  		=> $tabdots,
                'data-tabnav'   		=> $tabnav,

                'data-mobileitems'  	=> $mobileitems,
                'data-mobiledots'  		=> $mobiledots,
                'data-mobilenav'   		=> $mobilenav,	
			
            ]
        );
 
    echo '<div class="royalmastercarousel">';
    echo '<div class="royalcarousel royaltestimonialcarousel owl-carousel owl-theme '.$navposition.' '.$dotposition.'" '.$this->get_render_attribute_string( 'royal_carousel_options' ).'>';
        foreach( $settings[ 'slides' ] as $slide ):
           // $image_url = \Elementor\Group_Control_Image_Size::get_attachment_image_src($slide['image']['id'], 'thumbnail', $slide);
           
           if($slide['image']['id']){
            $img_atts = wp_get_attachment_image_src($slide['image']['id'], 'medium');
            $image_url = $img_atts[0];
           } else {
            $image_url = $slide['image']['url'];
           }

            
            if('layout1'== $settings['layout']){
            echo '<div class="item layout1">';
                echo '<div class="content '.$settings['showarrow'].'">';
                if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
                echo $slide['content'];
                if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
                echo '</div>';
                echo '<div class="imagebox">';
                    echo '<div class="imageboxinner">';
                        echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                        echo '<div class="name">'.$slide['name'].',&nbsp;</div>';
                        echo '<div class="title">'.$slide['title'].'</div>';
                    echo '</div>';
                echo '</div>';
             echo '</div>'; 
                
                
            } elseif('layout2'== $settings['layout']){
            echo '<div class="item layout2">';
                echo '<div class="content '.$settings['showarrow'].'">';
                if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
                echo $slide['content'];
                if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
                echo '</div>';
                echo '<div class="imagebox">';
                    echo '<div class="imageboxinner">';
                        echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                        echo '<div class="nametitle">';
                        echo '<div class="name">'.$slide['name'].'</div>';
                        echo '<div class="title">'.$slide['title'].'</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
             echo '</div>';


            } elseif('layout3'== $settings['layout']){
            echo '<div class="item layout3">';
                echo '<div class="imageleft">';
                    echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                echo '</div>';
                echo '<div class="contentright">';
                    echo '<div class="content '.$settings['showarrow'].'">';
                    if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
                    echo $slide['content'];
                    if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
                    echo '</div>';
                    echo '<div class="name">'.$slide['name'].'</div>';
                    echo '<div class="title">'.$slide['title'].'</div>';                    
                echo '</div>';
            echo '</div>';
            

        } elseif('layout4'== $settings['layout']){
            echo '<div class="item layout4">';
            echo '<div class="imagebox">';
                echo '<div class="imageboxinner">';
                    echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                echo '</div>';
            echo '</div>';

            echo '<div class="content '.$settings['showarrow'].'">';
            if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
            echo $slide['content'];
            if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
            echo '</div>';
            echo '<div class="imagebox">';
                echo '<div class="imageboxinner">';
                    echo '<div class="name">'.$slide['name'].'</div>';
                    echo '<div class="title">'.$slide['title'].'</div>';
                echo '</div>';
            echo '</div>';
         echo '</div>';


        } elseif('layout5'== $settings['layout']){
            echo '<div class="item layout5">';
            echo '<div class="content">';

            if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
            echo $slide['content'];
            if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
            echo '<div class="imagebox">';
                echo '<div class="imageboxinner">';
                    echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                    echo '<div class="name">'.$slide['name'].'</div>';
                    echo '<div class="title">'.$slide['title'].'</div>';
                echo '</div>';
            echo '</div>';
            echo '</div>';
         echo '</div>';



        } else {
            echo '<div class="item layout1">';
                echo '<div class="content '.$settings['showarrow'].'">';
                if ( $settings['quotebefore'] ) { echo '<span class="quotebefore">'.$settings['quotebefore'].'</span>';}
                echo $slide['content'];
                if ( $settings['quoteafter'] ) { echo '<span class="quoteafter">'.$settings['quoteafter'].'</span>';}
                echo '</div>';
                echo '<div class="imagebox">';
                    echo '<div class="imageboxinner">';
                        echo '<div class="image"><img src="' . esc_attr($image_url) . '" alt="' . esc_attr($slide['title'] ) . '" /></div>';
                        echo '<div class="name">'.$slide['name'].',&nbsp;</div>';
                        echo '<div class="title">'.$slide['title'].'</div>';
                    echo '</div>';
                echo '</div>';
             echo '</div>';
            }


        endforeach;          
    echo '</div>';
    echo '</div>';
    }













}
